//(function(angular){
//	'use strict';
	angular.module('winsoft.treeWidget', [])
		.directive('treeModel',['$compile',function($compile){
				return{
					restrict:'A',
					//scope: { treeModel: '=fabricList'},
					link:function(scope,element,attrs){
						var treeId=attrs.treeId;
						var treeModel=attrs.treeModel;
						var nodeId=attrs.nodeId;
						var nodeLabel=attrs.nodeLabel;
						var nodeChildren=attrs.nodeChildren;
						var searchQuery=attrs.searchQuery;
						
						var template='<ul data-ng-class="{subTree: node.'+nodeChildren+'.length}">'+'<li data-ng-repeat="node in '+treeModel+' |  filter:'+searchQuery+' ">'+'<i class="collapsed" data-ng-class="{nopointer: !node.'+nodeChildren+'.length}"'+'data-ng-show="!node.expanded && !node.fileicon" data-ng-click="'+treeId+'.selectNodeHead(node)"></i>'+'<i class="expanded" data-ng-show="node.expanded && !node.fileicon" data-ng-click="'+treeId+'.selectNodeHead(node)"></i>'+'<i class="normal" data-ng-show="node.fileicon"></i> '+'<span class="fa fa-cloud" data-ng-show="node.'+nodeChildren+'.length"></span><span class="fa fa-share-alt" data-ng-show="!node.'+nodeChildren+'.length"></span><span class="treenode" title="{{node.'+nodeLabel+'}}" data-ng-class="node.selected" data-ng-click="'+treeId+'.selectNodeLabel(node)">{{node.'+nodeLabel+'}}</span>'+'<div data-ng-show="node.expanded" data-tree-id="'+treeId+'" data-tree-model="node.'+nodeChildren+'" data-node-id='+nodeId+' data-node-label='+nodeLabel+' data-node-children='+nodeChildren+' data-search-query='+searchQuery+' data-ng-class="{subTree: node.'+nodeChildren+'.length}"></div>'+'</li>'+'</ul>';
						
						if( treeId && treeModel ) {
							if(attrs.angularTreeview) {
								scope[treeId] = scope[treeId] || {};

								scope[treeId].selectNodeHead 
									= scope[treeId].selectNodeHead
										||	function(selectedNode) {
												if(selectedNode[nodeChildren] !== undefined) { 
													selectedNode.expanded = !selectedNode.expanded;
												}
											};

								scope[treeId].selectNodeLabel 
									= scope[treeId].selectNodeLabel
										|| function(selectedNode) { 
												if (scope[treeId].currentNode && scope[treeId].currentNode.selected ) { 
													scope[treeId].currentNode.selected = undefined;
												}

												selectedNode.selected = 'selected';
												scope[treeId].currentNode = selectedNode;
												scope.$emit('selection-changed', selectedNode);
											};

							}

							element.html('').append($compile(template)(scope));
						}
					}};
			}])
		.directive('searchFilter', function () {
			/*
			 *  Example usage
			 *  "get" returns list of search results
			 *  "action"  method to implement "after item selection" action
			 * <search-filter get="getMatch(item)" action="myaction(item, history)"
			 *                searchtext="Search Analytics" loadingtext="Searching..."></search-filter>
			 */
			return {
				restrict: 'E',
				replace: true,
				scope: {
					get: '&',
					action: '&',
					searchtext: "@",
					loadingtext: "@"
				},
				link: function (scope, elem, attrs) {
					scope.selectedItem = "";
					scope.placeholder = attrs["searchtext"];
					scope.history = [];
					scope.getItem = function (item) {
						scope.placeholder = attrs["loadingtext"];
						try {
							return scope.get({item: item});
						} catch(e){
							console.log("Errors when get action is not defined. ",e)
						}
					};

					scope.onSelect = function(selected) {
						if (typeof selected === "undefined") { // clear history
							scope.selectedItem = "";
							scope.history.splice(0, scope.history.length);
						} else if (arguments.length > 0 && selected !== "") {
							// arguments > 0 for($item, $model, $label, $event) or call from history
							scope.selectedItem = selected.display || selected;
							if (scope.history.indexOf(scope.selectedItem) === -1)
								scope.history.push(scope.selectedItem);
						}
						// fetch backend
						try {
							return scope.action({item: scope.selectedItem, history: scope.history});
						} catch(e){
							console.log("Errors when action is not defined. ",e)
						}
					}
				},
				template : function (elem, attrs) {
					var html = '<div class="input-group" style="width: 100%;">'+
						'<span class="input-group-addon icon-lookup"><span class="fa fa-search" aria-hidden="true"></span></span>'
						+ '<input type="text" ng-model="selectedItem" class="form-control" placeholder="{{searchtext}}"'
						+ 'typeahead-on-select="onSelect($item, $model, $label, $event)"'
						+ 'uib-typeahead="item for item in getItem($viewValue) " >'
						// + 'uib-typeahead="items for items in getItem($viewValue) | toArray:false | filter:$viewValue" >'
						+ '<div class="input-group-addon icon-history" tooltip-placement="left" tooltip-append-to-body="true" uib-tooltip="Show History">'
						+ '<div uib-dropdown class="btn-group">'
						+ '<button type="button" class="btn btn-primary" uib-dropdown-toggle ng-disabled="history.length === 0">'
						+ '<span class="fa fa-history" aria-hidden="true"></span></button>'
						+ '<ul role="menu" uib-dropdown-menu class="dropdown-menu dropdown-menu-right">'
						+ '<li role="menuitem" ng-repeat="label in history"><a href="javascript:void(0)" ng-click="onSelect(label)">{{label}}</a></li>'
						+ '<li role="separator" class="divider"></li>'
						+ '<li><a href="javascript:void(0)" ng-click="onSelect()">Clear History</a></li>'
						+ '</ul>'
						+ '</div></div>'
						+ '</div>';
					return html;
				}
			};
		});
//})(angular);