VCF.controller('HeaderController', ['$scope', '$http', 'config', 'ContextSearchService', 'SharedDataService', '$rootScope', 'ngDialog',
	function($scope, $http, config, ContextSearchService, SharedDataService, $rootScope, ngDialog) {
        $scope.appList = [
            {"app": "vcf-ia", "app-name" : "Insight Analytics", "build": "vcfc"},
            {"app": "vcf-pa", "app-name" : "Packet Analytics", "build": "vcfc"},
            {"app": "vcf-mgr", "app-name" : "VCF Manager", "build": "vcfc", "beta":true}
        ];
		$scope.username="admin";
		$scope.networkCode;
		
		/* commented because of common search moved from header to fabric and other parts separately
		$rootScope.isDataFound = false;
		
		$scope.search = function(){
			$http
				({
					method: 'POST',
					url: config.CONTEXT_SEARCH_POST_URI,
					params: {
						'networkCode': $scope.networkCode
					},
					data: {
						'context': $rootScope.contextValue,
						'key': '',
						'value': $scope.searchValue
					}
				})
				.success(function() {
					ContextSearchService.sendData($scope.searchValue);
				}) ;
		};
		*/
		
		$scope.$on('fabric_change', function(event, newValue, oldValue, parent){
			$scope.networkCode = (newValue.networkCode ? newValue.networkCode : newValue.code);
		});
		
		$scope.logout = function(){
			var req = {
					method: 'GET',
					url: '/logout',
					headers: {
						'Content-Type': 'text/plain'
					}
				};
			
			$http(req).success(function(){
				document.location = "/";
			})
			.error(function(resp) {
				document.location = "/";
				console.log(resp);
			});
		};
		
		$scope.$on('notification', function (event, notification) {
			if($scope.notificationDialog){
				ngDialog.close($scope.notificationDialog);
			}
			$scope.notificationDialog = ngDialog.open({
				disableAnimation: true,
				template: notification.msg,
				plain: 'true',
				overlay: false,
				appendClassName: 'ngdialog-errNotification'
			});
		});

		// #TODO use lodash utils
		// ex: _.find(appList, {app: v.app});
		function findApp(id) {
			for (var i = 0; i < $scope.appList.length; i++) {
				if ($scope.appList[i].app === id) {
					return $scope.appList[i];
				}
			}
			return null;
		}

		(function () {
			$http({ method: 'GET', url: config.APPLICATION_VERSION_INFORMATION_GET_URI})
				.then(function (response) {
					if(response){
						response.data.map(function (v) {
							//update app properties.
							var app = findApp(v.app);
							if (app)
								for (var key in v)
									app[key] = v[key];
						});
					}
				}, function () {
					console.error("Error while getting app info");
				})
		})();
	}
]);