VCF.factory('ContextSearchService', [ '$rootScope', '$timeout', function($rootScope, $timeout){
	var service = {};
	service.searchText = "";
	service.sendData = function(data){
		service.searchText = data;
		$rootScope.$broadcast('text_search');
	};
	service.getData = function(){
		return service.searchText;
	};
	return service;
}]);