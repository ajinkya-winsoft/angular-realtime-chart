VCF.controller('NavbarController', ['$scope', '$rootScope', '$http', '$location', 'SharedDataService', 'config', '$state', '$timeout',
	function($scope, $rootScope, $http, $location, SharedDataService, config, $state, $timeout){
		$rootScope.ansibleAccess = false;
		
		$http ({
			method: 'GET',
			url: config.MENUS_GET_URI,
			params: {"Param1" : "xxx1"}
		})
		.success(function(data){
			$scope.treeMenu = data.menuItems;
			if(data.menuItems[0].modules[0].modules && data.menuItems[0].modules[0].modules[0].name == 'ansible' && data.menuItems[0].modules[0].modules[0].access == true) {
				$rootScope.ansibleAccess = true;
			}
			
			// $timeout(function(){
				// var node, nodeNamePos;
				// var stateName = $state.current.name.split(".");
				// for(i=0; i<$scope.treeMenu.length; i++){
					// if(stateName[0]==$scope.treeMenu[i].name){
						// nodeNamePos = i;
					// }
				// }
				// node = $scope.treeMenu[nodeNamePos];
				
				// node.selected = !node.selected;
			// }, 1000);
			
		})
		.error(function(resp) {
			console.log(resp);
		});
		
		$scope.$on('selection-changed', function (e, node) {
			SharedDataService.setCurrentMenu(node);	
			$location.path(node.url);
			var context =  SharedDataService.getContext();
		});
		
	}
]);