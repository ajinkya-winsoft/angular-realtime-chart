VCF.controller('NotificationController', ['$scope', '$rootScope', '$http', '$q', '$filter', '$interval', 'ngDialog', 'config', '$timeout', 'ContextSearchService', 
	function($scope, $rootScope, $http, $q, $filter, $interval, ngDialog, config, $timeout, ContextSearchService){

		$scope.notificationList = {};
		$scope.currentNotification = {};
		$rootScope.contextValue = "notifications";
		
		$scope.search = function(){
			$http
				({
					method: 'POST', 
					url: config.CONTEXT_SEARCH_POST_URI,
					data: {
						'context': $rootScope.contextValue,
						'key': '',
						'value': $scope.searchValue
					}
				})
				.success(function() {
					ContextSearchService.sendData($scope.searchValue);
				}) ;
		};
		
		$scope.startsWith = function (actual, expected) {
			var lowerStr = (actual + "").toLowerCase();
			return lowerStr.indexOf(expected.toLowerCase()) === 0;
		}
		
		$scope.$on('text_search', function(){
			var searchValue =  ContextSearchService.getData();
			if (searchValue == '') {
				$scope.gridOptions.data = $scope.notificationList;
			}
			else {
				$scope.gridOptions.data = $filter('filter')($scope.notificationList, searchValue, $scope.startsWith);
			}
        });

		$scope.openNotification = function (value) {
			
			if(value) {
				$scope.currentNotification = value;
			} 
			else {
				$scope.currentNotification = {};
				$scope.currentNotification.type = "select";
				$scope.currentNotification.pollingFrequency = 1;
				$scope.currentNotification.severity = "select";
				$scope.currentNotification.retriggerPeriod = 1;
				$scope.currentNotification.shouldMatchAll = true;
				$scope.currentNotification.conditions = [
				// {
					// 'code': 1,
					// 'operand1': 'select',
					// 'operator': 'select',
					// 'operand2': ''
				// }
				];
				$scope.currentNotification.action = "none";
				$scope.currentNotification.state = "select";
			}
			$scope.notificationDialog = ngDialog.open({
				template: './app/components/notifications/notification-registration.dialog.htm',
				showClose: false,
				closeByDocument: false,
				closeByEscape: false,
				width:500,
				scope: $scope,
				appendClassName: 'ngdialog-notification',
			})
		};
		
		$scope.deleteRow = function(row) {
			ngDialog.openConfirm({
				template:
					'<div class="inner-dialog-container">'+
						'<p>Are you sure you want to delete this notification?</p>'+
						'<div class="ngdialog-buttons">'+
							'<button type="button" class="button" ng-click="closeThisDialog(0)"> No </button> '+
							'<button type="button" class="button" ng-click="confirm(1)">Yes</button>'+
						'</div>'+
					'</div>',
				plain: true
			}).then(function(success){
				var index = $scope.gridOptions.data.indexOf(row.entity);
				$http ({
					method: 'DELETE',
					url: config.NOTIFICATION_DELETE_URI + "/" + row.entity.code
				})
				.success(function(response){
					//console.log('all is good', response.data);
					var deleteNotificationDialog = ngDialog.open({
						template: 
							'<div class="inner-dialog-container success-container">'+
								'<div>Notification deleted successfully.</div>'+
							'</div>',
						plain: 'true',
						showClose: false,
						overlay: false,
						width:250
					});
					
					$timeout(function () {
						ngDialog.close(deleteNotificationDialog);
					}, 2000);
					
					$scope.gridOptions.data.splice(index, 1);
					loadNotifications();
				})
				.error(function(resp) {
					console.log('an error occurred', resp.data);
					console.log(resp);
				});
			})
		};
		
		$scope.columns = [
			{name: 'name', displayName: 'Name', width:150},
			{name: 'type', displayName: 'Type'},
			{name: 'state', displayName: 'State'},
			{name: 'actions',  
					enableCellEdit: false, 
					enableSorting:false,
					width: 80,
					cellTemplate: 
						'<button ng-click="grid.appScope.openNotification(row.entity)" class="icon-edit" tooltip-placement="left" uib-tooltip="Edit Notification">Edit</button>'+	
						'<button ng-click="grid.appScope.deleteRow(row)" class="icon-delete" tooltip-placement="left" uib-tooltip="Delete Notification"> Delete </button>'
			}		
		];
		
		var paginationOptions = {
			pageNumber: 1,
			pageSize: 10
		};
		
		$scope.gridOptions = {
			rowEditWaitInterval: 1000,
			paginationPageSizes: [10, 15, 20],
			paginationPageSize: 10,
			enableCellEdit: false,
			enableGridMenu: true,
			enableColumnResizing: true,
			columnDefs: $scope.columns,
			onRegisterApi: function(gridApi) {
				$scope.gridApi = gridApi;
				//gridApi.rowEdit.on.saveRow($scope, $scope.saveRow);
				
				gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
					paginationOptions.pageNumber = newPage;
					paginationOptions.pageSize = pageSize;
					loadNotifications();
				});
			}
		};
		
		var loadNotifications = function() {
			$scope.loading = true;
			$http ({
				method: 'GET',
				url: config.NOTIFICATIONS_GET_URI,
				params: {
					"pageNumber": paginationOptions.pageNumber, 
					"pageSize" : paginationOptions.pageSize
				}
				
			})
			.success(function (response) {
				for(i=0; i< response.result.length; i++){
					if(typeof response.result[i].severity == "number"){
						response.result[i].severity = response.result[i].severity.toString();
					}
				}
				$scope.gridOptions.data = response.result;
				$scope.notificationList = response.result;
				$scope.loading = false;
			})
			.error(function(resp) {
				console.log(resp);
				$scope.loading = false;
			});
		};
		// automatically called when the grid is edited inline (within row)
		
		$scope.saveRow = function( rowEntity ) {
			// create a fake promise - normally you'd use the promise returned by $http or $resource
			var promise = $q.defer();
			
			//$scope.gridApi.rowEdit.setSavePromise( rowEntity, promise.promise );

			// fake a delay of 3 seconds whilst the save occurs, return error if gender is "male"
			$interval( function() {
				if (rowEntity.ip === '' ) {
					promise.reject();
				}
				else {
					promise.resolve();
					$http ({
						method: 'POST',
						url: config.NOTIFICATION_POST_URI,
						data: rowEntity
					})
					.success(function(response){
					
						var updateNotificationDialog = ngDialog.open({
							template: 
								'<div class="inner-dialog-container success-container">'+
									'<div>Notification updated successfully.</div>'+
								'</div>',
							plain: 'true',
							showClose: false,
							overlay: false,
							width:250
						});
						
						$timeout(function () {
							ngDialog.close(updateNotificationDialog);
						}, 2000);
						
						loadNotifications();
					})
				}
			}, 100, 1);

		};
		
		$scope.refreshNotification = function(){
			loadNotifications();
		}
		
		$scope.$on('load-notification', function(event) {
			loadNotifications();
		});
		
		$scope.$on('update-row', function(event, data) {
			$scope.saveRow(data);
		});
		
		loadNotifications();
	}
]);