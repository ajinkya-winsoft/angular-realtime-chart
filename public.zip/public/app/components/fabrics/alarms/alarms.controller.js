VCF.controller('AlarmsController', ['$scope', '$rootScope', '$http', 'config', '$timeout', '$filter', 'ContextSearchService', 'ngDialog',
	function($scope, $rootScope, $http, config, $timeout, $filter, ContextSearchService, ngDialog) {

		$scope.filterDiv = true;
		$scope.hideGridDiv = false;
		$scope.networkCode;
		$scope.showAlarms = false;
		$scope.dataReload = false;
		$rootScope.fabricSelected = false;
		$scope.alarmsList = [];
		$scope.switchList = [];
		$scope.startTime = "";
		$scope.endTime = "";
		$scope.isDataFound = false;

		$scope.gridAlert = false;
		$scope.gridAudit = false;
		$scope.gridEvent = false;
		$scope.gridSystem = false;

		$scope.logType={};
		$scope.logType.options ="0";

		$scope.endTime = $filter('date')(new Date(), 'yyyy-MM-ddThh:mm:ss');
		var todatDate = new Date();
		//var yesterdayDate = todatDate - (1000 * 60 * 60 * 24); // yesterdayDate
		var yesterdayDate = todatDate - 600000; // 10 min before time.
		$scope.startTime = $filter('date')(new Date(yesterdayDate), 'yyyy-MM-ddThh:mm:ss');

		$scope.$on('text_search', function(){
			if($rootScope.selectedFabricsTab == "alarms" && $scope.alarmsList){
				var searchValue =  ContextSearchService.getData();

				if (searchValue == '') {
					if($scope.logType.options == "ALERT"){
						$scope.gridOptions_Alert.data = $scope.alarmsList;
					}
					else if($scope.logType.options == "AUDIT"){
						$scope.gridOptions_Audit.data = $scope.alarmsList;
					}
					else if($scope.logType.options == "EVENT"){
						$scope.gridOptions_Event.data = $scope.alarmsList;
					}
					else if($scope.logType.options == "SYSTEM"){
						$scope.gridOptions_System.data = $scope.alarmsList;
					}
				}
				else {
					if($scope.logType.options == "ALERT"){
						$scope.gridOptions_Alert.data = $filter('filter')($scope.alarmsList, searchValue, undefined);
					}
					else if($scope.logType.options == "AUDIT"){
						$scope.gridOptions_Audit.data = $filter('filter')($scope.alarmsList, searchValue, undefined);
					}
					else if($scope.logType.options == "EVENT"){
						$scope.gridOptions_Event.data = $filter('filter')($scope.alarmsList, searchValue, undefined);
					}
					else if($scope.logType.options == "SYSTEM"){
						$scope.gridOptions_System.data = $filter('filter')($scope.alarmsList, searchValue, undefined);
					}
				}
			}
        });

		$scope.columns_Alert = [
			{name: 'category', displayName: 'Category', visible:false},
			{name: 'time', displayName: 'Time'},
			{name: 'switch', displayName: 'Switch'},
			{name: 'code', displayName: 'Code'},
			{name: 'name', displayName: 'Name'},
			{name: 'count', displayName: 'Count'},
			{name: 'last-message', displayName: 'Last Message'}
		]

		// var paginationOptions = {
			// pageNumber: 1,
			// pageSize: 10
		// }

		$scope.gridOptions_Alert = {
			enableCellEdit: false,
			enableSorting: true,
			enableGridMenu: true,
			enableColumnResizing: true,
			//paginationPageSizes: [10, 15, 20],
			//paginationPageSize: 10,
			columnDefs: $scope.columns_Alert,
			// onRegisterApi: function(gridApi) {
				// gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
					// paginationOptions.pageNumber = newPage;
					// paginationOptions.pageSize = pageSize;
					// loadBroadcastDomains();
				// });
			// }
		};

		$scope.columns_Audit = [
			{name: 'category', displayName: 'Category', visible:false},
			{name: 'time', displayName: 'Time'},
			{name: 'switch', displayName: 'Switch'},
			{name: 'program', displayName: 'Program'},
			{name: 'pid', displayName: 'PID'},
			{name: 'name', displayName: 'Name'},
			{name: 'code', displayName: 'Code'},
			{name: 'user', displayName: 'User'},
			{name: 'client-pid', displayName: 'Client Pid'},
			{name: 'client-addr', displayName: 'Client Addr'},
			{name: 'message', displayName: 'Message'},
			{name: 'starting-point', displayName: 'Starting Point'},
			{name: 'length', displayName: 'Length'}
		]

		$scope.gridOptions_Audit = {
			enableCellEdit: false,
			enableSorting: true,
			enableGridMenu: true,
			enableColumnResizing: true,
			columnDefs: $scope.columns_Audit

		};

		$scope.columns_Event = [
			{name: 'category', displayName: 'Category', visible:false},
			{name: 'time', displayName: 'Time'},
			{name: 'name', displayName: 'Name'},
			{name: 'code', displayName: 'Code'},
			{name: 'event-type', displayName: 'Event Type'},
			{name: 'port', displayName: 'Port'},
			{name: 'message', displayName: 'Message'}
		]

		$scope.gridOptions_Event = {
			enableCellEdit: false,
			enableSorting: true,
			enableGridMenu: true,
			enableColumnResizing: true,
			columnDefs: $scope.columns_Event

		};

		$scope.columns_System = [
			{name: 'category', displayName: 'Category', visible:false},
			{name: 'level', displayName: 'Level',
				cellClass: function(grid, row, col, rowRenderIndex, colRenderIndex) {
					if (grid.getCellValue(row,col) == 'critical') {
						return 'red';
					}
					else if (grid.getCellValue(row,col) == 'error') {
						return 'orange';
					}
					else if (grid.getCellValue(row,col) == 'warn') {
						return 'yellow';
					}
					else if (grid.getCellValue(row,col) == 'note') {
						return 'green';
					}
				}
			},
			{name: 'time', displayName: 'Time'},
			{name: 'switch', displayName: 'Switch'},
			{name: 'program', displayName: 'Program'},
			{name: 'pid', displayName: 'PID'},
			{name: 'name', displayName: 'Name'},
			{name: 'code', displayName: 'Code'},
			{name: 'message', displayName: 'Message'},
			{name: 'startingPoint', displayName: 'Starting Point'},
			{name: 'length', displayName: 'Length'}
		]

		$scope.gridOptions_System = {
			enableCellEdit: false,
			enableSorting: true,
			enableGridMenu: true,
			enableColumnResizing: true,
			columnDefs: $scope.columns_System

		};

		$scope.$on('fabric_change', function(event, newValue, oldValue, parent) {
			$scope.networkCode = (newValue.networkCode ? newValue.networkCode : newValue.code);
			$rootScope.selectedSwitchId = newValue.id;
			$scope.dataReload = false;

		});
		
		$scope.$on('fabric_node_change', function(event, newValue, oldValue, parent){
			$rootScope.selectedSwitchId = newValue.id;
			if(newValue.networkCode && (newValue != oldValue)){
				$scope.load();
			}
		});

		$scope.getSwitchList = function(){
			$http ({
				method: 'GET',
				url: config.SWITCH_NAMES_GET_URI,
				params: {
					"networkCode": $scope.networkCode,
					"switchId": $rootScope.selectedSwitchId	
				}
			})
			.success(function (response) {
				if(response.result){
					$scope.switchList = response.result;
				}

			})
			.error(function(resp) {
				console.log(resp);
			});
		};

		$scope.$on('selectedFabricsTab', function(event) {

			if($rootScope.selectedFabricsTab == "alarms" && $scope.networkCode  && !$scope.dataReload){
				$scope.showAlarms = true;
				$scope.loading = false;
				$scope.filterDiv = false;
				$rootScope.fabricSelected = true;
				$scope.getSwitchList();
			}
			if($rootScope.selectedFabricsTab == "alarms"){
				$rootScope.contextValue = "syslogs";
			}
		});

		$scope.load = function() {

			$scope.loading = true;
			$http ({
					method: 'POST',
					url: config.LOGS_POST_URI,
					params: {
						"logType": $scope.logType.options,
						"networkCode": $scope.networkCode,
						"switchId": $rootScope.selectedSwitchId
					},
					data: {
						"startTime": $scope.startTime,
						"endTime": $scope.endTime
					}
				})
				.success(function (response) {

					if (!response.result || response.result.length == 0) {
						//console.log(response.result.length);
						$scope.isDataFound = true;
						$scope.loading = false;

						$scope.gridAlert = false;
						$scope.gridAudit = false;
						$scope.gridEvent = false;
						$scope.gridSystem = false;
					}
					else{

						$scope.hideGridDiv = true;
						$scope.loading = false;
						$scope.dataReload = true;
						$scope.isDataFound = false;

						$scope.gridAlert = false;
						$scope.gridAudit = false;
						$scope.gridEvent = false;
						$scope.gridSystem = false;

						for(var x=0; x<response.result.length; x++){
							for(var j=0; j<$scope.switchList.length; j++){
								if(response.result[x].switch == $scope.switchList[j].id){
									response.result[x].switch = $scope.switchList[j].name;
								}
							}
						}

						$scope.alarmsList = response.result;

						if($scope.logType.options == "ALERT"){
							$scope.gridAlert = true;
							$scope.gridOptions_Alert.data = response.result;
						}
						else if($scope.logType.options == "AUDIT"){
							$scope.gridAudit = true;
							$scope.gridOptions_Audit.data = response.result;
						}
						else if($scope.logType.options == "EVENT"){
							$scope.gridEvent = true;
							$scope.gridOptions_Event.data = response.result;
						}
						else if($scope.logType.options == "SYSTEM"){
							$scope.gridSystem = true;
							$scope.gridOptions_System.data = response.result;
						}
					}
				})
				.error(function(resp) {
					console.log(resp);
					$scope.loading = false;
				});
		};

		$scope.filterAlarms = function(){
			$scope.startTime = angular.element( document.querySelector( '#startTime' )).val();
			$scope.endTime = angular.element( document.querySelector( '#endTime' )).val();

			var start_time = new Date($scope.startTime).getTime();
	 		var end_time = new Date($scope.endTime).getTime();

			if($scope.logType.options == 0 || $scope.startTime == "" || $scope.endTime == "")
			{
				ngDialog.open({
					template:
						'<div class="inner-dialog-container">'+
							'<div>Please select a Log Type, Start Time and End time</div>'+
							'<button type="button" class="button" ng-click="closeThisDialog(0)">Close</button>'+
						'</div>',
					plain: 'true'
					});
			}else if((end_time - start_time)<=0){
						ngDialog.open({
								template:
									'<div class="inner-dialog-container">'+
										'<div> Start time should be less than end time. </div>'+
										'<button type="button" class="button" ng-click="closeThisDialog(0)">Close</button>'+
									'</div>',
								plain: 'true'
						});
			}else{
				$scope.load();
			}
		}

		$scope.clear = function(){
			$timeout(function () {
				$scope.endTime = $filter('date')(new Date(), 'yyyy-MM-ddThh:mm:ss');
				var todatDate = new Date();
				var yesterdayDate = todatDate - (1000 * 60 * 60 * 24);
				$scope.startTime = $filter('date')(new Date(yesterdayDate), 'yyyy-MM-ddThh:mm:ss');
					$scope.logType.options ="0";
					var el = angular.element( document.querySelector( '#startTime' )).val($scope.startTime).change();
					var el = angular.element( document.querySelector( '#endTime' )).val($scope.endTime).change();


			});

			$scope.hideGridDiv = false;
			$scope.isDataFound = false;
		};

		if($rootScope.selectedFabricsTab == "alarms" && $scope.networkCode  && !$scope.dataReload){
			$scope.showAlarms = true;
			$scope.loading = false;
			$scope.filterDiv = false;
			$rootScope.fabricSelected = true;
			$scope.getSwitchList();
		}
		if($rootScope.selectedFabricsTab == "alarms"){
			$rootScope.contextValue = "syslogs";
		}
	}
]);
