VCF.controller('MapController', ['$scope', '$rootScope', '$http', 'SharedDataService', 'FabricsDataService', 'config', '$timeout', 'ngDialog', '$interval', '$window', 'ContextSearchService', '$filter',
	function($scope, $rootScope, $http, SharedDataService, FabricsDataService, config, $timeout, ngDialog, $interval, $window, ContextSearchService, $filter) {
		$scope.dataReload = false;
		$rootScope.fabricSelected = false;
		$scope.contextNode;
		$scope.selectedNodes = [];
		$scope.bgpAutomaticConfig = {};
		$scope.nodeComments = {};

		$scope.nodeNotifications = {};
		$scope.linkNotifications = {};

		$scope.name;
		$scope.savedNodeX;
		$scope.savedNodeY;
		$scope.links;
		$scope.mapNodesData;

		$scope.minChildNodesVisible = 10;
		$scope.labelCount=1;

		$scope.PortstatsPollingDuration = 5000;
		$scope.maxVisibleNotifications = 10;
		$scope.awaitingPortStatsPollingResponse = false;
		$scope.fabricsStatsPolling = false;

		$scope.MapX, $scope.MapY;

		$scope.isContextClickNode = false;

		$scope.nodeCommentExist = false;
		$scope.FabricsStatsBtnText = "Update Fabrics Stats";

		$scope.$on('text_search', function(newValue){
			if($rootScope.selectedFabricsTab == "map") {
				var searchValue =  ContextSearchService.getData();
				if (searchValue != '') {
					d3.selectAll("image.node-selection")
						.transition()
						.attr("width", 10)
						.attr("height", 10)
						.remove();
						
					d3.selectAll("g.node")
						.each(function(d, i){
							if (searchValue === d.name || searchValue === d.mgmtIp){
								d3.select(this).insert("image",":first-child")
									.attr("class","node-selection")
									.attr("xlink:href","assets/images/node-selection.png")
									.attr("width", 10)
									.attr("height", 10)
									.attr("x", function(d) { return d.x - 20; })
									.attr("y", function(d) { return d.y; })
									.attr("transform", "translate(-16,-18)")
									.transition()
									.attr("width", 70)
									.attr("height", 50);
							};
							
							if(d.networkTrunks !== null){
								for(i=0; i< d.networkTrunks.length; i++){
									if (searchValue == d.networkTrunks[i].trunk || searchValue == d.networkTrunks[i].trunkname){
										d3.select(this).insert("image",":first-child")
											.attr("class","node-selection")
											.attr("xlink:href","assets/images/node-selection.png")
											.attr("width", 10)
											.attr("height", 10)
											.attr("x", function(d) { return d.x - 20; })
											.attr("y", function(d) { return d.y; })
											.attr("transform", "translate(-16,-18)")
											.transition()
											.attr("width", 70)
											.attr("height", 50);
									}
								}	
							}
							
							if(d.networkVlags !== null){
								for(i=0; i< d.networkVlags.length; i++){
									if (searchValue == d.networkVlags[i].vlag || searchValue == d.networkVlags[i].vlagname){
										d3.select(this).insert("image",":first-child")
											.attr("class","node-selection")
											.attr("xlink:href","assets/images/node-selection.png")
											.attr("width", 10)
											.attr("height", 10)
											.attr("x", function(d) { return d.x - 20; })
											.attr("y", function(d) { return d.y; })
											.attr("transform", "translate(-16,-18)")
											.transition()
											.attr("width", 70)
											.attr("height", 50);
									}
								}	
							}
							
							if(d.networkPorts !== null){
								for(i=0; i< d.networkPorts.length; i++){
									if (searchValue == d.networkPorts[i].description){
										d3.select(this).insert("image",":first-child")
											.attr("class","node-selection")
											.attr("xlink:href","assets/images/node-selection.png")
											.attr("width", 10)
											.attr("height", 10)
											.attr("x", function(d) { return d.x - 20; })
											.attr("y", function(d) { return d.y; })
											.attr("transform", "translate(-16,-18)")
											.transition()
											.attr("width", 70)
											.attr("height", 50);
									}
								}	
							}
							
						});
				}

			}
		});

		$("body").off("click", ".mapCustomLabel .close-icon");
		$("body").off("keypress", ".mapCustomLabel .txt");
		$("body").off("focusout", ".mapCustomLabel .txt");
		$("body").off("mouseover mouseout", ".mapCustomLabel");
		$("body").off("dblclick", ".mapCustomLabel .spanTxt");
		$("body").off("dblclick", ".mapCustomLabel .spanImg");
		$("body").off("dragstop", ".mapCustomLabel");
		$("body").off("mouseover mouseout",".linkNotificationWrapper");
		$("body").off("mouseover mouseout",".nodeNotificationWrapper");
		$("body").off("mouseover mouseout",".nodeCommentWrapper");
		$("body").off("mouseover mouseout",".nodeComment");
		$("body").off("click",".nodeComment .edit");
		$("body").off("click",".nodeComment .remove");
		$("body").off("contextmenu", ".network-map-div");
		$("body").off("click", ".network-map-div");
		$("body").off("click", ".mapCustomLabel .btnSubmit");
		$("body").off("click", ".mapCustomLabel .btnCancel");

		$scope.$on('fabric_change', function(event, newValue, oldValue, parent){
			$scope.fabric_change(event, newValue, oldValue, parent);
		});

		$scope.fabric_change = function(event, newValue, oldValue, parent){
			//console.log("in map fabric_change");
			$scope.networkCode = (newValue.networkCode ? newValue.networkCode : newValue.code);

			//$scope.fabric =  newValue;
			//$scope.device = newValue;

			$scope.newValue = newValue;
			//$scope.oldValue = oldValue;
			$rootScope.fabricNodeSelected = false;
			$scope.dataReload = false;
			//$scope.loadMap();
			if (parent) {
				$scope.user = "" + (parent.userId ? parent.userId : "");
				$scope.password = "" + (parent.password ? parent.password : "");
			}

			$scope.awaitingPortStatsPollingResponse == false;
			$scope.fabricsStatsPolling = false;
			if(typeof startPortstatsPolling !== "undefined"){
				$interval.cancel(startPortstatsPolling);
			}
		};

		$scope.$on('selectedFabricsTab', function(event) {
			if($rootScope.selectedFabricsTab == "map" && $scope.networkCode && !$scope.dataReload){
				$scope.loadMap();
			}
			if($rootScope.selectedFabricsTab == "map"){
				$rootScope.contextValue = "network_fabrics";
			}
		});

		$scope.loadMap = function(){
			if(!$rootScope.fabricNodeSelected){
			    $scope.loading = true;
				$http ({
					method: 'GET',
					//url: config.NETWORK_MAP_GET_URI + "/" + (newValue.parentId ? newValue.parentId : newValue.id)
					url: config.NETWORK_MAP_GET_URI,
					params: {
						"networkCode": $scope.networkCode
					}
				})
				.success(function(response){
					$scope.dataReload = true;
					$scope.CLIDiv = false;
					$scope.mapNodesData = response.result;
					$scope.nodes = response.result.devices;
					$scope.links = response.result.links;
					$rootScope.fabricSelected = true;
					$scope.loading = false;


					$timeout(function(){
						$scope.fabric_node_change($scope.newValue);

						for (var i=0; i< response.result.devices.length; i++) {

							$scope.name = response.result.devices[i].name;
							$scope.savedNodeX = response.result.devices[i].coordinateX;
							$scope.savedNodeY = response.result.devices[i].coordinateY;

							if(response.result.devices[i].coordinateX != 0.0 && response.result.devices[i].coordinateY != 0.0){
								response.result.devices[i].x = response.result.devices[i].coordinateX;
								response.result.devices[i].px = response.result.devices[i].coordinateX;

								response.result.devices[i].y = response.result.devices[i].coordinateY;
								response.result.devices[i].py = response.result.devices[i].coordinateY;
							}
							else{
								//console.log(response.result.devices[i]);
								d3.selectAll("g.node")
									.each(function(d, ii){
										if ($scope.name === d.name){
											$scope.saveNodePosition(response.result.devices[i]);
										}
									});
							}

							if(!$scope.savedNodeX ==  0.0 && !$scope.savedNodeY ==  0.0) {
								d3.selectAll("circle")
									.each(function(d){
										if ($scope.name === d.name){
											d3.select(this)
												.attr("transform", "translate(" + $scope.savedNodeX + "," + $scope.savedNodeY + ")")
										}
									});

								d3.selectAll("text")
									.each(function(d){
										if ($scope.name === d.name){
											d3.select(this)
												.attr("transform", "translate(" + $scope.savedNodeX + "," + $scope.savedNodeY + ")")
										}
									});

								d3.selectAll("image.fabricNode")
									.each(function(d){
										if ($scope.name === d.name){
											d3.select(this)
												.attr("x", $scope.savedNodeX)
												.attr("y", $scope.savedNodeY)
										}
									});

								d3.selectAll("image.node-selection")
									.each(function(d){
										if ($scope.name === d.name){
											d3.select(this)
												.attr("x", $scope.savedNodeX - 20)
												.attr("y", $scope.savedNodeY)
										}
									});

								d3.selectAll("g.node")
									.each(function(d, i){
										if ($scope.name === d.name){
											d.outboundLinks.forEach(onDragLink);
											d.inboundLinks.forEach(onDragLink);
										}
									});

							}
							
							var prevLink = {};
							var xx=0, yy=0;
							d3.selectAll("g line.link")
								.each(function(d, i){
									if(prevLink.source && prevLink.target && prevLink.source.code == d.source.code && prevLink.target.code == d.target.code){
										xx = xx + 4;
										if(Math.abs(d.source.y - d.target.y) < 50){
											yy = yy + 3;
										}
									}
									else{
										xx = 0;
										yy = 0;
									}
									prevLink = d;
									
									d3.select(this)
										.attr("x1", function(dl) { return dl.source.x + xx; })
										.attr("y1", function(dl) { return dl.source.y + yy; })
										.attr("x2", function(dl) { return dl.target.x + xx; })
										.attr("y2", function(dl) { return dl.target.y + yy; });
								});
							
						}


						d3.selectAll("g.node")
							.each(function(d, i){
								gNode = this;
								$scope.toggleNodeChilds(d, gNode);
							});

					}, 100);

					// startPortstatsPolling = $interval(function () {
						// if($rootScope.selectedFabricsTab == "map"
							// && $scope.awaitingPortStatsPollingResponse == false
							// && $scope.fabricsStatsPolling == true){
							// $scope.awaitingPortStatsPollingResponse = true;
							// $scope.portstatsPolling();
						// }
					// }, $scope.PortstatsPollingDuration);

					$scope.getMapObjects();

					$scope.getNodeComments();

				})
				.error(function(resp) {
					console.log(resp);
					$scope.loading = false;
				});
			}
		};

		$scope.getNodeComments = function(){
			$http ({
					method: 'GET',
					url: config.NETWORK_NODE_COMMENTS_GET_URI,
					params: {
						"networkCode": $scope.networkCode
					}
				})
				.success(function(response){
					if(response && response.result){
						$scope.nodeComments = response.result;
						$scope.setNodeComments();
					}
				})
				.error(function(resp) {
					console.log(resp);
				});
		};

		$scope.showNodeChildsDetails = function(d, gNode){
			html="<table class='data-grid' width='100%'>";
			html+="<tr>";
			html+="<th>Code</th>";
			html+="<th>Name</th>";
			html+="<th>Type</th>";
			html+="</tr>";
			for(i=0; i<d.outboundLinks.length; i++){
				if(d.outboundLinks[i].toNode.target.outboundLinks.length == 0 && d.outboundLinks[i].toNode.target.inboundLinks.length <= 1 && (d.outboundLinks[i].toNode.target.type == "STA" || d.outboundLinks[i].toNode.target.type == "")){
					for(x=0; x<$scope.links.length; x++){

						if($scope.links[x].code == d.outboundLinks[i].code){
							d3.selectAll("g.node")
								.each(function(d, i){
									if ($scope.links[x].target.name == d.name){
										html+="<tr>";
										html+="<td>"+d.code+"</td>";
										html+="<td>"+d.name+"</td>";
										html+="<td>"+d.type+"</td>";
										html+="</tr>";
									}
								});
						}
					}
				}
			}
			html+="</table>";

			ngDialog.open({
				template:
					'<div class="inner-dialog-container">'+
						'<div>'+html+'</div>'+
						'<button type="button" class="button" ng-click="closeThisDialog(0)">Close</button>'+
					'</div>',
				plain: 'true',
				showClose: false,
				closeByDocument: false,
				closeByEscape: false,
			});
		};

		$scope.toggleNodeChilds = function(d, gNode){
			var opacity = 0;
			data = d;
			var count=0;
			var prevNodeName;
			var opacity = 0;
			var nodeExpandIconAdded = false;

			for(i=0; i<data.outboundLinks.length; i++){
				if(data.outboundLinks[i].toNode.target.outboundLinks.length == 0 && data.outboundLinks[i].toNode.target.inboundLinks.length <= 1){
					if(prevNodeName != data.outboundLinks[i].toNode.target.name){
						prevNodeName = data.outboundLinks[i].toNode.target.name;
						count++;
					}
				}
			}

			if(count > $scope.minChildNodesVisible){
				for(i=0; i<data.outboundLinks.length; i++){
					if(data.outboundLinks[i].toNode.target.outboundLinks.length == 0 && data.outboundLinks[i].toNode.target.inboundLinks.length <= 1 && (data.outboundLinks[i].toNode.target.type == "STA" || data.outboundLinks[i].toNode.target.type == "")){
						if(prevNodeName != data.outboundLinks[i].toNode.target.name){
							if(nodeExpandIconAdded == false){
								nodeExpandIconAdded = true;
								d3.select(gNode).insert("image",":last-child")
									.attr("class","node-expand")
									.attr("xlink:href","assets/images/node-expand.png")
									.attr("width", 12)
									.attr("height", 12)
									.attr("x", function(d) { return d.x + 8; })
									.attr("y", function(d) { return d.y - 22; })
									.attr("style","cursor: pointer")
									.on("click", function(){
										//$scope.toggleNodeChilds(d, this.parentNode);
										$scope.showNodeChildsDetails(d, gNode.parentNode);
									});
							}
							prevNodeName = data.outboundLinks[i].toNode.target.name;
							var link = d3.select("#" + data.outboundLinks[i].type + "Path"  + data.outboundLinks[i].code);
							link.style("display", "none");

							for(x=0; x<$scope.links.length; x++){
								if($scope.links[x].code == data.outboundLinks[i].code){
									d3.selectAll("g.node")
										.each(function(d, i){
											if ($scope.links[x].target.name == d.name){
												d3.select(this).style("display", "none");
											}
										});
								}
							}
						}
					}

				}
			}

		};

		function onDragLink(d) {
			var link = d3.select("#" + d.type + "Path"  + d.code);
			if (d.type === "normalRoute") {
				link
					.attr("x1", function(d) { return d.source.x; })
					.attr("y1", function(d) { return d.source.y; })
					.attr("x2", function(d) { return d.target.x; })
					.attr("y2", function(d) { return d.target.y; });
			}
			else if (d.type === "testRoute1") {
				var diagonalFn = d3.svg.diagonal().projection(function(d) { return [d.x, d.y]; });
				link.attr("d", diagonalFn);
			}
			else {
				link.attr("d", linkArc);
			}
		}

		function linkArc(d) {
			var dx = d.target.x - d.source.x,
				dy = d.target.y - d.source.y,
				dr = Math.sqrt(dx * dx + dy * dy);
			return "M" + d.source.x + "," + d.source.y + "A" + dr + "," + dr + " 0 0,1 " + d.target.x + "," + d.target.y;
		}

		$scope.$on('fabric_node_change', function(event, newValue, oldValue, parent){
			$scope.fabric_node_change(newValue);
		});

		$scope.fabric_node_change = function(newValue){
			$rootScope.fabricNodeSelected = true;
			d3.selectAll("g.node")
				.each(function(d, i){
					if (newValue.name === d.name){

						d3.selectAll("image.node-selection")
							.transition()
							.attr("width", 10)
							.attr("height", 10)
							.remove();
						d3.select(this).insert("image",":first-child")
							.attr("class","node-selection")
							.attr("xlink:href","assets/images/node-selection.png")
							.attr("width", 10)
							.attr("height", 10)
							.attr("x", function(d) { return d.x - 20; })
							.attr("y", function(d) { return d.y; })
							.attr("transform", "translate(-16,-18)")
							.transition()
							.attr("width", 70)
							.attr("height", 50);
					}
				});
		}

		$scope.onNodeMove = function(data) {
			d3.selectAll("g.node")
				.each(function(d, i){
					if(data.code == d.code){
						d3.select(this).select("image.node-expand")
										.attr("x", function(d) { return d.x + 8; })
										.attr("y", function(d) { return d.y - 22; })

						d3.select(this).select("image.nodeCommentIcon")
										.attr("x", function(d) { return d.x - 20; })
										.attr("y", function(d) { return d.y - 25; })

						d3.select(this).select("image.nodeNotificationIcon")
										.attr("x", function(d) { return d.x + 15; })
										.attr("y", function(d) { return d.y - 10; })
					}
				});
			$scope.saveNodePosition(data);			
			
			var prevLink = {};
			var xx=0, yy=0;
			d3.selectAll("g line.link")
				.each(function(d, i){
					if(prevLink.source && prevLink.target && prevLink.source.code == d.source.code && prevLink.target.code == d.target.code){
						xx = xx + 4;
						if(Math.abs(d.source.y - d.target.y) < 50){
							yy = yy + 3;
						}
					}
					else{
						xx = 0;
						yy = 0;
					}
					prevLink = d;
					
					d3.select(this)
						.attr("x1", function(dl) { return dl.source.x + xx; })
						.attr("y1", function(dl) { return dl.source.y + yy; })
						.attr("x2", function(dl) { return dl.target.x + xx; })
						.attr("y2", function(dl) { return dl.target.y + yy; });
				});
		};

		$scope.saveNodePosition = function(data){

			var currentNodeX = data.x;
			var currentNodeY = data.y;
				
			$http ({
					method: 'POST',
					url: config.NETWORK_NODE_COORDINATES_POST_URI,
					params: {
						"networkCode": $scope.networkCode,
						"code": data.code,
						"x": currentNodeX,
						"y": currentNodeY
					}
				})
				.success(function(response){
					//$scope.nodes = response.result.devices;
					//$scope.links = response.result.links;
				})
				.error(function(resp) {
					console.log(resp);
				});
		};

		$scope.onNodeClick = function(data) {

			if($rootScope.ansibleAccess){
				if(data.id){
					if($rootScope.ctrlClick){
						//console.log("ctrl key pressed, now select the node");
						d3.selectAll("g.node")
							.each(function(d, i){
								if (data.name === d.name){
									var index = $scope.selectedNodes.indexOf(data);
									if(index == -1){
										$scope.selectedNodes.push(data);
										d3.select(this).insert("image",":first-child")
											.attr("class","node-selected")
											.attr("xlink:href","assets/images/node-selected.png")
											.attr("width", 10)
											.attr("height", 10)
											.attr("x", function(d) { return d.x - 20; })
											.attr("y", function(d) { return d.y; })
											.attr("transform", "translate(-16,-18)")
											.transition().duration(100)
											.attr("width", 70)
											.attr("height", 50);
									}
									else{
										$scope.selectedNodes.splice(index, 1);
										d3.select(this).select("image.node-selected").remove();

									}

								}
							});

					}
					else{
						d3.selectAll("g.node")
							.each(function(d, i){
								d3.selectAll("image.node-selected")
									.transition()
									.attr("width", 10)
									.attr("height", 10)
									.remove();
							});

						d3.selectAll("g.node")
							.each(function(d, i){
								if (data.name === d.name){

									$scope.selectedNodes = [];
									$scope.selectedNodes.push(data);
									d3.select(this).insert("image",":first-child")
										.attr("class","node-selected")
										.attr("xlink:href","assets/images/node-selected.png")
										.attr("width", 10)
										.attr("height", 10)
										.attr("x", function(d) { return d.x - 20; })
										.attr("y", function(d) { return d.y; })
										.attr("transform", "translate(-16,-18)")
										.transition().duration(100)
										.attr("width", 70)
										.attr("height", 50);

								}
							});
					}
				}
			}
		};

		$scope.onNodeDoubleClick = function(data) {
			$scope.showNodeDetails(data);
		};

		$scope.onNodeContextMenu = function(data, eve) {
			//console.info("onNodeContextMenu - ", data, eve.layerX, eve.layerY);
			$scope.isContextClickNode = true;
			//if($rootScope.ansibleAccess){
				if(data.id){
					if(!$rootScope.ctrlClick && $scope.selectedNodes.length < 1){
						$scope.contextNode = data;
						$("#mapContextMenu").hide();
						$("#mapUserContextMenu").hide();
						$("#nodeContextMenu").css({"top":eve.layerY+10, "left":eve.layerX+5}).show();
						//$timeout(function () {
							//$scope.isContextClickNode = false;
							//$scope.contextNode = false;
						//},10);

					}
				}
			//}
		};

		$scope.onNodeMouseOver = function(data, d3e){
			$scope.showNodeLabel(data, d3e);
		};

		$scope.showNodeLabel = function(data, d3e){
			var top = d3e.layerY-35;
			var bottom = ($(".network-map-div").height() - d3e.layerY) + 12;
			var left = d3e.layerX-20;
			var nodeLabelTooltipFound = false;
			var nodeLabelTooltipText = "";
			var nodeLabelTooltipDiv = "";

			for(x = 0; x < $scope.mapNodesData.devices.length; x++){
				if($scope.mapNodesData.devices[x].code == data.code){
					if($scope.mapNodesData.devices[x].label && $scope.mapNodesData.devices[x].label != null){
						nodeLabelTooltipFound = true;
						nodeLabelTooltipDiv = "<div class='nodeTooltip' id='"+$scope.mapNodesData.devices[x].code+"'>";
						nodeLabelTooltipDiv += "<span class='nodeComment'>"+$scope.mapNodesData.devices[x].label+"</span>";
						nodeLabelTooltipDiv += "</div>"
						nodeLabelTooltipText = nodeLabelTooltipText + nodeLabelTooltipDiv;
					}
				}
			}

			if(nodeLabelTooltipFound){
				if($("#nodeLabelTooltip_"+data.code)){
					$("#nodeLabelTooltip_"+data.code).remove();
				}
				var tooltipContainer = $(document.createElement("div"));
				tooltipContainer.attr("id","nodeLabelTooltip_"+data.code);
				tooltipContainer.attr("class","nodeTooltipWrapper");
				tooltipContainer.attr("style","top:"+top+"; left:"+left+"; position:absolute;");
				tooltipContainer.html(nodeLabelTooltipText);
				$(".network-map-div").append(tooltipContainer);
			}
		};

		$scope.setNodeComments = function(){
			var nodeCommentText = "";
			var nodeCommentsIconAdded = false;
			var prevNode="";

			d3.selectAll("image.nodeCommentIcon").remove();

			for(x=0; x<$scope.nodeComments.length; x++){
				d3.selectAll("g.node")
					.each(function(d, i){
						if ($scope.nodeComments[x].networkNodeCode === d.code){
							if(prevNode != d.code){
								prevNode = d.code;
								d3.select(this).insert("image",":last-child")
									.attr("class","nodeCommentIcon")
									.attr("xlink:href","assets/images/comment-small-icon.png")
									.attr("width", 16)
									.attr("height", 16)
									.attr("x", d.coordinateX - 20)
									.attr("y", d.coordinateY - 25)
									.attr("style","cursor: pointer")
									.on("click", function(){
										$scope.showNodeComments(d);
									}).insert("title").text("click to view comments");
							}
						}
					});
			}
		};

		$scope.showNodeComments = function(node){
			var top = node.y;
			var bottom = ($(".network-map-div").height() - node.y) + 12;
			//var bottom = node.y;
			var left = node.x - 20;
			var nodeCommentFound = false;
			var nodeCommentText = "";
			var nodeCommentDiv = "";
			for(x=0; x<$scope.nodeComments.length; x++){
				if($scope.nodeComments[x].networkNodeCode==node.code){
					nodeCommentFound = true;
					nodeCommentDiv = "<div class='nodeComment' id='"+$scope.nodeComments[x].code+"'>";
					nodeCommentDiv += "<span class='edit' title='Edit comment'></span>";
					nodeCommentDiv += "<span class='remove' title='Remove comment'></span>";
					nodeCommentDiv += "<span class='commentTime'>"+$filter('date')($scope.nodeComments[x].dateTime,"MM-dd-yyyy HH:mm:ss")+"</span>";
					nodeCommentDiv += "<span class='nodeCommentText'>"+$scope.nodeComments[x].comment+"</span>";
					nodeCommentDiv += "</div>"
					nodeCommentText = nodeCommentText + nodeCommentDiv;
				}
			}

			if(nodeCommentFound){
				if($("#nodeComment_"+data.code)){
					$("#nodeComment_"+data.code).remove();
				}
				var nodeCommentContainer = $(document.createElement("div"));
				nodeCommentContainer.attr("id","nodeComment_"+data.code);
				nodeCommentContainer.attr("class","nodeCommentWrapper");
				nodeCommentContainer.attr("style","top:"+top+"; left:"+left+"; position:absolute;");
				nodeCommentContainer.html(nodeCommentText);
				$(".network-map-div").append(nodeCommentContainer);
			}
		};

		$scope.showNodeNotifications = function(notificationNode){
			var top = notificationNode.y - 5;
			var bottom = ($(".network-map-div").height() - notificationNode.y) - 10;
			var left = notificationNode.x - 30;
			var nodeNotificationFound = false;
			var nodeNotificationText = "";
			var nodeNotificationDiv = "";

			for(var node in $scope.nodeNotifications){
				if($scope.nodeNotifications.hasOwnProperty(node)){
					if(notificationNode.code == node){
						var nodeObj = $scope.nodeNotifications[node];
						//console.log(nodeObj);
						for(x=0; x< nodeObj.length; x++){
							nodeNotificationFound = true;
							nodeNotificationDiv = "<div class='nodeNotification' id='"+nodeObj[x].code+"'>";
							nodeNotificationDiv += "<div class='notificationTime'>"+$filter('date')(nodeObj[x].createdOn,"MM-dd-yyyy HH:mm:ss")+"</div>";
							nodeNotificationDiv += "<span class='nodeNotificationText'>"+nodeObj[x].notification+"</span>";
							nodeNotificationDiv += "</div>"
							nodeNotificationText = nodeNotificationText + nodeNotificationDiv;
						}
					}

				}
			};

			if(nodeNotificationFound){
				if($("#nodeNotification_"+notificationNode.code)){
					$("#nodeNotification_"+notificationNode.code).remove();
				}
				var nodeNotificationContainer = $(document.createElement("div"));
				nodeNotificationContainer.attr("id","nodeNotification_"+notificationNode.code);
				nodeNotificationContainer.attr("class","nodeNotificationWrapper");
				nodeNotificationContainer.attr("style","top:"+top+"; left:"+left+"; position:absolute;");
				nodeNotificationContainer.html(nodeNotificationText);
				$(".network-map-div").append(nodeNotificationContainer);
			}
		};

		$scope.showLinkNotifications = function(notificationLink){
			minY = Math.min(notificationLink.target.coordinateY, notificationLink.source.coordinateY);
			maxY = Math.max(notificationLink.target.coordinateY, notificationLink.source.coordinateY);
			yPos = minY + (maxY - minY)/2;

			minX = Math.min(notificationLink.target.coordinateX, notificationLink.source.coordinateX);
			maxX = Math.max(notificationLink.target.coordinateX, notificationLink.source.coordinateX);
			xPos = minX + (maxX - minX)/2

			var top = yPos;
			var bottom = ($(".network-map-div").height() - notificationLink.y) - 10;
			var left = xPos - 30;
			var linkNotificationFound = false;
			var linkNotificationText = "";
			var linkNotificationDiv = "";

			for(var link in $scope.linkNotifications){
				if($scope.linkNotifications.hasOwnProperty(link)){
					if(notificationLink.code == link){
						var linkObj = $scope.linkNotifications[link];
						for(x=0; x< linkObj.length; x++){
							linkNotificationFound = true;
							linkNotificationDiv = "<div class='nodeNotification' id='"+linkObj[x].code+"'>";
							linkNotificationDiv += "<div class='notificationTime'>"+$filter('date')(linkObj[x].createdOn,"MM-dd-yyyy HH:mm:ss")+"</div>";
							linkNotificationDiv += "<span class='nodeNotificationText'>"+linkObj[x].notification+"</span>";
							linkNotificationDiv += "</div>"
							linkNotificationText = linkNotificationText + linkNotificationDiv;
						}
					}

				}
			};

			if(linkNotificationFound){
				if($("#linkNotification_"+notificationLink.code)){
					$("#linkNotification_"+notificationLink.code).remove();
				}
				var linkNotificationContainer = $(document.createElement("div"));
				linkNotificationContainer.attr("id","linkNotification_"+notificationLink.code);
				linkNotificationContainer.attr("class","nodeNotificationWrapper");
				linkNotificationContainer.attr("style","top:"+top+"; left:"+left+"; position:absolute;");
				linkNotificationContainer.html(linkNotificationText);
				$(".network-map-div").append(linkNotificationContainer);
			}
		};

		$("body").on("mouseover mouseout",".linkNotificationWrapper", function(e){
			if(e.type == "mouseover"){
				$(this).show();
			}else if(e.type == "mouseout"){
				$(this).hide();
			}
		});

		$("body").on("mouseover mouseout",".nodeNotificationWrapper", function(e){
			if(e.type == "mouseover"){
				$(this).show();
			}else if(e.type == "mouseout"){
				$(this).hide();
			}
		});

		$("body").on("mouseover mouseout",".nodeCommentWrapper", function(e){
			if(e.type == "mouseover"){
				$(this).show();
			}else if(e.type == "mouseout"){
				$(this).hide();
			}
		});

		$("body").on("mouseover mouseout",".nodeComment", function(e){
			if(e.type == "mouseover"){
				$(this).children(".edit, .remove").show();
			}else if(e.type == "mouseout"){
				$(this).children(".edit, .remove").hide();
			}
		});

		$("body").on("click",".nodeComment .edit", function(e){
			comment = $(this);
			$scope.commentCode = $(this).parent().attr("id");
			$scope.nodeCode = $(this).parent().parent().attr("id").split("_");
			$scope.nodeComment = $(this).parent().children(".nodeCommentText").html();

			$scope.nodeCommentEditDialog = ngDialog.open({
				template:
						'<div class="inner-dialog-container">'+
							'<div>Comments  : <br/><textarea class="txtArea" ng-model="nodeComment" ></textarea> </div>'+
							'<button type="button" class="button" ng-click="editNodeComment(nodeComment)">Ok</button> '+
							'<button type="button" class="button" ng-click="closeThisDialog(0)">Cancel</button>'+
						'</div>',
				plain: 'true',
				scope: $scope,
				className: 'ngdialog-theme-default'
			});

		});

		$scope.editNodeComment = function(nodeComment){
			if($.trim(nodeComment) == ""){
				ngDialog.open({
						template:
							'<div class="inner-dialog-container">'+
								'<div>Comment cannot be blank!</div>'+
								'<button type="button" class="button" ng-click="closeThisDialog(0)">Close</button>'+
							'</div>',
						plain: 'true'
					});
				return;
			}

			$http ({
				method: 'POST',
				url: config.NETWORK_NODE_COMMENT_POST_URI,
				params: {
					"networkCode": $scope.networkCode
				},
				data: {
					"networkNodeCode": $scope.nodeCode[1],
					"code": $scope.commentCode,
					"comment": nodeComment
				}
			})
			.success(function(response){
				ngDialog.close($scope.nodeCommentEditDialog);
				if (response) {
					var updateCommentDialog = ngDialog.open({
						template:
							'<div class="inner-dialog-container success-container">'+
								'<div>Comment saved successfully!</div>'+
							'</div>',
						plain: 'true',
						showClose: false,
						overlay: false,
						width:250
					});

					$timeout(function () {
						ngDialog.close(updateCommentDialog);
					}, 2000);
					$scope.getNodeComments();
				}
				else{

				}
			})
			.error(function(resp) {
				console.log(resp);
			});
		};

		$("body").on("click",".nodeComment .remove", function(e){
			comment = $(this);
			code = $(this).parent().attr("id");

			ngDialog.openConfirm({
				template:
					'<div class="inner-dialog-container">'+
						'<p>Are you sure you want to delete?</p>'+
						'<div class="ngdialog-buttons">'+
							'<button type="button" class="button" ng-click="closeThisDialog(0)"> No </button> '+
							'<button type="button" class="button" ng-click="confirm(1)">Yes</button>'+
						'</div>'+
					'</div>',
				plain: 'true'
			}).then(function (success) {
				$http({
					method: 'DELETE',
					url: config.NETWORK_NODE_COMMENT_DELETE_URI + "/" + code
				})
				.success(function(response){
					comment.parent().remove();
					$scope.getNodeComments();
				})
				.error(function(resp) {
					console.log(resp);
				});
			}, function (reason) {
				//console.log('confirm no');
			});
		});

		$scope.onNodeMouseOut = function(data){
			$("#nodeLabelTooltip_"+data.code).hide();
		};

		$scope.onLinkClick = function(data) {
		};

		$scope.onLinkDoubleClick = function(data) {
			$scope.showLinkDetails(data);
		};

		/*
		$scope.onMapClick = function(data){
			console.info("on map click", data);
			$scope.isContextClickNode = false;
			$("#nodeContextMenu").hide();
			if(!$rootScope.ctrlClick){
				$scope.nodesSelectionInit();
			}
		};
		*/
		/*$scope.onMapContextclick = function(data){
			//$("#nodeContextMenu").hide();

			if($scope.isContextClickNode === false){
				console.info("onMapContextclick", data);
				$scope.MapX = data.offsetX;
				$scope.MapY = data.offsetY;
				$("#nodeContextMenu").hide();
				if($scope.selectedNodes.length > 0){
					$("#mapContextMenu").css({"top":data.offsetY+20, "left":data.offsetX}).show();

				}
				else{
					if(!$scope.contextNode){
						$("#mapUserContextMenu").css({"top":data.offsetY+20, "left":data.offsetX}).show();
					}
				}
			}

		};*/

		$scope.$on('ESC-Clicked', function(event) {
			$scope.isContextClickNode = false;
			$scope.nodesSelectionInit();
		});

		$scope.nodesSelectionInit = function(){
			$scope.contextNode = "";
			$scope.selectedNodes = [];
			$(".contextMenu").hide();

			d3.selectAll("g.node")
				.each(function(d, i){
					d3.selectAll("image.node-selected")
						.transition()
						.attr("width", 10)
						.attr("height", 10)
						.remove();
				});
		};

		$scope.showBGPConfigDialog = function(){

			$("#BGPDialog").dialog({
				autoOpen: false,
				resizable: true,
				title: "Configuration",
				buttons: {
					"Save": function() {
						$(this).dialog("destroy");
					},
					"Cancel": function() {
						$(this).dialog("destroy");
					}
				},
			}).dialog('open')

		};

		$rootScope.mapDialogOpen = [];
		$scope.showNodeDetails = function(node){
			//console.log("in showNodeDetails");
			//console.log(node);
			if(node.id){
				//$scope.selectedNodeForDialog = node;
				//console.log("found node id");
				$http ({
					method: 'GET',
					url: config.NETWORK_SUMMARY_GET_URI,
					params: {
						"networkCode": $scope.networkCode,
						"switchId": node.id
					}
				})
				.success(function(response){
					if (response.result && response.result.length > 0) {
						//$scope.currentNode = response.result;
						var dialogData = {
							'node': node,
							'property': response.result[0],
							'user': $scope.user,
							'password': $scope.password,
							'port': '22'
						};
						$rootScope.mapDialogOpen[node.code] = true;
						//console.log(dialogData);
						$scope.mapDialog = ngDialog.open({
							template: './app/components/fabrics/map/map-node.dialog.htm',
							showClose: true,
							closeByDocument: false,
							closeByEscape: false,
							overlay: false,
							draggable: true,
							pinable: true,
							showMinimize: true,
							enableFullScreen: true,
							minimizedTitle: node.name,
							data: dialogData,
							scope: $scope,
							appendClassName: 'ngdialog-maps',
							width: '55%'
						});
						$scope.shouldBeFocus = true;
						$scope.mapDialog.closePromise.then(function (response) {
							// $scope.sshTerminal = false;
							// $scope.tab = '';
							$rootScope.mapDialogOpen[node.code] = false;
						});
					}
					else{
						ngDialog.open({
							template:
								'<div class="inner-dialog-container">'+
									'<div>No version and model information found for <strong>'+node.name+'</strong> </div>'+
									'<button type="button" class="button" ng-click="closeThisDialog(0)">Close</button>'+
								'</div>',
							plain: 'true'
						});
					}
				})
				.error(function(resp) {
					console.log(resp);
				});

			}
			else{
				ngDialog.open({
					template:
						'<div class="inner-dialog-container">'+
							'<div> '+node.name+' is not a fabric node.</div>'+
							'<button type="button" class="button" ng-click="closeThisDialog(0)">Close</button>'+
						'</div>',
					plain: 'true'
				});
			}
		};

		$rootScope.mapLinkDialogOpen = [];
		$scope.showLinkDetails = function(linkData){

			var sourcePorts = [];
			var targetPorts = [];
			if(linkData.code && linkData.source.id && linkData.target.id){
				//console.log($scope.links);
				for(x=0;x<$scope.links.length;x++){
					if($scope.links[x].source.code == linkData.source.code && $scope.links[x].target.code == linkData.target.code){
						sourcePorts.push($scope.links[x].sourcePort);
						targetPorts.push($scope.links[x].targetPort);
					}
				}

				linkData["sourcePorts"] = sourcePorts.join();
				linkData["targetPorts"] = targetPorts.join();

				$rootScope.mapLinkDialogOpen[linkData.code] = true;
				//console.log($rootScope.mapLinkDialogOpen[linkData.code]);
				$scope.mapLinkDialog = ngDialog.open({
					template: './app/components/fabrics/map/map-link.dialog.htm',
					showClose: true,
					closeByDocument: false,
					closeByEscape: false,
					overlay: false,
					draggable: true,
					pinable: true,
					showMinimize: true,
					minimizedTitle: "Link Traffic: " + linkData.sourcePort + " - " + linkData.targetPort,
					data: linkData,
					scope: $scope,
					appendClassName: 'ngdialog-link-maps',
					width: '80%'
				});

				$scope.mapLinkDialog.closePromise.then(function (data) {
					$rootScope.mapLinkDialogOpen[linkData.code] = false;
				});
				// $rootScope.$on('ngDialog.closed', function (e, $dialog) {
					// console.log($dialog);
					// console.log('ngDialog closed: ' + $dialog.attr('id'));
				// });

			}
			else{
				ngDialog.open({
					template:
						'<div class="inner-dialog-container">'+
							'<div> No information found for clicked link.</div>'+
							'<button type="button" class="button" ng-click="closeThisDialog(0)">Close</button>'+
						'</div>',
					plain: 'true'
				});
			}
		};

		$(".contextMenu").on("click", ".link", function(event){
			//event.stopPropagation();
			//event.preventDefault();
			$(".contextMenu").hide();
			ref = $(this).attr("ref");
			if(ref=="cTag"){
				$scope.cTagDialog = ngDialog.open({
                    template:
							'<div class="inner-dialog-container">'+
								'<div>Custom Tag : <input ng-model="customTag" /> </div>'+
								'<button type="button" class="button" ng-click="getCustomTag(customTag)">Ok</button> '+
								'<button type="button" class="button" ng-click="closeThisDialog(0)">Cancel</button>'+
							'</div>',
					plain: 'true',
					scope: $scope,
                    className: 'ngdialog-theme-default'
                });
			}
			else if(ref=="spine" || ref=="leaf"){
				$scope.setAnsibleTag(ref);
			}
			else if(ref=="bgpAutomatic"){
				$scope.bgpAutomaticConfig = {};

				$scope.bgpAutomaticDialog = ngDialog.open({
					template: './app/components/fabrics/map/map-ansible-bgp.dialog.htm',
					showClose: true,
					closeByDocument: false,
					closeByEscape: false,
					overlay: true,
					scope: $scope,
					appendClassName: 'ngdialog-ansible',
					width: '60%'
				});
			}
			else if(ref=="cRealTime"){
				startPortstatsPolling = $interval(function () {
					if($rootScope.selectedFabricsTab == "map"
						&& $scope.awaitingPortStatsPollingResponse == false
						&& $scope.fabricsStatsPolling == true){
							$scope.awaitingPortStatsPollingResponse = true;
							$scope.portstatsPolling();
					}
				}, $scope.PortstatsPollingDuration);
			}
			else if(ref=="cPin"){
				lbCount = $scope.labelCount++;
				$scope.mapObjects("new",lbCount, $scope.MapX, $scope.MapY, "",  "image");
			}
			else if(ref=="cLabel"){
				lbCount = $scope.labelCount++;
				$scope.mapObjects("new",lbCount, $scope.MapX, $scope.MapY, "",  "label");
			}
			else if(ref=="cNodeComment"){
				var tooltipText;
				$scope.nodeComment = "";

				$scope.cNodeCommentDialog = ngDialog.open({
                    template:
							'<div class="inner-dialog-container">'+
								'<div>Comments  : <br/><textarea class="txtArea" ng-model="nodeComment" ></textarea> </div>'+
								'<button type="button" class="button" ng-click="saveNodeComment(nodeComment)">Ok</button> '+
								'<button type="button" class="button" ng-click="closeThisDialog(0)">Cancel</button>'+
							'</div>',
					plain: 'true',
					scope: $scope,
                    className: 'ngdialog-theme-default'
                });
			}
			else if(ref=="cTop10App"){
				$scope.showTop10App();
			}

		});

		$scope.saveNodeComment = function(nodeComment){

			if($.trim(nodeComment) == ""){
				ngDialog.open({
						template:
							'<div class="inner-dialog-container">'+
								'<div>Comment cannot be blank!</div>'+
								'<button type="button" class="button" ng-click="closeThisDialog(0)">Close</button>'+
							'</div>',
						plain: 'true'
					});
				return;
			}

			$http ({
				method: 'PUT',
				url: config.NETWORK_NODE_COMMENT_PUT_URI,
				params: {
					"networkCode": $scope.contextNode.networkCode,
					"networkNodeCode": $scope.contextNode.code
				},
				data: {
					"comment": nodeComment
				}
			})
			.success(function(response){
				ngDialog.close($scope.cNodeCommentDialog);
				if (response) {
					var createCommentDialog = ngDialog.open({
						template:
							'<div class="inner-dialog-container success-container">'+
								'<div> Comment saved successfully!</div>'+
							'</div>',
						plain: 'true',
						showClose: false,
						overlay:false,
						width:250
					});

					$timeout(function () {
						ngDialog.close(createCommentDialog);
						$scope.contextNode = "";
					}, 2000);

					$scope.getNodeComments();
				}
				else{

				}
			})
			.error(function(resp) {
				console.log(resp);
			});
		};

		$scope.mapObjects = function(state, lblCount, cordX, cordY, txt, type, imgContent){
			var objectDiv = $(document.createElement("div"));
			objectDiv.attr("id","label_"+lblCount);
			objectDiv.attr("class","mapCustomLabel");
			objectDiv.attr("style","top:"+cordY+"; left:"+cordX+"; position:absolute;");
			objectDiv.draggable({ containment: ".network-map-div", scroll: false, stack: ".network-map-div .mapCustomLabel", cursor: "move" });

			if(type == "label"){
				input = $("<input type='text' class='txt' id='label_"+lblCount+"' value='' />");
				span = $("<span id='span_"+lblCount+"' class='spanTxt'></span>");
				closeSpan = $("<span id='close_"+lblCount+"' class='close-icon'></span>");
				objectDiv.append(input).append(span).append(closeSpan);
			}
			else if(type == "image"){
				input = $("<input type='file' class='file-txt' accept='image/*' id='label_"+lblCount+"' value='' />");
				submit = $("<input type='button' class='btnSubmit' id='btnPin_"+lblCount+"' value='Upload' />");
				pinCancel = $("<input type='button' class='btnCancel' id='btnPinCancel_"+lblCount+"' value='Cancel' />");
				img = $("<img src='' id='img_"+lblCount+"' class='spanImg' style='max-width:100px;' />");
				closeSpan = $("<span id='pinClose_"+lblCount+"' class='close-icon'></span>");
				objectDiv.append(input).append(submit).append(pinCancel).append(img).append(closeSpan);
			}

			$(".network-map-div").append(objectDiv);
			if(state=="new"){
				if(type == "label"){
					objectDiv.children(".txt").focus();
				}
				else if(type == "image"){
					objectDiv.children(".file-txt").focus();
				}
			}
			else{
				if(type == "label"){
					objectDiv.attr("refid",lblCount);
					objectDiv.children(".txt").hide();
					objectDiv.children(".spanTxt").html(txt).show();
				}
				else if(type == "image"){
					objectDiv.attr("refid",lblCount);
					objectDiv.children(".file-txt").hide();
					objectDiv.children(".btnSubmit").hide();
					objectDiv.children(".btnCancel").hide();
					objectDiv.children(".spanImg").attr("src", imgContent).show();
				}
			}
		};

		$scope.saveBGPAutomaticConfig = function(data){

			$http ({
				method: 'POST',
				url: config.ANSIBLE_BGP_AUTOMATIC_POST_URI,
				params: {
					"networkCode": $scope.selectedNodes[0].networkCode
				},
				data: {
					nodes: $scope.selectedNodes,
					vRouterName: data.vRouterName,
					sviSwitch: data.sviSwitch,
					uplinksLeaf: data.uplinksLeaf,
					routerId: data.routerId,
					sviIPAddr: data.sviIPAddr,
					l3UplinksIPAddr: data.l3UplinksIPAddr,
					asRangeFrom: data.asRangeFrom,
					asRangeTo: data.asRangeTo,
					vlanRangeFrom: data.vlanRangeFrom,
					vlanRangeTo: data.vlanRangeTo
				}
			})
			.success(function(response){
				if (response) {
					ngDialog.close($scope.bgpAutomaticDialog);
					$scope.nodesSelectionInit();
					$scope.bgpSuccessDialog = ngDialog.open({
						template:
							'<div class="inner-dialog-container success-container">'+
								'<div> BGP Automatic Configuration saved successfully!</div>'+
							'</div>',
						plain: 'true',
						showClose:false,
						overlay: false,
						width:250
					});

					$timeout(function () {
						ngDialog.close($scope.bgpSuccessDialog);
					}, 2000);


					$scope.bgpSuccessDialog.closePromise.then(function (data) {
						if(response.result && response.result.url){
							$window.open(response.result.url);
						}
					});
				}
				else{

				}
			})
			.error(function(resp) {
				console.log(resp);
			});
		};


		$("body").on("contextmenu", ".network-map-div", function(event){
			event.preventDefault();

			$scope.MapX = event.offsetX;
			$scope.MapY = event.offsetY;
			if($scope.selectedNodes.length > 0){
				$("#mapContextMenu").css({"top":event.offsetY+20, "left":event.offsetX+15}).show();

			}
			else{
				if(!$scope.contextNode){
					$("#mapUserContextMenu").css({"top":event.offsetY+20, "left":event.offsetX+15}).show();
				}
			}

		});

		$("body").on("click", ".network-map-div", function(event){
			if(!$rootScope.ctrlClick){
				$scope.nodesSelectionInit();
			}
		});


		$scope.getCustomTag = function(cTag){
			if(cTag){
				ngDialog.close($scope.cTagDialog);
				$scope.setAnsibleTag(cTag);

			}
			else{
				ngDialog.open({
				template:
					'<div class="inner-dialog-container">'+
						'<div>Custom Tag cannot be blank</div>'+
						'<button type="button" ng-click="closeThisDialog(0)">Close</button>'+
					'</div>',
				plain: 'true'
				});
			}
		};

		$scope.setAnsibleTag = function(ref){
			$http ({
				method: 'POST',
				url: config.ANSIBLE_TAG_POST_URI,
				params: {
					"networkCode": $scope.contextNode.networkCode,
					"code": $scope.contextNode.code,
					"tag": ref
				}
			})
			.success(function(response){
				if (response) {
					ngDialog.open({
						template:
							'<div class="inner-dialog-container">'+
								'<div> "' + $scope.contextNode.name + '" has been set as <strong>'+ ref +'</strong> successfully!</div>'+
								'<button type="button" class="button" ng-click="closeThisDialog(0)">Close</button>'+
							'</div>',
						plain: 'true'
					});

					$http ({
						method: 'GET',
						url: config.NETWORK_MAP_GET_URI,
						params: {
							"networkCode": $scope.networkCode
						}
					})
					.success(function(response){
						$scope.mapNodesData = response.result;
						$scope.contextNode = "";
					})
					.error(function(resp) {
					});

				}
				else{

				}
			})
			.error(function(resp) {
				console.log(resp);
			});
		};

		function getImageByDeviceType (data, severity) {
			var enabled = data.fabId && data.fabId.length > 0 ? true : false ;
			var type = data.type;
			var state = data.state;

			if (type === 'host') {
				return "./assets/images/networkImages/host.png";
			}
			else if (type === 'server') {
				return "./assets/images/networkImages/server.png";
			}
			else if (type === 'switch') {
				return "./assets/images/networkImages/switch.png";
			}
			else if (type === 'wireless_router') {
				return "./assets/images/networkImages/wireless-router-down.png";
			}
			else if (type === 'router') {
				return "./assets/images/networkImages/router.png";
			}
			else if (type === 'wan') {
				return "./assets/images/networkImages/cloud.png";
			}
			else if (type === 'pbx') {
				return "./assets/images/networkImages/pbx.png";
			}
			else if (type === 'hub') {
				return "./assets/images/networkImages/hub-unstable.png";
			}
			else if (type === 'bridge') {
				return "./assets/images/networkImages/bridge-disabled.png";
			}
			else if (type === 'firewall') {
				return "./assets/images/networkImages/firewall-vertical-up.png";
			}
			else if (type === 'server_down') {
				return "./assets/images/networkImages/server-disabled.png";
			}
			else if (type === 'lan') {
				return "./assets/images/networkImages/lan.png";
			}
			else if (/B,R/.test(type)) {
				if(severity){
					if(severity == 1){
						return "./assets/images/networkImages/router-down.png";
					}
					else if(severity == 2){
						return "./assets/images/networkImages/router-unstable.png";
					}
					else if(severity == 3){
						return "./assets/images/networkImages/router-low.png";
					}
				}
				else{
					if (enabled) {
						return "./assets/images/networkImages/router-up.png";
					}
					else {
						return "./assets/images/networkImages/router-disabled.png";
					}
				}
			}
			else if (/B,W/.test(type)) {
				if(severity){
					if(severity == 1){
						return "./assets/images/networkImages/switch-down.png";
					}
					else if(severity == 2){
						return "./assets/images/networkImages/switch-unstable.png";
					}
					else if(severity == 3){
						return "./assets/images/networkImages/switch-low.png";
					}
				}
				else{
					if (enabled) {
						return "./assets/images/networkImages/switch-up.png";
					}
					else {
						return "./assets/images/networkImages/switch-disabled.png";
					}
				}
			}
			else if (/B,W,R/.test(type)) {
				if(severity){
					if(severity == 1){
						return "./assets/images/networkImages/router-down.png";
					}
					else if(severity == 2){
						return "./assets/images/networkImages/router-unstable.png";
					}
					else if(severity == 3){
						return "./assets/images/networkImages/router-low.png";
					}
				}
				else{
					if (enabled) {
						return "./assets/images/networkImages/router-up.png";
					}
					else {
						return "./assets/images/networkImages/router-disabled.png";
					}
				}
			}
			else if (/B/.test(type)) {
				if(severity){
					if(severity == 1){
						return "./assets/images/networkImages/switch-down.png";
					}
					else if(severity == 2){
						return "./assets/images/networkImages/switch-unstable.png";
					}
					else if(severity == 3){
						return "./assets/images/networkImages/switch-low.png";
					}
				}
				else{
					if (enabled) {
						return "./assets/images/networkImages/switch-up.png";
					}
					else {
						return "./assets/images/networkImages/switch-disabled.png";
					}
				}

			}
			else if (/R/.test(type)) {
				if(severity){
					if(severity == 1){
						return "./assets/images/networkImages/router-down.png";
					}
					else if(severity == 2){
						return "./assets/images/networkImages/router-unstable.png";
					}
					else if(severity == 3){
						return "./assets/images/networkImages/router-low.png";
					}
				}
				else{
					if (enabled) {
						return "./assets/images/networkImages/router-up.png";
					}
					else {
						return "./assets/images/networkImages/router-disabled.png";
					}
				}
			}
			else if (/W/.test(type)) {
				if(severity){
					if(severity == 1){
						return "./assets/images/networkImages/access-Point-down.png";
					}
					else if(severity == 2){
						return "./assets/images/networkImages/access-Point-unstable.png";
					}
					else if(severity == 3){
						return "./assets/images/networkImages/access-Point-low.png";
					}
				}
				else{
					if (enabled) {
						return "./assets/images/networkImages/access-Point-up.png";
					}
					else {
						return "./assets/images/networkImages/access-Point-disabled.png";
					}
				}
			}
			else if (/S/.test(type)) {
				if(severity){
					if(severity == 1){
						return "./assets/images/networkImages/server-down.png";
					}
					else if(severity == 2){
						return "./assets/images/networkImages/server-unstable.png";
					}
					else if(severity == 3){
						return "./assets/images/networkImages/server-low.png";
					}
				}
				else{
					if (enabled) {
						return "./assets/images/networkImages/server-up.png";
					}
					else {
						return "./assets/images/networkImages/server-disabled.png";
					}
				}
			}
			else {
				return "./assets/images/networkImages/unknown-device.png";
			}
			return null;
		}

		$scope.portstatsPolling = function(){
			//console.log("in portstatsPolling");
			$scope.FabricsStatsBtnText = "Updating Fabrics Stats ...";

			$http({
				method: 'GET',
				url: config.NETWORK_NODE_LINK_NOTIFICATIONS_GET_URI,
				params: {
					'networkCode': $scope.networkCode,
					'maxVisibleNotifications': $scope.maxVisibleNotifications
				}
			})
			.success(function(response){

				if(response && response.result){
					//$timeout(function(){
						$scope.awaitingPortStatsPollingResponse = false;
						$scope.FabricsStatsBtnText = "Update Fabrics Stats";
						var fileName = "";
						d3.selectAll("g.node")
							.each(function(d, i){
								if(d.id){
									//console.log(d.type);
									fileName = getImageByDeviceType(d);
									d3.select(this).select("image.fabricNode").attr("xlink:href", fileName);
								}
							});

						d3.selectAll("g line.link").classed("high", false);
						d3.selectAll("g line.link").classed("medium", false);
						d3.selectAll("g line.link").classed("low", false);

						d3.selectAll("image.nodeNotificationIcon").remove();
						d3.selectAll("image.linkNotificationIcon").remove();

						$scope.nodeNotifications = response.result.nodeNotifications;
						$scope.linkNotifications = response.result.linkNotifications;

						var nodeImg = "";
						var severity=0;
						var severityClass = "";
						var nodeObj;

						for(var node in $scope.nodeNotifications){
							if($scope.nodeNotifications.hasOwnProperty(node)){
								d3.selectAll("g.node")
									.each(function(d, i){
										gNode = this;

										if(d.code == node){
											nodeObj = $scope.nodeNotifications[node];

											for(c=0; c<nodeObj.length; c++){
												var severityArr = nodeObj.map(function(d){return d.severity});
												var severity = Math.min.apply(this,severityArr);

												if(severity == 1) {
													nodeImg = getImageByDeviceType(d, severity);
													severityClass = "high";
													notificationImg ="notification-down.png";
												}
												else if(severity == 2){
													nodeImg = getImageByDeviceType(d, severity);
													severityClass = "medium";
													notificationImg ="notification-unstable.png";
												}
												else if(severity == 3){
													nodeImg = getImageByDeviceType(d, severity);
													severityClass = "low";
													notificationImg ="notification-low.png";
												}

												d3.select(gNode).select("image.fabricNode").attr("xlink:href", nodeImg);

												d3.select(gNode).select("image.nodeNotificationIcon").remove();

												d3.select(gNode).insert("image")
													.attr("class","nodeNotificationIcon " + severityClass)
													.attr("xlink:href","assets/images/"+notificationImg)
													.attr("width", 16)
													.attr("height", 16)
													.attr("x", d.x + 15)
													.attr("y", d.y - 10)
													.attr("style","cursor: pointer")
													.on("click", function(){
														$scope.showNodeNotifications(d);
													}).insert("title").text("click to view node notifications");

											}
										}
									});

							}
						};

						for(var link in $scope.linkNotifications){
							if($scope.linkNotifications.hasOwnProperty(link)){
								d3.selectAll("g line.link")
									.each(function(d, i){
										gLink = this;

										if(d.code == link){
											//console.log(gLink);
											linkObj = $scope.linkNotifications[link];

											for(c=0; c<linkObj.length; c++){
												var severityArr = linkObj.map(function(d){return d.severity});
												var severity = Math.min.apply(this,severityArr);

												if(severity == 1) {
													severityClass = "high";
													notificationImg ="notification-down.png";
												}
												else if(severity == 2){
													severityClass = "medium";
													notificationImg ="notification-unstable.png";
												}
												else if(severity == 3){
													severityClass = "low";
													notificationImg ="notification-low.png";
												}

												d3.select(gLink).classed(severityClass, true);

												d3.select(gLink.parentNode).select("image[id='"+d.code+"']").remove();
												
												minY = Math.min(d.target.coordinateY, d.source.coordinateY);
												maxY = Math.max(d.target.coordinateY, d.source.coordinateY);
												yPos = minY + (maxY - minY)/2;

												minX = Math.min(d.target.coordinateX, d.source.coordinateX);
												maxX = Math.max(d.target.coordinateX, d.source.coordinateX);
												xPos = minX + (maxX - minX)/2

												d3.select(gLink.parentNode).insert("image")
													.attr("id", d.code)
													.attr("class","linkNotificationIcon " + severityClass)
													.attr("xlink:href","assets/images/"+notificationImg )
													.attr("width", 16)
													.attr("height", 16)
													.attr("x", xPos)
													.attr("y", yPos)
													.attr("style","cursor: pointer")
													.on("click", function(){
														$scope.showLinkNotifications(d);
													}).insert("title").text("click to view link notifications");

											}
										}
									});

							}
						};

					//},5000);
				}
				else if(response.message){
					ngDialog.open({
						template:
							'<div class="inner-dialog-container">'+
								'<div> "' + response.message + '" </div>'+
								'<button type="button" class="button" ng-click="closeThisDialog(0)">Close</button>'+
							'</div>',
						plain: 'true'
					});
					$scope.awaitingPortStatsPollingResponse = false;
					$scope.FabricsStatsBtnText = "Update Fabrics Stats";
				}

			})
			.error(function(resp) {
				$scope.awaitingPortStatsPollingResponse = false;
				$scope.FabricsStatsBtnText = "Update Fabrics Stats";
				console.log(resp);
			});
		};

		$("body").on("mouseover mouseout", ".mapCustomLabel", function(e){

			if(e.type == "mouseover"){
				$(this).children(".close-icon").show();
			}else if(e.type == "mouseout"){
				$(this).children(".close-icon").hide();
			}
		});

		$("body").on("click", ".mapCustomLabel .close-icon", function(e){
			lblDiv = this;
			lblCode=$(this).parent().attr("refid");
				ngDialog.openConfirm({
					template:
							'<div class="inner-dialog-container">'+
								'<p>Are you sure you want to delete?</p>'+
								'<div class="ngdialog-buttons">'+
									'<button type="button" class="button" ng-click="closeThisDialog(0)"> No </button> '+
									'<button type="button" class="button" ng-click="confirm(1)">Yes</button>'+
								'</div>'+
							'</div>',
					plain: 'true'
				}).then(function (value) {
						$(lblDiv).parent().remove();
						if(lblCode){
							$scope.removeLabel(lblCode);
						}
				}, function (reason) {
					//console.log('confirm no');
				});
		});

		$("body").on("focusout", ".mapCustomLabel .txt", function(e){

			if($(this).parent().attr("refid")){
				$(this).hide();
				$(this).parent().children(".spanTxt").show();
			}
			else{
				if($(this).val() == ""){
					$(this).parent().remove();
				}
			}
		});

		$("body").on("keypress", ".mapCustomLabel .txt", function(e){
			//console.log(e.type);
			//console.log(e.which);
			var keycode = (e.keyCode ? e.keyCode : e.which);
			if(keycode == 13) {
				e.preventDefault();

				if($(this).val() == "" && $(this).parent().attr("refid")){
					txt = this;
					ngDialog.openConfirm({
						template:
								'<div class="inner-dialog-container">'+
								'<div> If label is kept blank, the label will be removed, <br/>Are you sure you want to remove the label</div>'+
								'<button type="button" class="button" ng-click="confirm()">Yes</button>'+
								' <button type="button" class="button" ng-click="closeThisDialog(0)">No</button>'+
								'</div>',
						plain: 'true'
					}).then(function (value) {
						$(txt).parent().remove();
						lblCode=$(this).parent().attr("refid");
						if(lblCode){
							$scope.removeLabel(lblCode);
						}
					}, function (reason) {
						//console.log('confirm no');
					});

				}
				else{
					$(this).hide();
					$(this).parent().children(".spanTxt").html($(this).val()).show().focus();
					lblId = $(this).attr("id").split("_");
					lblCode = $(this).parent().attr("refid");
					lblTxt=$(this).val();
					lblX=$(this).parent().css("left");
					lblY=$(this).parent().css("top");
					$scope.saveLabel(lblId[1], lblCode, lblTxt, lblX, lblY);

				}
			}

		});

		$("body").on("dblclick", ".mapCustomLabel .spanTxt", function(e){
			$(this).hide();
			$(this).parent().children(".txt").val($(this).html()).show().focus();
		});

		$("body").on("dblclick", ".mapCustomLabel .spanImg", function(e){
			$(this).hide();
			$(this).parent().children(".file-txt").show();
			$(this).parent().children(".btnSubmit").show();
			$(this).parent().children(".btnCancel").show();
		});

		$("body").on("dragstop", ".mapCustomLabel", function(e){
			inputType = $(this).children("input").attr('type');
			if (inputType == "text"){
				lblId = $(this).attr("id").split("_");
				lblCode = $(this).attr("refid");
				lblTxt = $(this).children(".spanTxt").html();
				lblX = $(this).css("left");
				lblY = $(this).css("top");
				$scope.saveLabel(lblId[1], lblCode, lblTxt, lblX, lblY);
			}
			else if (inputType == "file"){
				inputFile = $(this).children(".file-txt");
				pinId = $(inputFile).attr("id").split("_");
				pinCode = $(inputFile).parent().attr("refid");
				imgData = $(this).children(".spanImg").attr("src");
				pinX = $(inputFile).parent().css("left");
				pinY = $(inputFile).parent().css("top");
				$scope.savePin(pinId[1], pinCode, imgData, pinX, pinY);
			}
		});

		$scope.saveLabel = function(lblId, lblCode, lblTxt, lblX, lblY){
			lblId=lblId
			code=lblCode;
			lblX = lblX.substring(0, lblX.length - 2);
			lblY = lblY.substring(0, lblY.length - 2);
			if(code){
				$http({
					method: 'POST',
					url: config.MAP_OBJECT_POST_URI,
					data: {
						'networkCode': $scope.networkCode,
						'code': code,
						'type': "label",
						'label': lblTxt,
						'coordinateX': lblX,
						'coordinateY': lblY
					}
				})
				.success(function(response){

				})
				.error(function(resp) {
					console.log(resp);
				});
			}
			else{
				$http({
					method: 'PUT',
					url: config.MAP_OBJECT_PUT_URI,
					params: {
						'networkCode': $scope.networkCode
					},
					data: {
						'type': "label",
						'label': lblTxt,
						'coordinateX': lblX,
						'coordinateY': lblY
					}
				})
				.success(function(response){
					if(response){
						$("#label_"+lblId).attr("refid",response.code);
					}
				})
				.error(function(resp) {
					console.log(resp);
				});
			}
		};

		$scope.removeLabel = function(lblCode){
			$http({
				method: 'DELETE',
				url: config.MAP_OBJECT_DELETE_URI + "/" + lblCode
			})
			.success(function(response){

			})
			.error(function(resp) {
				console.log(resp);
			});
		};

		$scope.getMapObjects = function(){

			$(".mapCustomLabel").remove();

			$http({
				method: 'GET',
				url: config.MAP_OBJECT_GET_URI,
				params: {
					'networkCode': $scope.networkCode
				}
			})
			.success(function(response){
				if(response && response.result){
					for(i=0; i< response.result.length; i++){
						$scope.mapObjects("render",response.result[i].code, response.result[i].coordinateX, response.result[i].coordinateY, response.result[i].label, response.result[i].type, response.result[i].file);
						$scope.labelCount=response.result[i].code+1;
					}

				}
			})
			.error(function(resp) {
				console.log(resp);
			});
		};

		$("body").on("click", ".mapCustomLabel .btnSubmit", function(e){

			inputFile = $(this).parent().children(".file-txt");
			inputCancel = $(this).parent().children(".btnCancel");

			var ext = $(inputFile).val().split('.').pop().toLowerCase();
			if($.inArray(ext, ['gif','png','jpg','jpeg']) == -1) {
				ngDialog.open({
					template:
						'<div class="inner-dialog-container">'+
							'<div>File type not supported!</div>'+
						'</div>',
					plain: 'true',
					showClose: true,
					closeByDocument: true,
					closeByEscape: true,
				});
				return;
			};

			var size = parseFloat(inputFile[0].files[0].size / 1024).toFixed(2);
			if(size > 200) {
				ngDialog.open({
					template:
						'<div class="inner-dialog-container">'+
							'<div>Image size is ' +size+' KB.</div>'+
							'<div>Size must not exceed 200 KB.</div>'+
						'</div>',
					plain: 'true',
					showClose: true,
					closeByDocument: false,
					closeByEscape: true,
				});
				return;
			};

			if($(inputFile).val() == ""){
				txt = inputFile;
					ngDialog.openConfirm({
						template:
								'<div class="inner-dialog-container"><div>If label is kept blank, the label will be removed, <br/>Are you sure you want to remove the label</div>'+
								'<button type="button" class="button" ng-click="confirm()">Yes</button>'+
								' <button type="button" class="button" ng-click="closeThisDialog(0)">No</button></div>',
						plain: 'true'
					}).then(function (value) {
						$(txt).parent().remove();
						pinCode=$(inputFile).parent().attr("refid");
						if(pinCode){
							$scope.removeLabel(pinCode);
						}
					}, function (reason) {
						//console.log('confirm no');
					});
			}
			else{
				$(inputFile).hide();
				$(inputCancel).hide();
				$(this).hide();
				pinId = $(inputFile).attr("id").split("_");
				pinCode = $(inputFile).parent().attr("refid");
				pinX=$(inputFile).parent().css("left");
				pinY=$(inputFile).parent().css("top");

				var reader = new FileReader();
				reader.onload = function(e) {
					imgData = e.target.result;
					$scope.savePin(pinId[1], pinCode, imgData, pinX, pinY);
				}
				reader.readAsDataURL(inputFile[0].files[0]);

			}
		});

		$("body").on("click", ".mapCustomLabel .btnCancel", function(e){
			lblCode = $(this).parent().attr("refid");
			if(lblCode) {
				$(this).parent().children(".file-txt").hide();
				$(this).parent().children(".btnSubmit").hide();
				$(this).parent().children(".btnCancel").hide();
				$(this).parent().children(".spanImg").show();
			}
			else{
				$(this).parent().remove();
			}
		});

		$scope.savePin = function(pinId, pinCode, imgData, pinX, pinY){

			pinId=pinId
			code=pinCode;

			pinX = pinX.substring(0, pinX.length - 2);
			pinY = pinY.substring(0, pinY.length - 2);
			if(code){
				$http({
					method: 'POST',
					url: config.MAP_OBJECT_POST_URI,
					data: {
						'networkCode': $scope.networkCode,
						'code': code,
						'type': "image",
						'file': imgData,
						'coordinateX': pinX,
						'coordinateY': pinY
					}
				})
				.success(function(response){
					$("#label_"+pinId).children('.spanImg').attr("src", imgData).show();
				})
				.error(function(resp) {
					console.log(resp);
				});
			}
			else{
				$http({
					method: 'PUT',
					url: config.MAP_OBJECT_PUT_URI,
					params: {
						'networkCode': $scope.networkCode
					},
					data: {
						'type': "image",
						'file': imgData,
						'coordinateX': pinX,
						'coordinateY': pinY
					}
				})
				.success(function(response){
					if(response){
						$("#label_"+pinId).attr("refid",response.code);
						$("#label_"+pinId).children('.spanImg').attr("src", imgData).show();
					}
				})
				.error(function(resp) {
					console.log(resp);
				});
			}
		};

		$scope.updateFabricsStats = function(){
			//console.log("updateFabricsStats");
			$scope.awaitingPortStatsPollingResponse = true;
			$scope.portstatsPolling();
		};
		
		$scope.showTop10App = function(){
			$http ({
				method: 'GET',
				url: config.TOP_10_APP_GET_URI,
				params: {
					"networkCode": $scope.contextNode.networkCode,
					"networkNodeCode": $scope.contextNode.code
				}
			})
			.success(function(response){
				if (response && response.result) {
					ngDialog.open({
						template:'<div style="padding: 5px;"><div class="drag-header"><h3 class="title" style="border-bottom:none;" >Top 10 Application for '+$scope.contextNode.name+'</h3></div><iframe height="90%" width="100%" frameborder="0" allowfullscreen src='+response.result.url+'></iframe></div>',
						plain: true,
						showClose: true,
						closeByDocument: false,
						closeByEscape: false,
						overlay: true,
						draggable: true,
						pinable: true,
						showMinimize: true,
						enableFullScreen: true,
						minimizedTitle: "Top 10 Application for " + $scope.contextNode.name,
						scope: $scope,
						appendClassName: 'ngdialog-maps',
						width: '55%'
					});
				}
				else{

				}
			})
			.error(function(resp) {
				console.log(resp);
			});
		};

		if($rootScope.selectedFabricsTab == "map" && $scope.networkCode && !$scope.dataReload){
			$scope.fabric_change('', $rootScope.newValue, $rootScope.oldValue, $rootScope.parent);
			$scope.loadMap();
		}
		if($rootScope.selectedFabricsTab == "map"){
			$rootScope.contextValue = "network_fabrics";
		}
	}
]);
