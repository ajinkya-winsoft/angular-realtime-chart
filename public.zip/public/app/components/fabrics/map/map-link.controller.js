VCF.controller('MapLinkController', ['$scope', '$rootScope', '$http', 'SharedDataService', 'FabricsDataService', 'config', '$timeout', 'ngDialog', '$interval',
	function($scope, $rootScope, $http, SharedDataService, FabricsDataService, config, $timeout, ngDialog, $interval) {
		$scope.maplinkcontroller = "in maplinkcontroller";
		//console.log("in MapLinkController");
		//console.log($scope.ngDialogData);

		$scope.linkSourcedata = [];
		$scope.labelsLinkSource = [];
		$scope.seriesLinkSource = [];
		$scope.portSourceDataMap = {};

		$scope.linkTargetdata = [];
		$scope.labelsLinkTarget = [];
		$scope.seriesLinkTarget = [];
		$scope.portTargetDataMap = {};

		$scope.statslinkTrafficSourceFilter = "ibytes";
		$scope.statslinkTrafficTargetFilter = "ibytes";

		$scope.awaitingLinkResponse = false;
		$scope.awaitingTargetResponse = false;

		//$scope.startLinkChart;
		var startTargetChart;

		$scope.showSourceChart = true;
		$scope.showTargetChart = true;
		$scope.colors = ['#45b7cd', '#ff6384', '#ff8e72', '#FFD572', '#B1FF72', '#72FF9F', '#72A8FF', '#9872FF', '#EA72FF', '#A672FF'];

		//console.log($rootScope.mapLinkDialogOpen[$scope.ngDialogData.code]);
		$scope.showLinkChart = function(){
			if(typeof $scope.startLinkChart !== "undefined"){
				$interval.cancel($scope.startLinkChart);
			}
			$scope.startLinkChart = $interval(function () {
				if ($scope.awaitingLinkResponse === false
					&& $rootScope.mapLinkDialogOpen[$scope.ngDialogData.code]
				) {
					$scope.awaitingLinkResponse = true;
					//$scope.getLinkTrafficChartData();
				}
			}, 1000);
		};



		$scope.refreshlinkTrafficSourceFilter = function(statslinkTrafficSourceFilter){
			$scope.statslinkTrafficSourceFilter = statslinkTrafficSourceFilter;
			$scope.chartSeries[0].data = [];
		};

		$scope.refreshlinkTrafficTargetFilter = function(statslinkTrafficTargetFilter){
			$scope.statslinkTrafficTargetFilter = statslinkTrafficTargetFilter;
				$scope.chartSeriesT[0].data = [];
		};

		$scope.showLinkChart();
		/******************************************************************************************/
		 Highcharts.setOptions({
	        global: {
	            useUTC: false
	        }
    	});
		 $scope.chartSeries = [
			 {
					 name: 'Random data',
					 data: (function () {
							 // generate an array of random data
							 var data = [],
									 time = (new Date()).getTime(),
									 i;

							 for (i = -999; i <= 0; i += 1) {
									 data.push([
											 time + i * 1000,
											 Math.round(Math.random() * 100)
									 ]);
							 }
							 return data;
					 }()),
					 type: 'line',
                yAxis: 0,
                tooltip: {
                    valueSuffix: ' sec'
                },
                color: '#c680ca'
			 }
		];
		$scope.chartSeriesT = [
				 {"name": "Some data", "data": [],showInNavigator: true}
		];
		$scope.chartConfig = {
			options: {
            subtitle: {
                text: 'Click and drag to zoom in.'
            },
            chart: {
                backgroundColor: 'transparent',
                zoomType: 'x',
                type : 'stockchart',
                resetZoomButton: {
                    position: {
                        x: 0,
                        y: -35
                    },
                    theme: {
                        fill: 'white',
                        stroke: 'silver',
                        r: 0,
                        states: {
                            hover: {
                                fill: '#41739D',
                                style: {
                                    color: 'white'
                                }
                            }
                        }
                    }
                }
            },
            navigator: {
                enabled: true,
                // series: {
                //     data: []
                // }
            },
            rangeSelector: {
               enabled: true,
                        selected: 0,
                    //  allButtonsEnabled: true,
                buttons: [{
                    count: 1,
                    type: 'minute',
                    text: '1M'
                }, {
                    count: 2,
                    type: 'minute',
                    text: '2M'
                }, {
                    type: 'all',
                    text: 'All'
                }]

            },
            plotOptions: {
                series: {
                    lineWidth: 1,
                    fillOpacity: 0.5

                },
                column: {
                    stacking: 'normal'
                },
                area: {
                    stacking: 'normal',
                    marker: {
                        enabled: false
                    }
                }

            },
            exporting: false,
            xAxis: [{
                type: 'datetime'
            }],
            yAxis: [

                { // Primary yAxis

                    min: 0,
                    allowDecimals: false,
                    title: {
                        text: 'number of notification',
                        style: {
                            color: '#80a3ca'
                        }
                    },
                    labels: {
                        format: '{value}',
                        style: {
                            color: '#80a3ca'
                        }
                    }


                },
                { // Secondary yAxis
                    min: 0,
                    allowDecimals: false,
                    title: {
                        text: 'usage time',
                        style: {
                            color: '#c680ca'
                        }
                    },
                    labels: {
                        format: '{value}',
                        style: {
                            color: '#c680ca'
                        }
                    },
                    opposite: true

                }
            ],

            legend: {
                enabled: false
            },
            title: {
                text: ' '
            },
            credits: {
                enabled: false
            },

            loading: false,
            tooltip: {
                crosshairs: [
                    {
                        width: 1,
                        dashStyle: 'dash',
                        color: '#898989'
                    },
                    {
                        width: 1,
                        dashStyle: 'dash',
                        color: '#898989'
                    }
                ],
                headerFormat: '<div class="header">{point.key}</div>',
                pointFormat: '<div class="line"><div class="circle" style="background-color:{series.color};float:left;margin-left:10px!important;clear:left;"></div><p class="country" style="float:left;">{series.name}</p><p>{point.y:,.0f} {series.tooltipOptions.valueSuffix} </p></div>',
                borderWidth: 1,
                borderRadius: 5,
                borderColor: '#a4a4a4',
                shadow: false,
                useHTML: true,
                percentageDecimals: 2,
                backgroundColor: "rgba(255,255,255,.7)",
                style: {
                    padding: 0
                },
                shared: true

            },
            useHighStocks: true

        },
				size: {
					width: 400,
					height: 200
				},
				series: $scope.chartSeries,
				func : function(){
  						$interval(function() {
								$http({
										method: 'POST',
										url: config.PORT_STATS_LINK_POST_URI,
										params: {
											"networkCode": $scope.networkCode
										},
										data: {
											"sourceCode": $scope.ngDialogData.source.code,
											"sourcePorts": $scope.ngDialogData.sourcePort,
											"targetCode": $scope.ngDialogData.target.code,
											"targetPorts": $scope.ngDialogData.targetPort
										}
									})
									.success(function(response){

										$scope.awaitingLinkResponse = false;

										if (!response.result || !response.result.sourceData) {
											return;
										}

										var statsSource = response.result.sourceData;
										var statsTarget = response.result.targetData;
										var MAXIMUM_X_AXIS_UNIT = 10;

										var keysSource = [];
										$scope.seriesLinkSource = [];
										$scope.linkSourcedata = [];

										var keysTarget = [];
										$scope.seriesLinkTarget = [];
										$scope.linkTargetdata = [];

										/***Target data***/
										if (statsSource && statsSource.length > 0) {
											$scope.showSourecChart = true;
											for (var i=0; i<statsSource.length; i++) {
												var keySource = ''+ statsSource[i].port;

												if ($scope.portSourceDataMap[keySource]) {
													if ($scope.portSourceDataMap[keySource].length >= MAXIMUM_X_AXIS_UNIT) {
														$scope.portSourceDataMap[keySource] = $scope.portSourceDataMap[statsSource[i].port].slice(1);
													}
												}
												else {
													$scope.portSourceDataMap[keySource] = [];
													xAxes = [];
												}

												$scope.portSourceDataMap[keySource].push(statsSource[i]);

												keysSource.push(keySource);

											//	$scope.seriesLinkSource.push('Port #' + keySource);
											$scope.chartSeries[i].name = ('Port #'+ keysSource);
											}

											if ($scope.labelsLinkSource.length > (MAXIMUM_X_AXIS_UNIT-1)) {
												$scope.labelsLinkSource = $scope.labelsLinkSource.slice(1);
											}

											var d = new Date();
											var time = ('0'+d.getHours()).slice(-2) + ':' + ('0'+d.getMinutes()).slice(-2) + ':' + ('0'+d.getSeconds()).slice(-2);
											$scope.labelsLinkSource.push(time);

											for (var i=0; i < keysSource.length; i++) {
													 var data = $scope.portSourceDataMap[keysSource[i]].map(function(d){return d[$scope.statslinkTrafficSourceFilter]});
																				if($scope.chartSeries[i].data.length >300){
																								$scope.chartSeries[i].data.splice(0,1);
																								//$scope.chartConfig.getHighcharts().series;
																								//$scope.chartConfig2.getHighcharts().series[i].addPoint([new Date().getTime() ,Number(data[0])],true,true);
																								$scope.chartSeries[i].data.push([new Date().getTime() ,Number(data[0])]);
																							}else{
																									$scope.chartSeries[i].data.push([new Date().getTime() ,Number(data[0])]);
																							}



												// $scope.linkSourcedata.push(data);
											}
										}
										else{
											$scope.showSourceChart = false;
										}
									})
									.error(function(resp) {
										$scope.awaitingLinkResponse = false;
										console.log(resp);
									});

							}, 1000);
				}
			};
// configuration for 2nd chart goes here
$scope.chartConfig2 = {
		options: {
			chart: {
				type: 'spline',
				//animation: Highcharts.svg,
				zoomType: 'x',
				panning: true,
				panKey: 'shift'
			},
			plotOptions: {
				series: {
						lineWidth: 1
				}
			},
			rangeSelector: {
						selected: 1
				},
			scrollbar: {
					enabled: true
			},
			legend: {
					 enabled: false
			 },
		},
		title: {
			text: ''
		},
		exporting: false,
		navigator: {
			enabled: true
		},
		rangeSelector: {
			selected: 2
		},
		useHighStocks: false,
		credits: {
			enabled: false
		},
		loading: false,
		size: {
			width: 400,
			height: 200
		},
		xAxis: {
			type: 'datetime',
			tickPixelInterval: 10,
		},
		yAxis: {
			title: {text: ''}
		},
		series: $scope.chartSeriesT,
		func : function(){
					$interval(function() {
								$http({
										method: 'POST',
										url: config.PORT_STATS_LINK_POST_URI,
										params: {
											"networkCode": $scope.networkCode
										},
										data: {
											"sourceCode": $scope.ngDialogData.source.code,
											"sourcePorts": $scope.ngDialogData.sourcePort,
											"targetCode": $scope.ngDialogData.target.code,
											"targetPorts": $scope.ngDialogData.targetPort
										}
									})
									.success(function(response){

										$scope.awaitingLinkResponse = false;

										if (!response.result || !response.result.sourceData) {
											return;
										}

										var statsSource = response.result.sourceData;
										var statsTarget = response.result.targetData;
										var MAXIMUM_X_AXIS_UNIT = 10;

										var keysSource = [];
										$scope.seriesLinkSource = [];
										$scope.linkSourcedata = [];

										var keysTarget = [];
										$scope.seriesLinkTarget = [];
										$scope.linkTargetdata = [];

										/***Target data***/
										if (statsTarget && statsTarget.length > 0) {
											$scope.showTargetChart = true;
											for (var i=0; i<statsTarget.length; i++) {
												var keyTarget = ''+ statsTarget[i].port;

												if ($scope.portTargetDataMap[keyTarget]) {
													if ($scope.portTargetDataMap[keyTarget].length >= MAXIMUM_X_AXIS_UNIT) {
														$scope.portTargetDataMap[keyTarget] = $scope.portTargetDataMap[statsTarget[i].port].slice(1);
													}
												}
												else {
													$scope.portTargetDataMap[keyTarget] = [];
													xAxes = [];
												}

												$scope.portTargetDataMap[keyTarget].push(statsTarget[i]);

												keysTarget.push(keyTarget);

											//	$scope.seriesLinkTarget.push('Port #' + keyTarget);
											$scope.chartSeriesT[i].name = ('Port #'+ keyTarget);
											}

											if ($scope.labelsLinkTarget.length > (MAXIMUM_X_AXIS_UNIT-1)) {
												$scope.labelsLinkTarget = $scope.labelsLinkTarget.slice(1);
											}

											var d = new Date();
											var time = ('0'+d.getHours()).slice(-2) + ':' + ('0'+d.getMinutes()).slice(-2) + ':' + ('0'+d.getSeconds()).slice(-2);
											$scope.labelsLinkTarget.push(time);

											for (var i=0; i < keysTarget.length; i++) {
													 var data = $scope.portTargetDataMap[keysTarget[i]].map(function(d){return d[$scope.statslinkTrafficTargetFilter]});
																							if($scope.chartSeriesT[i].data.length >300){
																								//$scope.chartSeries[i].data.shift();
																								//$scope.chartConfig.getHighcharts().series;
																								$scope.chartConfig2.getHighcharts().series[i].addPoint([new Date().getTime() ,Number(data[0])],true,true);
																							}else{
																									$scope.chartSeriesT[i].data.push([new Date().getTime() ,Number(data[0])]);
																							}



												// $scope.linkTargetdata.push(data);
											}
										}
										else{
											$scope.showTargetChart = false;
										}
									})
									.error(function(resp) {
										$scope.awaitingLinkResponse = false;
										console.log(resp);
									});
					}, 1000);
		}
	};

		/*****************************************************************************************/
	}
]);
