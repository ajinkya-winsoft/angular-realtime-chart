VCF.controller('VlansController', ['$scope', '$rootScope', '$http', 'config', '$filter', 'ContextSearchService',
	function($scope, $rootScope, $http, config, $filter, ContextSearchService) {
		
		$scope.networkCode;
		$scope.showVlans = false;
		$scope.dataReload = false;
		$rootScope.fabricSelected = false;
		$scope.isDataFound = false;
		$scope.vlanList = [];
		
		$scope.$on('text_search', function(){
			if($rootScope.selectedFabricsTab == "vlans" && $scope.vlanList){ 
				var searchValue =  ContextSearchService.getData();
				if (searchValue == '') {
					$scope.gridOptions.data = $scope.vlanList;
				}
				else {
					$scope.gridOptions.data = $filter('filter')($scope.vlanList, searchValue, undefined);
				}
			}
        });
		
		$scope.columns = [
			// {name: ' ', width: 30,
			// cellTemplate: '<span ng-show="row.entity.extendFirstHopGateways == 0"><i class="fa fa-times">test33</i></span>' +
			// '<span ng-show="row.entity.extendFirstHopGateways > 0" class="cursor"' +
			// 'ng-click="grid.api.expandable.toggleRowExpansion(row.entity)">' + 
				// '<i ng-hide="row.isExpanded" class="fa fa-plus">test</i>' + 
				// '<i ng-show="row.isExpanded" class="fa fa-minus">test111</i>' +
			// '</span>'},
			{name: 'id', displayName: 'VLAN', width:70},
			{name: 'type', displayName: 'Type', width:70},
			{name: 'scope', displayName: 'Scope', width:70},
			{name: 'description', displayName: 'Description', width:100},
			{name: 'active', displayName: 'Active', width:70},
			{name: 'ports', displayName: 'Ports'}		
		]
		
		var paginationOptions = {
			pageNumber: 1,
			pageSize: 10
		}
		
		$scope.gridOptions = {
			enableCellEdit: false,
			enableSorting: true,
			enableGridMenu: true,
			enableColumnResizing: true,
			paginationPageSizes: [15, 25, 30],
			paginationPageSize: 15,
			columnDefs: $scope.columns,
			expandableRowHeight: 0,
			expandableRowTemplate: './app/components/fabrics/vlans/vlans.subgrid.view.htm',
			//enableExpandableRowHeader: false,
			onRegisterApi: function(gridApi) {
				$scope.gridApi = gridApi;
				gridApi.expandable.on.rowExpandedStateChanged($scope,function(row){
					if(row.entity.firstHopGateways) {
						row.expandedRowHeight = (row.entity.firstHopGateways.length * 30) + 30;
					}
					else {
						row.expandedRowHeight = 55;
					}
				});

				gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize){
					paginationOptions.pageNumber = newPage;
					paginationOptions.pageSize = pageSize;
					$scope.load();
				});
			}
		};
		
		$scope.$on('fabric_change', function(event, newValue, oldValue, parent) {			
			$scope.networkCode = (newValue.networkCode ? newValue.networkCode : newValue.code);
			$scope.dataReload = false;
			$rootScope.selectedSwitchId = newValue.id; 
		});
		
		$scope.$on('fabric_node_change', function(event, newValue, oldValue, parent){
			$rootScope.selectedSwitchId = newValue.id;
			if(newValue.networkCode && (newValue != oldValue)){
				$scope.load();
			}
		});
		
		$scope.$on('selectedFabricsTab', function(event) {
			if($rootScope.selectedFabricsTab == "vlans" && $scope.networkCode  && !$scope.dataReload){
				$scope.load();
			}
			if($rootScope.selectedFabricsTab == "vlans"){
				$rootScope.contextValue = "network_vlans";
			}
		});
		
		$scope.load = function() {
			$scope.loading = true;
			$http ({
					method: 'GET',
					url: config.VLANS_GET_URI,
					params: {
						"pageNumber": paginationOptions.pageNumber, 
						"pageSize" : paginationOptions.pageSize,
						"networkCode": $scope.networkCode,
						"switchId": $rootScope.selectedSwitchId
					}
				})
				.success(function (response) {
					if(!response.result || response.result.length === 0 ) {
						$scope.loading = false;
						$scope.isDataFound = true;
						$scope.showVlans = false;
						$rootScope.fabricSelected = true;
					}
					else { 
						for(i = 0; i < response.result.length; i++){
						response.result[i].extendFirstHopGateways = {
							columnDefs: [ 
								{name: 'vrouterName', displayName: 'vRouter Name'},
								{name: 'ip', displayName: 'IP'},
								{name: 'netmask', displayName: 'Netmask'},
								{name: 'nic', displayName: 'NIC'},
								{name: 'nicState', displayName: 'NIC State'},
								{name: 'vrrpState', displayName: 'VRRP State'}
							],
							rowStyle: function(row){
								if(row.entity.vrrpState === "master"){
									return 'greenbg';
								}
								else if(row.entity.vrrpState === "slave") {
									return 'orangebg';
								}
							},
							rowTemplate : '<div ng-class="grid.options.rowStyle(row)"><div ng-repeat="(colRenderIndex, col) in colContainer.renderedColumns track by col.uid" ui-grid-one-bind-id-grid="rowRenderIndex + \'-\' + col.uid + \'-cell\'" ng-class="{ \'ui-grid-row-header-cell\': col.isRowHeader}" class="ui-grid-cell" role="{{col.isRowHeader ? \'rowheader\' : \'gridcell\'}}" ui-grid-cell></div></div>',
							data: response.result[i].firstHopGateways
						}
					}
					$scope.gridOptions.data = response.result;
					
					$scope.vlanList = response.result;
					$scope.showVlans = true;
					$scope.isDataFound = false;
					$scope.loading = false;
					$scope.dataReload = true;
					$rootScope.fabricSelected = true;
					}
				})
				.error(function(resp) {
					console.log(resp);
					$scope.loading = false;
				});
		};
		
		$scope.refresh = function(){
			$scope.load();
		};
		
		if($rootScope.selectedFabricsTab == "vlans" && $scope.networkCode  && !$scope.dataReload){
			$scope.load();
		}
		if($rootScope.selectedFabricsTab == "vlans"){
			$rootScope.contextValue = "network_vlans";
		}
	}
]);