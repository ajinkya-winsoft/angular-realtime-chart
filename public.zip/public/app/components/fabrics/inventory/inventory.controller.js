VCF.controller('InventoryController', ['$scope', '$rootScope', '$http', 'config', 'ngDialog', '$filter', 'ContextSearchService',
	function($scope, $rootScope, $http, config, ngDialog, $filter, ContextSearchService) {
		
		$scope.networkCode;
		$scope.hardware = [];
		$scope.software = [];
		$scope.license = [];
		$scope.transceivers = [];
		$scope.data = [];
		$scope.inventoryList = [];
		$scope.dataReload == false
		$rootScope.fabricSelected = false;
		
		$scope.$on('text_search', function(){
			if($rootScope.selectedFabricsTab == "inventory" && $scope.inventoryList){
				var searchValue =  ContextSearchService.getData();
				if (searchValue == '') {
					$scope.items = $scope.inventoryList;
				}
				else {
					$scope.items = $filter('filter')($scope.inventoryList, searchValue, undefined);
				}
			}
        });
		
		$scope.$on('fabric_change', function(event, newValue, oldValue, parent){
			$scope.networkCode = (newValue.networkCode ? newValue.networkCode : newValue.code);
			$rootScope.selectedSwitchId = newValue.id;
			$scope.dataReload = false;
		});
		
		$scope.$on('fabric_node_change', function(event, newValue, oldValue, parent){
			$rootScope.selectedSwitchId = newValue.id;
			if(newValue.networkCode && (newValue != oldValue)){
				$scope.loadInventory();
				$scope.dataReload = false;
			}
		});
		
		$scope.$on('selectedFabricsTab', function(event) {			
			if($rootScope.selectedFabricsTab == "inventory" && $scope.networkCode && !$scope.dataReload){
				$scope.loadInventory();
			}
			if($rootScope.selectedFabricsTab == "inventory"){
				$rootScope.contextValue = "network_inventory";
			}
		});
		
		$scope.loadInventory = function(){
			$scope.loading = true;
			$http ({
				method: 'GET',
				url: config.INVENTORY_GET_URI,
				params: {
					"networkCode": $scope.networkCode,
					"switchId": $rootScope.selectedSwitchId
				}
			})
			.success(function(response){
				$scope.items = response.result;
				$scope.inventoryList = response.result;
				$scope.dataReload = true;
				$rootScope.fabricSelected = true;
				$scope.loading = false;
			})
			.error(function(resp) {
				console.log(resp);
				$scope.loading = false;
			});
		};
		
		$scope.openInventory = function () {
			$scope.currentInventory = this.item;
			
			$scope.inventoryDialog = ngDialog.open({
				template: './app/components/fabrics/inventory/inventory.dialog.htm',
				showClose: true,
				closeByDocument: false,
				closeByEscape: false,
				scope: $scope,
				width: '50%'
			});
		};
		
		if($rootScope.selectedFabricsTab == "inventory" && $scope.networkCode && !$scope.dataReload){
			$scope.loadInventory();
		}
		if($rootScope.selectedFabricsTab == "inventory"){
			$rootScope.contextValue = "network_inventory";
		}
	}
])