var CONTEXT_SEARCH_POST_URI = "data/context-search.json";

var MENUS_GET_URI = "data/menu.json";
var FABRICS_GET_URI = "data/fabrics.json";
var NETWORK_MAP_GET_URI = "data/network-map.json";

var INTERFACES_GET_URI = "data/switch-ports.json";
var SEARCH_INTERFACES_POST_URI = "data/interfaces.json";

var SWITCHES_GET_URI = "data/switches.json";
var INVENTORY_GET_URI = "data/inventory.json";
var SUMMARY_GET_URI = "data/network-summary.json";
var LIVE_TRAFFIC_GET_URI = "data/live-traffic.json";
var PORT_STATS_CONSOLIDATED_GET_URI = "data/port-stats-consolidated.json";

var PORT_STATS_ALL_GET_URI = "data/port-stats-all.json";

var PORT_STATS_LINK_POST_URI = "data/port-stats-link.json";

var VLANS_STATS_POST_URI = "data/vlan-stats.json";

var SWITCH_PORTS_GET_URI = "data/switch-ports.json";
var SWITCH_PORT_STATS_POST_URI = "data/live-traffic.json";

var SWITCH_NAMES_GET_URI = "data/switch-names.json";

var VLANS_GET_URI = "data/vlans.json";

var LOGS_POST_URI = "data/logs.json";

var SYSTEM_STATS_GET_URI = "data/system-stats.json";

var NETWORK_SUMMARY_GET_URI = "data/network-summary.json";

var NOTIFICATIONS_GET_URI = "data/notification.json";
var NOTIFICATION_PUT_URI = "data/success.json";
var NOTIFICATION_POST_URI = "data/success.json";
var NOTIFICATION_DELETE_URI = "data/success.json";

var NOTIFICATION_TYPE_GET_URI = "data/notification-type.json";

var SEED_DEVICES_GET_URI = "data/seed-device.json";
var SEED_DEVICE_PUT_URI = "data/success.json";
var SEED_DEVICE_POST_URI = "data/success.json";
var SEED_DEVICE_DELETE_URI = "data/success.json";

var SSH_COMMAND_POST_URI = "data/sshOutput.json";

var NETWORK_NODE_COORDINATES_POST_URI = "data/network-map.json";

var ANSIBLE_TAG_POST_URI = "data/success.json";

var ANSIBLE_BGP_AUTOMATIC_POST_URI = "data/success.json";

var MAP_OBJECT_POST_URI = "data/success.json";
var MAP_OBJECT_PUT_URI = "data/success.json";
var MAP_OBJECT_GET_URI = "data/network-objects.json";
var MAP_OBJECT_DELETE_URI = "data/success.json";

var NETWORK_NODE_COMMENT_POST_URI = "data/success.json";
var NETWORK_NODE_COMMENT_PUT_URI = "data/success.json";
var NETWORK_NODE_COMMENTS_GET_URI = "data/network-node-comments.json";
var NETWORK_NODE_COMMENT_DELETE_URI = "data/success.json";

var NETWORK_NODE_LINK_NOTIFICATIONS_GET_URI = "data/node-link-notifications.json";

var APPLICATION_VERSION_INFORMATION_GET_URI = "data/application-version-information.json";

var ANSIBLE_MODULES_GET_URI = "data/ansible-modules.json";
var ANSIBLE_YML_FILE_PATH_URI = "data/ansible-ymls";
var ANSIBLE_YML_POST_URI = "data/success.json";
var ANSIBLE_YML_EXECUTE_POST_URI = "data/success.json";

var TOP_10_APP_GET_URI = "data/success.json";

var ZTP_FILE_UPLOAD_POST_URI = "data/success.json";