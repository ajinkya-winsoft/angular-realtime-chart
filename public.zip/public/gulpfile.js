var gulp = require('gulp');
var useref = require('gulp-useref');
var uglify = require('gulp-uglify');
var gulpIf = require('gulp-if');
//var gutil = require('gulp-util');

gulp.task('vcf-client-compile', function(){    // �useref� is the task name
	console.log('starting js minification...');
	return gulp.src('*.html')
		.pipe(useref())
		// Minifies only if it's a JavaScript file
		.pipe(gulpIf('*.js', uglify()))
		.on('end', function(){ console.log('js minification completed.'); console.log('copying files.'); })
		.pipe(gulp.dest('dist'))
		.pipe(gulp.dest('../static'))
		.on('end', function(){ console.log('files copied.'); })
});