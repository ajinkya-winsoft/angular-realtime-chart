var VCF = angular.module('VCFClient', ['ngAnimate','ui.bootstrap', 'winsoft.treeWidget', 'winsoft.loaderWidget', 'winsoft.map', 'winsoft.typeahead', 'winsoft.enterDirective', 'ui.router', 'TreeWidget', 'ui.grid', 'ui.grid.pagination', 'ui.grid.edit', 'ui.grid.autoResize', 'ui.grid.rowEdit', 'ui.grid.cellNav', 'ngDialog', 'ui.grid.resizeColumns', 'chart.js','angularjs-datetime-picker', 'autocomplete', 'ui.grid.expandable', 'ui.grid.pinning','highcharts-ng']);

VCF.config(['$stateProvider', '$urlRouterProvider', function($stateProvider, $urlRouterProvider) {
	$urlRouterProvider.otherwise('/fabrics');
	$stateProvider
		.state('fabrics', {
			url: '/fabrics',
			displayName: "Fabric",
			isParent: true,
			hasTabs: true,
			cssClass: "fa-share-alt",
			views: { 'app':  { templateUrl: './app/components/fabrics/fabrics.view.htm', controller: 'FabricsController' } }
		})
		.state('fabrics.map', {
			url: '/map',
			displayName: "Map",
			parent: 'fabrics',
			views: { 'fabric':  { templateUrl: './app/components/fabrics/map/map.view.htm' } },
			tab: 'map'
		})
		.state('fabrics.interfaces', {
			url: '/interfaces',
			displayName: "Interfaces",
			parent: 'fabrics',
			views: { 'fabric':  { templateUrl: './app/components/fabrics/switch-interfaces/switch-interfaces.view.htm' } },
			tab: 'interfaces'
		})
		.state('fabrics.switches', {
			url: '/switches',
			displayName: "Switches",
			parent: 'fabrics',
			views: { 'fabric':  {templateUrl: './app/components/fabrics/switches/switches.view.htm'}},
			tab: 'switches'
		})
		.state('fabrics.liveTraffic', {
			url: '/liveTraffic',
			displayName: "Live Traffic",
			parent: 'fabrics',
			views: { 'fabric':  {templateUrl: './app/components/fabrics/live-traffic/live-traffic.view.htm'}},
			tab: 'liveTraffic'
		})
		.state('fabrics.vlans', {
			url: '/networks',
			displayName: "Networks",
			parent: 'fabrics',
			views: { 'fabric':  {templateUrl: './app/components/fabrics/vlans/vlans.view.htm'}},
			tab: 'networks'
		})
		.state('fabrics.alarms', {
			url: '/alarms',
			displayName: "Alarms/Logs",
			parent: 'fabrics',
			views: { 'fabric':  {templateUrl: './app/components/fabrics/alarms/alarms.view.htm'}},
			tab: 'alarms'
		})
		.state('fabrics.inventory', {
			url: '/inventory',
			displayName: "Inventory",
			parent: 'fabrics',
			views: { 'fabric':  {templateUrl: './app/components/fabrics/inventory/inventory.view.htm'}},
			tab: 'inventory'
		})
		.state('fabrics.ansibleAutomation', {
			url: '/ansibleAutomation',
			displayName: "Automation",
			parent: 'fabrics',
			views: { 'fabric':  {templateUrl: './app/components/fabrics/ansible-automation/ansible-automation.view.htm'}},
			tab: 'ansibleAutomation'
		})
		.state('notifications', {
			url: '/notifications',
			displayName: "Notifications",
			cssClass: "fa-bullhorn",
			isParent: true,
			//views: { 'app':  { template: '<ui-view/>' } }
			views: { 'app':  { templateUrl: './app/components/notifications/notification.view.htm' } }
		})
		/* comment to hide the notification sub menu
		.state('notifications.list', {
			url: '/list',
			displayName: "Notification",
			parent: 'notifications',
			templateUrl: './app/components/notifications/notification.view.htm'
		})
		.state('notifications.errors', {
			url: '/errors',
			displayName: "errors",
			parent: 'notifications',
			templateUrl: './app/components/notifications/errors.view.htm'
		})
		.state('notifications.traps', {
			url: '/traps',
			displayName: "traps",
			parent: 'notifications',
			templateUrl: './app/components/notifications/traps.view.htm'
		})
		*/
		.state('settings', {
			url: '/settings',
			displayName: "Settings",
			cssClass: "fa-cog",
			isParent: true,
			//views: { 'app':  { template: '<ui-view/>' } }
			views: { 'app':  { templateUrl: './app/components/settings/seed-devices/seed-device.view.htm' } }
		});
		/* comment to hide the settings sub menu
		.state('settings.seed', {
			url: '/seedswitch',
			displayName: "Seed Switch",
			parent: 'settings',
			templateUrl: './app/components/settings/seed-devices/seed-device.view.htm',
			tab: 'seed'
		})
		.state('settings.config', {
			url: '/configuration',
			displayName: "Configuration",
			parent: 'settings',
			templateUrl: './app/components/settings/seed-devices/seed-device.view.htm',
			tab: 'config'
		});
		*/
}]);

VCF.controller('homeController', ['$scope', '$rootScope', '$window', '$state', '$timeout',
	function($scope, $rootScope, $window, $state, $timeout) {
		$scope.keyCode;
		$rootScope.ctrlClick = false;
		$scope.onResize = function() {
            var headerHeight = angular.element(document.getElementsByClassName('header')).prop('clientHeight');
			//console.log(headerHeight);
            var mainContainerHeight = $window.innerHeight - headerHeight - 12;
			angular.element(document.getElementsByClassName('main-container')).height(mainContainerHeight);
        }
		$scope.onResize();
        angular.element($window).bind('resize', function() {
            $scope.onResize();
        });
		
		$scope.keyboardEventDown = function($event){
			$scope.keyCode = window.event ? $event.keyCode : $event.which;
			
			if($scope.keyCode == 17){
				$rootScope.ctrlClick = true;
			}
			
			if($scope.keyCode == 27){
				$rootScope.$broadcast("ESC-Clicked");
			}
		};
		
		$scope.keyboardEventUp = function($event){
			$scope.keyCode = window.event ? $event.keyCode : $event.which;
			if($scope.keyCode == 17){
				$rootScope.ctrlClick = false;
			}
		};
		
		$rootScope.$state = $state;
		$rootScope.$on("$stateChangeSuccess", function (event, toState, toParams, fromState, fromParams) {
			// console.info("===== activeTab $stateChangeSuccess():  "
				// + "The state being transitioned to: ", toState, " ; "
				// + "The current state, pre-transition: ", fromState, " ; "
			// );
			//$rootScope.searchValue = "";
			
			var toStateName = toState.name.split(".")[0],
				fromStateName = fromState.name.split(".")[0];
			
			if (toStateName !== fromStateName) {
				// if main module name is different, then load submodules
				// console.info("toStateName - " , toState);
				// console.info("fromStateName - " , fromState);
				// console.info("$state.get() - " , $state.get());
				if(toState.parent || toState.hasTabs){
					$rootScope.tabs = $state.get().filter(function (v) {
						//console.log(v.name);
						v.active = v.name == toStateName;
						return v.parent && v.name.indexOf(toStateName) !== -1
					});
				}
			} else if (toStateName === fromStateName && toState.name !== fromState.name) {
				// transition between same parent state.
				// console.log($rootScope.tabs);
				$rootScope.tabs.forEach(function(tab, index) {
					
					if(tab.name == toState.name){
						//console.log("toState.name - " + toState.name);
						tab.active = toState.name;
						
						//console.log("setting selectedFabricsTab");
						$rootScope.selectedFabricsTab = toState.name.split(".")[1];
						//console.log("boadcasting selectedFabricsTab");
						$rootScope.$broadcast('selectedFabricsTab');
						
					}
				});
			}
			
		});
		
		// $scope.tabSelected = function(tabName){
			// console.log("tabSelected - " + tabName);
			// $state.go(tabName)
		// };
	}
]);