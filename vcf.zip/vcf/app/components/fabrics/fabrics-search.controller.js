VCF.controller('FabricsSearchController', ['$scope', '$http', 'SharedDataService', 'FabricsDataService', 'config', '$rootScope',
	function($scope, $http, SharedDataService, FabricsDataService, config, $rootScope){
		$scope.selectedMenu = SharedDataService.getContext().menu;

		$http ({
			method: 'GET',
			url: config.FABRICS_GET_URI,
			params: {"param1": "xx1"}
		})
		.success(function(response){
			if (response.result && response.result.fabrics) {
				var len = response.result.fabrics.length;
				for(var i = 0; i < len; i++){
					response.result.fabrics[i].expanded = true;
				}

				$scope.fabricList= response.result.fabrics;
			}
		})
		.error(function(resp) {
			console.log(resp);
		});
		/*
		$scope.$on('selection-changed', function (e, node) {
			FabricsDataService.setCurrentFabric(node);
			$scope.selectedFabric = node;
		});
		*/
		
		$scope.onSelectNode = function($event) {
			var rootScope = $scope;
			var currentScope = angular.element($event.target).scope();
			var node = currentScope.node;
			var parentNode;
			
			do {
				parentNode = currentScope.node;
				currentScope = currentScope.$parent;
			} while(currentScope.$id !== rootScope.$id);
			
			FabricsDataService.setCurrentFabric(node, parentNode);
			$scope.selectedFabric = node;
			$rootScope.selectedSwitchId = node.id;
		};
	}
]);