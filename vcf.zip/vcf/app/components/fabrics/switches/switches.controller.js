VCF.controller('SwitchesController', ['$scope', '$rootScope', '$http', 'config', '$filter', 'ngDialog', 'ContextSearchService',
	function($scope, $rootScope, $http, config, $filter, ngDialog, ContextSearchService) {

		$scope.networkCode;
		$scope.fabId;
		$scope.switchesList = [];
		$scope.dataReload == false;
		$rootScope.fabricSelected = false;
		
		$scope.$on('text_search', function(){
			if($rootScope.selectedFabricsTab == "switches" && $scope.switchesList) {
				var searchValue =  ContextSearchService.getData();
				if (searchValue == '') {
					$scope.items = $scope.switchesList;
				}
				else {
					$scope.items = $filter('filter')($scope.switchesList, searchValue, undefined);
				}
			}
        });
		
		$scope.$on('fabric_change', function(event, newValue, oldValue, parent){
			$scope.networkCode = (newValue.networkCode ? newValue.networkCode : newValue.code);
			$scope.fabId = newValue.fabId;
			$rootScope.selectedSwitchId = newValue.id;
			$scope.dataReload = false;
		});
		
		$scope.$on('fabric_node_change', function(event, newValue, oldValue, parent){
			$rootScope.selectedSwitchId = newValue.id;
			if(newValue.networkCode && (newValue != oldValue)){
				$scope.loadSwitches();
			}
		});
		
		$scope.$on('selectedFabricsTab', function(event) {		
			if($rootScope.selectedFabricsTab == "switches" && $scope.networkCode && $scope.fabId && !$scope.dataReload){
				$scope.loadSwitches();
			}
			if($rootScope.selectedFabricsTab == "switches"){
				$rootScope.contextValue = "network_nodes";
			}
		});
		
		$scope.loadSwitches = function(){
			$scope.loading = true;
			$http ({
				method: 'GET',
				url: config.SWITCHES_GET_URI,
				params: {
					"networkCode": $scope.networkCode,
					"fabId": $scope.fabId,
					"switchId": $rootScope.selectedSwitchId,
					"state": "online"
				}
			})
			.success(function(response){
				$scope.items = response.result;
				$scope.switchesList = response.result;
				$scope.dataReload = true;
				$rootScope.fabricSelected = true;
				$scope.loading = false;
			})
			.error(function(resp) {
				console.log(resp);
				$scope.loading = false;
			});
		};
			
		$scope.openSwitch = function () {
			$scope.currentSwitch = this.item;
			$scope.switchDialog = ngDialog.open({
				template: './app/components/fabrics/switches/switch.dialog.htm',
				showClose: true,
				closeByDocument: false,
				closeByEscape: false,
				scope: $scope
			});
		};
		
		if($rootScope.selectedFabricsTab == "switches" && $scope.networkCode && $scope.fabId && !$scope.dataReload){
			$scope.loadSwitches();
		}
		if($rootScope.selectedFabricsTab == "switches"){
			$rootScope.contextValue = "network_nodes";
		}
	}
])