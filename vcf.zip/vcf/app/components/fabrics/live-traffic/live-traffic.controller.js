VCF.controller('LiveTrafficController', ['$scope', '$rootScope', '$http', 'config', '$interval', '$filter', '$timeout', 'ngDialog',
	function($scope, $rootScope, $http, config, $interval, $filter, $timeout, ngDialog) {

		$scope.refresh_rate = 1;
		$scope.hideSwitches = true;
		$scope.hideChart = true;
		$scope.hideCurrentSwitchPorts = true;
		$scope.isActivePortsFound = false;
		$scope.networkCode;
		$scope.fabId;
		$scope.dataReload == false;
		$rootScope.fabricSelected = false;
		$scope.allPortsSelected = false;

		$scope.showChangeSwitchBtn = false;
		$scope.showChangeSwitchDropdown = false;

		$scope.currentData = {};
		$scope.statsDataFilter = "ierrs";
		$scope.statsDataFilter2 = "oerrs";
		$scope.statsDataFilter3 = "ibytes";
		$scope.statsDataFilter4 = "obytes";
		var startChart;

		$scope.awaitingResponse = false;

		$scope.labels = [];
		$scope.series = [];
		$scope.data = [];
		$scope.data2 = [];
		$scope.data3 = [];
		$scope.data4 = [];
		$scope.portDataMap = {};
		$scope.currentSwitchPort;
		$scope.currentSwitch;

		$scope.options = {
			animation: {
				duration: 0
			},
			elements: {
				line: {
					borderWidth: 1,
					fill: false
				},
				point: {
					radius: 3
				}
			},
			legend: {
				display: true,
				labels : {
						fontSize:10,
						boxWidth : 20,
					}
			},
			scales: {
				xAxes: [{
					display: true,
					ticks: {
							fontSize: 10
					}
				}],
				yAxes: [{
					display: true,
					stacked: true,
					ticks:{
						fontSize: 10,
						min: 0,
						callback: function (value) {
							var val=value.toString();
							val = value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
							if(val.indexOf(".")>0){
								temp = val.split(".");
								val = temp[0] + "." + temp[1].slice(0,1);
							}
							return val;
						}
					}
				}],
				gridLines: {
					display: true
				}
			},
			tooltips: {
				enabled: true
			}
		};

		$scope.$on('fabric_change', function(event, newValue, oldValue, parent){
			$scope.networkCode = (newValue.networkCode ? newValue.networkCode : newValue.code);
			var oldNetworkCode = oldValue && oldValue.networkCode;
			oldNetworkCode = oldNetworkCode || null;
			$scope.fabId = newValue.fabId;
			if(!$rootScope.newValue.id && oldNetworkCode==null){ // we are directly clicking on switch first time
					$scope.dataReload = true;
					$scope.loadLiveTraffic();
			}
			else{
				if($scope.networkCode != oldNetworkCode){ // we are clicking on diffeent switch and also selectig on diffrent fabric.
						if(typeof $rootScope.newValue.id=="undefined") // we are changing fabric * not clicking on switch*
							$scope.dataReload = false;
						else
							$scope.dataReload = true;
					}
				else{
					$scope.dataReload = false; // we are clicking on different fabric *not selecting any switch*
				}
			}
			if(typeof startChart !== "undefined"){
				$interval.cancel(startChart);
			}
			if($rootScope.newValue.id){
					$scope.showChart($rootScope.newValue);
			}
		});

		$scope.$on('fabric_node_change', function(event, newValue, oldValue, parent){
			if(newValue.networkCode && (newValue != oldValue)){

				if($scope.currentSwitch && $scope.currentSwitch.networkCode == newValue.networkCode && $scope.currentSwitch.code == newValue.code){

				}
				else{
					$scope.showChangeSwitchDropdown = false;
					$scope.allPortsSelected = false;
					$scope.hideChart = true;
					$rootScope.fabricSelected = true;
					$scope.selectedPorts = [];
					if(typeof startChart !== "undefined"){
						$interval.cancel(startChart);
					}
					$scope.showChart(newValue);
				}
			}
		});

		$scope.$on('selectedFabricsTab', function(event) {
			if($rootScope.selectedFabricsTab == "liveTraffic" && $scope.networkCode && !$scope.dataReload){
				$scope.loadLiveTraffic();
			}
			if($rootScope.selectedFabricsTab == "liveTraffic"){
				$rootScope.contextValue = "network_port_stats";
			}
		});

		$scope.loadLiveTraffic = function(){

			//if(startChart){
			//	$scope.hideSwitches = true;
			//}else{
				$scope.switches = [];
				$scope.selectedPorts = [];
				$scope.series = [];
				$scope.data = [];
				$scope.data2 = [];
				$scope.data3 = [];
				$scope.data4 = [];
				$scope.portDataMap = {};

				$scope.hideChart = true;
				$scope.loading = true;
				$http ({
					method: 'GET',
					url: config.SWITCHES_GET_URI,
					params: {
						"networkCode": $scope.networkCode,
						"fabId": $scope.fabId,
						"state": "online"
					}
				})
				.success(function(response){
					$scope.switches = response.result;
					$scope.hideSwitches = false;
					$scope.dataReload = true;
					$rootScope.fabricSelected = true;
					$scope.loading = false;
				})
				.error(function(resp) {
					console.log(resp);
					$scope.loading = false;
				});
			//}
		};

		$scope.showChart = function(swth) {
			$scope.hideSwitches = true;
			$scope.hideChart = false;

			$scope.currentSwitch = swth;
			$scope.switchList = swth;
			$scope.currentSwitchPort = "";
			$scope.allPortsSelected = false;
			$scope.getCurrentSwitchPort();
			$rootScope.fabricSelected = true;

			startChart = $interval(function () {
				if ( $scope.selectedPorts
					&& $scope.awaitingResponse === false
					&& $scope.selectedPorts.length > 0
					&& $rootScope.selectedFabricsTab == 'liveTraffic'
					) {
					$scope.awaitingResponse = true;
					$scope.getLiveChartData();
				}
			}, $scope.refresh_rate * 1000);
		};

		$scope.changeSwitch = function(swth){
			$scope.showChangeSwitchDropdown = false;
			$scope.hideChart = true;
			$scope.selectedPorts = [];
			if(typeof startChart !== "undefined"){
				$interval.cancel(startChart);
			}

			if(swth){
				$scope.showChart(swth);
			}
		};

		$scope.$on('ESC-Clicked', function(event) {
			$scope.showChangeSwitchDropdown = false;
		});

		$scope.refreshRateChange = function(){
			if($scope.refresh_rate < 1){
				$scope.refresh_rate = 1;
			}
			if(typeof startChart !== "undefined"){
				$interval.cancel(startChart);
			}
			startChart = $interval(function () {
				if ( $scope.selectedPorts
					&& $scope.awaitingResponse === false
					&& $scope.selectedPorts.length > 0
					&& $rootScope.selectedFabricsTab == 'liveTraffic'
					) {
					$scope.awaitingResponse = true;
					$scope.getLiveChartData();
				}
			}, $scope.refresh_rate * 1000);
		}

		$scope.showSwitches = function() {
			$scope.hideSwitches = false;
			$scope.hideChart = true;
			$scope.selectedPorts = [];
			if(typeof startChart !== "undefined"){
				$interval.cancel(startChart);
			}
		};

		var d = new Date();
		var initialStartTime =  d.getHours() + ':' + d.getMinutes() + ':' + (d.getSeconds() - 10);
		var currentTime =  d.getHours() + ':' + d.getMinutes() + ':' + d.getSeconds();
		var startTime="", endTime="";
		$scope.selectedPorts = [];

		$scope.selectPorts = function(selectPort) {
			$scope.port = this.currentPort.port;
			selectPort.toggled = !selectPort.toggled;
			var index = $scope.selectedPorts.indexOf($scope.port);
			if(index == -1){
				$scope.selectedPorts.push($scope.port);
				if(startTime==""){
					startTime = initialStartTime;
				}
				else{
					startTime = endTime;
				}

				if(endTime==""){
					endTime = currentTime;
				}
				else{
					var _tempd = new Date();
					endTime = _tempd.getHours() + ':' + _tempd.getMinutes() + ':' + _tempd.getSeconds();
				}
			}
			else{
				$scope.selectedPorts.splice(index, 1);
			}

			if($scope.selectedPorts.length == $scope.currentSwitchPort.length){
				$scope.allPortsSelected = true;
			}
			else{
				$scope.allPortsSelected = false;
			}
		}

		$scope.selectAllPorts = function(){
			$timeout(function() {
				angular.element('.button-port').trigger('click');
				$scope.allPortsSelected = true;
			}, 0);
		}

		$scope.deselectAllPorts = function(){
			$timeout(function() {
				angular.element('.active-port').trigger('click');
				$scope.allPortsSelected = false;
			}, 0);
		}

		$scope.getLiveChartData = function() {
			$http({
				method: 'POST',
				url: config.SWITCH_PORT_STATS_POST_URI,
				params: {
					'networkCode': $scope.currentSwitch.networkCode
				},
				data: {
					'ports': $scope.selectedPorts.toString(),
					'startTime': startTime,
					'endTime': endTime,
					'code': $scope.currentSwitch.code
				}
			})
			.success(function(response){

				$scope.awaitingResponse = false;

				if (!response || !response.result || !$scope.selectedPorts) {
					return;
				}

				var stats = response.result;
				var MAXIMUM_X_AXIS_UNIT = 10;

				var keys = [];
				$scope.series = [];
				$scope.data = [];
				$scope.data2 = [];
				$scope.data3 = [];
				$scope.data4 = [];

				for (var i=0; i<stats.length && i < $scope.selectedPorts.length; i++) {
					var key = ''+ stats[i].port;
					if ($scope.portDataMap[key]) {
						if ($scope.portDataMap[key].length >= MAXIMUM_X_AXIS_UNIT) {
							$scope.portDataMap[key] = $scope.portDataMap[stats[i].port].slice(1);
						}
					}
					else {
						$scope.portDataMap[key] = [];
						xAxes = [];
					}

					$scope.portDataMap[key].push(stats[i]);
					keys.push(key);

					$scope.series.push(key);
				}

				if ($scope.labels.length > (MAXIMUM_X_AXIS_UNIT-1)) {
					$scope.labels = $scope.labels.slice(1);
				}

				var d = new Date();
				var time = ('0'+d.getHours()).slice(-2) + ':' + ('0'+d.getMinutes()).slice(-2) + ':' + ('0'+d.getSeconds()).slice(-2);
				$scope.labels.push(time);

				for (var i=0; i < keys.length; i++) {
					var data = $scope.portDataMap[keys[i]].map(function(d){return d[$scope.statsDataFilter]});
					$scope.data.push(data);

					var data2 = $scope.portDataMap[keys[i]].map(function(d){return d[$scope.statsDataFilter2]});
					$scope.data2.push(data2);

					var data3 = $scope.portDataMap[keys[i]].map(function(d){return d[$scope.statsDataFilter3]});
					$scope.data3.push(data3);

					var data4 = $scope.portDataMap[keys[i]].map(function(d){return d[$scope.statsDataFilter4]});
					$scope.data4.push(data4);
				}
			})
			.error(function(resp) {
				$scope.awaitingResponse = false;
				console.log(resp);
			});
		}

		$scope.getCurrentSwitchPort = function() {
			$scope.loading = true;
			$http ({
					method: 'GET',
					url: config.SWITCH_PORTS_GET_URI,
					params: {
						"switchId": $scope.currentSwitch.id,
						"networkCode": $scope.networkCode,
						"enable": "enable"
					}
			})
			.success(function(response){
				if(response && response.result && response.result.length !== 0){
					$scope.currentSwitchPort = response.result;
					$scope.loading = false;
					$scope.hideCurrentSwitchPorts = false;
					$scope.isActivePortsFound = false;
				}
				else if (response && response.result && response.result.length === 0) {
					$scope.loading = false;
					$scope.hideCurrentSwitchPorts = true;
					$scope.isActivePortsFound = true;
				}
				else if(response.message){
					$scope.isActivePortsFound = false;
					$scope.loading = false;
					ngDialog.open({
						template:
							'<div class="inner-dialog-container">'+
								'<div> "' + response.message + '" </div>'+
								'<button type="button" class="button" ng-click="closeThisDialog(0)">Close</button>'+
							'</div>',
						plain: 'true'
					});
					$scope.showSwitches();
				}
			})
			.error(function(resp) {
				console.log(resp);
				$scope.loading = false;
			});

		};

		if($rootScope.selectedFabricsTab == "liveTraffic" && $scope.networkCode && !$scope.dataReload){
			//$scope.loadLiveTraffic();
			if($rootScope.newValue.id){
					$scope.showChart($rootScope.newValue);
			}
			else{
					$scope.loadLiveTraffic();
			}
		}
		if($rootScope.selectedFabricsTab == "liveTraffic"){
			$rootScope.contextValue = "network_port_stats";
		}
	}
])
