VCF.controller('FabricsController', ['$scope', '$rootScope', 'SharedDataService', '$state', 'config', 'ContextSearchService', '$http',
	function($scope, $rootScope, SharedDataService, $state, config, ContextSearchService, $http){
		$scope.networkCode;
		$scope.searchValue = "";
		/*commented as the old tabs were removed, delete after the system is stable
		if($state.current.tab){
			$scope.tab = $state.current.tab;
		}
		else{
			$scope.tab = 'map';
		}
		$rootScope.selectedFabricsTab = $scope.tab;
		
		var context =  SharedDataService.getContext();
		$scope.selectedNode = context.menu;
				
		$scope.setTab = function(tabName){
			$scope.tab = tabName;
			$state.go('fabrics.'+tabName);
			$rootScope.selectedFabricsTab = tabName;
		}
		
		$scope.$on('$stateChangeSuccess', function(event, toState, toParams, fromState, fromParams){
			if(toState.tab){
				$scope.setTab(toState.tab);
				$rootScope.$broadcast('selectedFabricsTab');
			}
		});
		*/
		$scope.tabSelected = function(tabName){
			$rootScope.selectedFabricsTab = tabName.split(".")[1];
			$state.go(tabName)
		};
		
		$scope.search = function(obj){
			$http
				({
					method: 'POST', 
					url: config.CONTEXT_SEARCH_POST_URI,
					params: {
						'networkCode': $scope.networkCode
					},
					data: {
						'context': $rootScope.contextValue,
						'key': '',
						'value': obj.searchValue
					}
				})
				.success(function() {
					ContextSearchService.sendData(obj.searchValue);
				}) ;
		};
	}
]);