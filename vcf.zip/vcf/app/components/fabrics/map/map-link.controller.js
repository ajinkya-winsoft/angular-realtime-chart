VCF.controller('MapLinkController', ['$scope', '$rootScope', '$http', 'SharedDataService', 'FabricsDataService', 'config', '$timeout', 'ngDialog', '$interval',
	function($scope, $rootScope, $http, SharedDataService, FabricsDataService, config, $timeout, ngDialog, $interval) {
		$scope.maplinkcontroller = "in maplinkcontroller";
		//console.log("in MapLinkController");
		//console.log($scope.ngDialogData);

		$scope.linkSourcedata = [];
		$scope.labelsLinkSource = [];
		$scope.seriesLinkSource = [];
		$scope.portSourceDataMap = {};

		$scope.linkTargetdata = [];
		$scope.labelsLinkTarget = [];
		$scope.seriesLinkTarget = [];
		$scope.portTargetDataMap = {};

		$scope.statslinkTrafficSourceFilter = "ibytes";
		$scope.statslinkTrafficTargetFilter = "ibytes";

		$scope.awaitingLinkResponse = false;
		$scope.awaitingTargetResponse = false;

		//$scope.startLinkChart;
		var startTargetChart;

		$scope.showSourceChart = true;
		$scope.showTargetChart = true;
		$scope.colors = ['#45b7cd', '#ff6384', '#ff8e72', '#FFD572', '#B1FF72', '#72FF9F', '#72A8FF', '#9872FF', '#EA72FF', '#A672FF'];
		$scope.optionsLinkSource = {
			animation: {
				duration: 0
			},
			elements: {
				line: {
					borderWidth: 1,
					fill: false
				},
				point: {
					radius: 3
				}
			},
			legend: {
				display: false
			},
			scales: {
				xAxes: [{
					display: true
				}],
				yAxes: [{
					display: true,
					stacked: true,
					ticks:{
						min: 0,
						callback: function (value) {
							var val=value.toString();
							val = value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
							if(val.indexOf(".")>0){
								temp = val.split(".");
								val = temp[0] + "." + temp[1].slice(0,1);
							}
							return val;
						}
					}
				}],
				gridLines: {
					display: true
				}
			},
			tooltips: {
				enabled: true
			}
		};

		$scope.optionsLinkTarget = {
			animation: {
				duration: 0
			},
			elements: {
				line: {
					borderWidth: 1,
					fill: false
				},
				point: {
					radius: 3
				}
			},
			legend: {
				display: false
			},
			scales: {
				xAxes: [{
					display: true
				}],
				yAxes: [{
					display: true,
					stacked: true,
					ticks:{
						min: 0,
						callback: function (value) {
							var val=value.toString();
							val = value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
							if(val.indexOf(".")>0){
								temp = val.split(".");
								val = temp[0] + "." + temp[1].slice(0,1);
							}
							return val;
						}
					}
				}],
				gridLines: {
					display: true
				}
			},
			tooltips: {
				enabled: true
			}
		};
		//console.log($rootScope.mapLinkDialogOpen[$scope.ngDialogData.code]);
		$scope.showLinkChart = function(){

			if(typeof $scope.startLinkChart !== "undefined"){
				$interval.cancel($scope.startLinkChart);
			}
			$scope.startLinkChart = $interval(function () {
				if ($scope.awaitingLinkResponse === false
					&& $rootScope.mapLinkDialogOpen[$scope.ngDialogData.code]
				) {
					$scope.awaitingLinkResponse = true;
					$scope.getLinkTrafficChartData();
				}
			}, 1000);
		};

		$scope.getLinkTrafficChartData = function() {

			$http({
				method: 'POST',
				url: config.PORT_STATS_LINK_POST_URI,
				params: {
					"networkCode": $scope.networkCode
				},
				data: {
					"sourceCode": $scope.ngDialogData.source.code,
					"sourcePorts": $scope.ngDialogData.sourcePort,
					"targetCode": $scope.ngDialogData.target.code,
					"targetPorts": $scope.ngDialogData.targetPort
				}
			})
			.success(function(response){

				$scope.awaitingLinkResponse = false;

				if (!response.result || !response.result.sourceData) {
					return;
				}

				var statsSource = response.result.sourceData;
				var statsTarget = response.result.targetData;
				var MAXIMUM_X_AXIS_UNIT = 10;

				var keysSource = [];
				$scope.seriesLinkSource = [];
				$scope.linkSourcedata = [];

				var keysTarget = [];
				$scope.seriesLinkTarget = [];
				$scope.linkTargetdata = [];

				if (statsSource && statsSource.length > 0) {
					$scope.showSourceChart = true;
					for (var i=0; i<statsSource.length; i++) {
						var keySource = ''+ statsSource[i].port;

						if ($scope.portSourceDataMap[keySource]) {
							if ($scope.portSourceDataMap[keySource].length >= MAXIMUM_X_AXIS_UNIT) {
								$scope.portSourceDataMap[keySource] = $scope.portSourceDataMap[statsSource[i].port].slice(1);
							}
						}
						else {
							$scope.portSourceDataMap[keySource] = [];
							xAxes = [];
						}

						$scope.portSourceDataMap[keySource].push(statsSource[i]);

						keysSource.push(keySource);

						$scope.seriesLinkSource.push('Port #' + keySource);
					}

					if ($scope.labelsLinkSource.length > (MAXIMUM_X_AXIS_UNIT-1)) {
						$scope.labelsLinkSource = $scope.labelsLinkSource.slice(1);
					}

					var d = new Date();
					var time = ('0'+d.getHours()).slice(-2) + ':' + ('0'+d.getMinutes()).slice(-2) + ':' + ('0'+d.getSeconds()).slice(-2);
					$scope.labelsLinkSource.push(time);

					for (var i=0; i < keysSource.length; i++) {
						var data = $scope.portSourceDataMap[keysSource[i]].map(function(d){return d[$scope.statslinkTrafficSourceFilter]});
						$scope.linkSourcedata.push(data);
					}
				}
				else{
					$scope.showSourceChart = true;
				}

				//***Target data***/
				if (statsTarget && statsTarget.length > 0) {
					$scope.showTargetChart = true;
					for (var i=0; i<statsTarget.length; i++) {
						var keyTarget = ''+ statsTarget[i].port;

						if ($scope.portTargetDataMap[keyTarget]) {
							if ($scope.portTargetDataMap[keyTarget].length >= MAXIMUM_X_AXIS_UNIT) {
								$scope.portTargetDataMap[keyTarget] = $scope.portTargetDataMap[statsTarget[i].port].slice(1);
							}
						}
						else {
							$scope.portTargetDataMap[keyTarget] = [];
							xAxes = [];
						}

						$scope.portTargetDataMap[keyTarget].push(statsTarget[i]);

						keysTarget.push(keyTarget);

						$scope.seriesLinkTarget.push('Port #' + keyTarget);
					}

					if ($scope.labelsLinkTarget.length > (MAXIMUM_X_AXIS_UNIT-1)) {
						$scope.labelsLinkTarget = $scope.labelsLinkTarget.slice(1);
					}

					var d = new Date();
					var time = ('0'+d.getHours()).slice(-2) + ':' + ('0'+d.getMinutes()).slice(-2) + ':' + ('0'+d.getSeconds()).slice(-2);
					$scope.labelsLinkTarget.push(time);

					for (var i=0; i < keysTarget.length; i++) {
						var data = $scope.portTargetDataMap[keysTarget[i]].map(function(d){return d[$scope.statslinkTrafficTargetFilter]});
						$scope.linkTargetdata.push(data);
					}
				}
				else{
					$scope.showTargetChart = false;
				}
			})
			.error(function(resp) {
				$scope.awaitingLinkResponse = false;
				console.log(resp);
			});
		};

		$scope.refreshlinkTrafficSourceFilter = function(statslinkTrafficSourceFilter){
			$scope.statslinkTrafficSourceFilter = statslinkTrafficSourceFilter;
		};

		$scope.refreshlinkTrafficTargetFilter = function(statslinkTrafficTargetFilter){
			$scope.statslinkTrafficTargetFilter = statslinkTrafficTargetFilter;
		};

		$scope.showLinkChart();

		/******************************************************************************************/
		 Highcharts.setOptions({
	        global: {
	            useUTC: false
	        }
    	});
		 $scope.chartSeries = [
    			{"name": "Some data", "data": [],showInNavigator: true}
		];

		$scope.chartConfig = {
		    options: {
		      chart: {
		       type: 'spline',
		         animation: Highcharts.svg,
		         zoomType: 'x',
		        panning: true,
		        panKey: 'shift',
		        width: 450,
		        height: 200

      },
      plotOptions: {
            series: {
                lineWidth: 1
            }
        },
        rangeSelector: {
                selected: 1
            },
      scrollbar: {
        enabled: true
    }
  },

    title: {
      text: ''
    },

  exporting: false,
    navigator: {
        enabled: true,
        // series: {
        //     data: []
        // }
    },
    rangeSelector: {
        selected: 2
    },
    plotOptions: {
    	spline: {
                marker: {
                    enabled: true
                }
            },
        series: {
            lineWidth: 1,
            fillOpacity: 0.9

        },
        column: {
            stacking: 'normal'
        },
        area: {
            stacking: 'normal',
            marker: {
                enabled: false
            }
        }

    },
    useHighStocks: false,

    rangeSelector: {
                  selected: 2
              },
    //
    //           plotOptions: {
    //               series: {
    //                   showInNavigator: true
    //               }
    //           },

    credits: {
      enabled: false
    },
    loading: false,
    size: {},

    xAxis: {
                type: 'datetime',
                tickPixelInterval: 100,

            },


  
series: $scope.chartSeries,
func : function(){
  $interval(function() {
  
    // if($scope.chartSeries[0].data.length > 300)
    //           $scope.chartSeries[0].data.splice(0,1);

    //           $scope.chartSeries[0].data.push([(new Date()).getTime(),Math.random()]);
    //           //console.log("hi");

    $http({
				method: 'POST',
				url: config.PORT_STATS_LINK_POST_URI,
				params: {
					"networkCode": $scope.networkCode
				},
				data: {
					"sourceCode": $scope.ngDialogData.source.code,
					"sourcePorts": $scope.ngDialogData.sourcePort,
					"targetCode": $scope.ngDialogData.target.code,
					"targetPorts": $scope.ngDialogData.targetPort
				}
			})
			.success(function(response){

				$scope.awaitingLinkResponse = false;

				if (!response.result || !response.result.sourceData) {
					return;
				}

				var statsSource = response.result.sourceData;
				var statsTarget = response.result.targetData;
				var MAXIMUM_X_AXIS_UNIT = 10;

				var keysSource = [];
				$scope.seriesLinkSource = [];
				$scope.linkSourcedata = [];

				var keysTarget = [];
				$scope.seriesLinkTarget = [];
				$scope.linkTargetdata = [];

				if (statsSource && statsSource.length > 0) {
					$scope.showSourceChart = true;
					for (var i=0; i<statsSource.length; i++) {
						var keySource = ''+ statsSource[i].port;

						if ($scope.portSourceDataMap[keySource]) {
							if ($scope.portSourceDataMap[keySource].length >= MAXIMUM_X_AXIS_UNIT) {
								$scope.portSourceDataMap[keySource] = $scope.portSourceDataMap[statsSource[i].port].slice(1);
							}
						}
						else {
							$scope.portSourceDataMap[keySource] = [];
							xAxes = [];
						}

						$scope.portSourceDataMap[keySource].push(statsSource[i]);

						keysSource.push(keySource);

						//$scope.seriesLinkSource.push('Port #' + keySource);
						$scope.chartSeries[i].name = ('Port #'+ keySource);
					}

					if ($scope.labelsLinkSource.length > (MAXIMUM_X_AXIS_UNIT-1)) {
						$scope.labelsLinkSource = $scope.labelsLinkSource.slice(1);
					}

					var d = new Date(Date.now());
					var time = ('0'+d.getHours()).slice(-2) + ':' + ('0'+d.getMinutes()).slice(-2) + ':' + ('0'+d.getSeconds()).slice(-2);
					$scope.labelsLinkSource.push(time);

					for (var i=0; i < keysSource.length; i++) {
						var data = $scope.portSourceDataMap[keysSource[i]].map(function(d){return d[$scope.statslinkTrafficSourceFilter]});
						 $scope.chartSeries[i].data.push([new Date().getTime() ,Number(data[0]+Math.random())]);
						 console.log($scope.chartSeries);
						//$scope.chartSeries[i].data = data;
					}
				}
				else{
					$scope.showSourceChart = true;
				}

				//***Target data***/
				if (statsTarget && statsTarget.length > 0) {
					$scope.showTargetChart = true;
					for (var i=0; i<statsTarget.length; i++) {
						var keyTarget = ''+ statsTarget[i].port;

						if ($scope.portTargetDataMap[keyTarget]) {
							if ($scope.portTargetDataMap[keyTarget].length >= MAXIMUM_X_AXIS_UNIT) {
								$scope.portTargetDataMap[keyTarget] = $scope.portTargetDataMap[statsTarget[i].port].slice(1);
							}
						}
						else {
							$scope.portTargetDataMap[keyTarget] = [];
							xAxes = [];
						}

						$scope.portTargetDataMap[keyTarget].push(statsTarget[i]);

						keysTarget.push(keyTarget);

						$scope.seriesLinkTarget.push('Port #' + keyTarget);
					}

					if ($scope.labelsLinkTarget.length > (MAXIMUM_X_AXIS_UNIT-1)) {
						$scope.labelsLinkTarget = $scope.labelsLinkTarget.slice(1);
					}

					var d = new Date();
					var time = ('0'+d.getHours()).slice(-2) + ':' + ('0'+d.getMinutes()).slice(-2) + ':' + ('0'+d.getSeconds()).slice(-2);
					$scope.labelsLinkTarget.push(time);

					for (var i=0; i < keysTarget.length; i++) {
						var data = $scope.portTargetDataMap[keysTarget[i]].map(function(d){return d[$scope.statslinkTrafficTargetFilter]});
						$scope.linkTargetdata.push(data);
					}
				}
				else{
					$scope.showTargetChart = false;
				}
			})
			.error(function(resp) {
				$scope.awaitingLinkResponse = false;
				console.log(resp);
			});
			 $scope.reflow();

  }, 1000);
}
};
 $scope.reflow = function () {
    $scope.$broadcast('highchartsng.reflow');
  };
		/*****************************************************************************************/
	}
]);
