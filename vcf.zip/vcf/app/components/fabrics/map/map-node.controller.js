VCF.controller('MapNodeController', ['$scope', '$rootScope', '$http', 'SharedDataService', 'FabricsDataService', 'config', '$timeout', 'ngDialog', '$interval',
	function($scope, $rootScope, $http, SharedDataService, FabricsDataService, config, $timeout, ngDialog, $interval) {
		$scope.refreshRate = 1;
		$scope.CLIDiv = true;

		$scope.networkCode;
		$scope.newValue;
		$scope.oldValue;
		$rootScope.fabricNodeSelected = false;
		$scope.selectedNodeForDialog;
		$scope.tab = 'liveTraffic';

		$scope.ctrlPlaneData = [];

		$scope.mapLiveTrafficdata = [];
		$scope.labelsLiveTraffic = [];
		$scope.seriesLiveTraffic = [];
		$scope.portDataMap = [];

		$scope.mapVlansLiveTrafficdata = [];
		$scope.labelsVlansLiveTraffic = [];
		$scope.seriesVLansLiveTraffic = [];
		$scope.vlanDataMap = [];

		$scope.statsMapLiveTrafficdataFilter = "ibytes";
		$scope.statsMapVlansLiveTrafficdataFilter = "ibytes";

		$scope.awaitingResponse = false;
		$scope.awaitingLiveTrafficResponse = false;
		$scope.awaitingVlansLiveTrafficResponse = false;

		$scope.vlans = "";

		var startChart;
		var startVlansChart;
		$scope.showVlansChart = false;
		$scope.showCtrlPlaneChart = false;
		$scope.showPortStatsChart = false;

		_C = 0;
		$scope.SSHFormCredentials = {};

		$scope.sshTerminal = false;

		$scope.dialogLoading = false;

		$scope.setTab = function(tabName){
			$scope.tab = tabName;
			if(tabName == "liveTraffic"){
				$scope.loadMapLiveTrafficChart();
			}
			else if(tabName == "vlansLiveTraffic"){
				$scope.loadMapVlansLiveTrafficChart();
			}
			else if(tabName == "ctrlPlane"){
				$scope.loadMapCtrlPlaneChart();
			}
			else if(tabName == "ssh"){
				$timeout(function() {
					angular.element('.terminalBox').trigger('focus');
				}, 100)

				//$scope.shouldBeFocus = true;
				//$scope.mapDialog.close();
				//$rootScope.$broadcast('openSSHfromMapDialog',$scope.selectedNodeForDialog);
				// console.log($scope.sshTerminal);
				// if(!$scope.sshTerminal){
					// $scope.loadSSH();
				// }
			}
		};

		$scope.optionsLiveTraffic = {
			animation: {
				duration: 0
			},
			elements: {
				line: {
					borderWidth: 1,
					fill: false
				},
				point: {
					radius: 3
				}
			},
			legend: {
				display: false
			},
			scales: {
				xAxes: [{
					display: true
				}],
				yAxes: [{
					display: true,
					stacked: true,
					ticks:{
						beginAtZero: true,
						callback: function (value) {
							var val=value.toString();
							val = value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
							if(val.indexOf(".")>0){
								temp = val.split(".");
								val = temp[0] + "." + temp[1].slice(0,1);
							}
							return val;
						}
					}
				}],
				gridLines: {
					display: true
				}
			},
			tooltips: {
				enabled: true
			}
		};

		$scope.optionsVlansLiveTraffic = {
			animation: {
				duration: 0
			},
			elements: {
				line: {
					borderWidth: 1,
					fill: false
				},
				point: {
					radius: 3
				}
			},
			legend: {
				display: false
			},
			scales: {
				xAxes: [{
					display: true
				}],
				yAxes: [{
					display: true,
					stacked: true,
					ticks:{
						beginAtZero: true,
						callback: function (value) {
							var val=value.toString();
							val = value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
							if(val.indexOf(".")>0){
								temp = val.split(".");
								val = temp[0] + "." + temp[1].slice(0,1);
							}
							return val;
						}
					}
				}],
				gridLines: {
					display: true
				}
			},
			tooltips: {
				enabled: true
			}
		};

		$scope.options = {
			animation: {
				duration: 500
			},
			elements: {
				line: {
					borderWidth: 1,
					fill: false
				},
				point: {
					radius: 3
				}
			},
			legend: {
				display: false
			},
			scales: {
				xAxes: [{
					display: true,
					stacked: true
				}],
				yAxes: [{
					display: true,
					stacked: true,
					ticks:{
						callback: function (value) {
							return value + " %";
						}
					}
				}],
				gridLines: {
					display: true
				}
			},
			tooltips: {
				enabled: true
			}
		};

		var d = new Date();
		var initialStartTime =  d.getHours() + ':' + d.getMinutes() + ':' + (d.getSeconds() - 10);
		var currentTime =  d.getHours() + ':' + d.getMinutes() + ':' + d.getSeconds();
		var startTime="", endTime="";

		$scope.loadMapLiveTrafficChart = function(){
			if(typeof $scope.startLiveTrafficChart !== "undefined"){
				$interval.cancel($scope.startLiveTrafficChart);
			}
			$scope.startLiveTrafficChart = $interval(function () {
				if ( $scope.awaitingLiveTrafficResponse === false
					&& $scope.tab == 'liveTraffic'
					&& $rootScope.mapDialogOpen[$scope.ngDialogData.node.code]
					) {
					$scope.awaitingLiveTrafficResponse = true;
					$scope.getMapLiveTrafficChartData();
				}
			}, 1000);
		};

		$scope.getMapLiveTrafficChartData = function() {
			if(startTime==""){
				startTime = initialStartTime;
			}
			else{
				startTime = endTime;
			}

			if(endTime==""){
				endTime = currentTime;
			}
			else{
				var _tempd = new Date();
				endTime = _tempd.getHours() + ':' + _tempd.getMinutes() + ':' + _tempd.getSeconds();
			}

			$http({
				method: 'POST',
				url: config.PORT_STATS_CONSOLIDATED_GET_URI,
				params: {
					shouldConsolidate: true,
					'networkCode': $scope.networkCode
				},
				data: {
					'startTime': startTime,
					'endTime': endTime,
					'code': $scope.ngDialogData.node.code
				}
			})
			.success(function(response){

				$scope.awaitingLiveTrafficResponse = false;

				if (!response || !response.result) {
					$scope.showPortStatsChart = false;
					$scope.portStatsMessage = "No Data Available";
				}
				else if(response.result[0].time){
					$scope.showPortStatsChart = true;
					var stats = response.result;
					var MAXIMUM_X_AXIS_UNIT = 10;

					var keys = [];
					$scope.seriesLiveTraffic = [];
					$scope.mapLiveTrafficdata = [];


					for (var i=0; i<stats.length; i++) {
						var key = ''+ stats[i].port;

						if ($scope.portDataMap) {
							if ($scope.portDataMap.length >= MAXIMUM_X_AXIS_UNIT) {
								$scope.portDataMap = $scope.portDataMap.slice(1);
							}
						}
						else {
							$scope.portDataMap = [];
							xAxes = [];
						}

						$scope.portDataMap.push(stats[i]);

						keys.push(key);

						$scope.seriesLiveTraffic.push('Port #' + key);
					}

					if ($scope.labelsLiveTraffic.length > (MAXIMUM_X_AXIS_UNIT-1)) {
						$scope.labelsLiveTraffic = $scope.labelsLiveTraffic.slice(1);
					}

					var d = new Date();
					var time = ('0'+d.getHours()).slice(-2) + ':' + ('0'+d.getMinutes()).slice(-2) + ':' + ('0'+d.getSeconds()).slice(-2);
					$scope.labelsLiveTraffic.push(time);

					var data = $scope.portDataMap.map(function(d){return d[$scope.statsMapLiveTrafficdataFilter]});
					$scope.mapLiveTrafficdata.push(data);
				}
				else {
					$scope.showPortStatsChart = false;
					$scope.portStatsMessage = "No Data Available";
				}
			})
			.error(function(resp) {
				$scope.awaitingResponse = false;
				console.log(resp);
			});
		};

		$scope.refreshLiveTrafficdataFilter = function(statsMapLiveTrafficdataFilter){
			$scope.statsMapLiveTrafficdataFilter = statsMapLiveTrafficdataFilter;
		};

		$scope.loadMapVlansLiveTrafficChart = function(){
			if(typeof $scope.startVlansLiveTrafficChart !== "undefined"){
				$interval.cancel($scope.startVlansLiveTrafficChart);
			}
			$scope.startVlansLiveTrafficChart = $interval(function () {
				if ( $scope.awaitingVlansLiveTrafficResponse === false
					&& $scope.tab == 'vlansLiveTraffic'
					&& $scope.vlans.length > 0
					&& $rootScope.mapDialogOpen[$scope.ngDialogData.node.code]
					) {
					$scope.awaitingVlansLiveTrafficResponse = true;
					$scope.getMapVlansLiveTrafficChartData();
				}
			}, 1000);
		};

		$scope.getMapVlansLiveTrafficChartData = function() {
			if(startTime==""){
				startTime = initialStartTime;
			}
			else{
				startTime = endTime;
			}

			if(endTime==""){
				endTime = currentTime;
			}
			else{
				var _tempd = new Date();
				endTime = _tempd.getHours() + ':' + _tempd.getMinutes() + ':' + _tempd.getSeconds();
			}

			$http({
				method: 'POST',
				url: config.VLANS_STATS_POST_URI,
				params: {
					'networkCode': $scope.networkCode
				},
				data: {
					'startTime': startTime,
					'endTime': endTime,
					'code': $scope.ngDialogData.node.code,
					'vlans': $scope.vlans
				}
			})
			.success(function(response){

				$scope.awaitingVlansLiveTrafficResponse = false;

				if (!response || !response.result || response.result.length == 0) {
					$scope.showVlansChart = false;
					$scope.vlansMessage = "No Data Available";
				}
				else if(response.result[0].time) {
					$scope.showVlansChart = true;

					var stats = response.result;
					var MAXIMUM_X_AXIS_UNIT = 10;

					var keys = [];
					$scope.seriesVlansLiveTraffic = [];
					$scope.mapVlansLiveTrafficdata = [];


					for (var i=0; i<stats.length; i++) {
						var key = ''+ stats[i].port;

						if ($scope.vlanDataMap) {
							if ($scope.vlanDataMap.length >= MAXIMUM_X_AXIS_UNIT) {
								$scope.vlanDataMap = $scope.vlanDataMap.slice(1);
							}
						}
						else {
							$scope.vlanDataMap = [];
							xAxes = [];
						}

						$scope.vlanDataMap.push(stats[i]);

						keys.push(key);

						$scope.seriesVlansLiveTraffic.push('Port #' + key);
					}

					if ($scope.labelsVlansLiveTraffic.length > (MAXIMUM_X_AXIS_UNIT-1)) {
						$scope.labelsVlansLiveTraffic = $scope.labelsVlansLiveTraffic.slice(1);
					}

					var d = new Date();
					var time = ('0'+d.getHours()).slice(-2) + ':' + ('0'+d.getMinutes()).slice(-2) + ':' + ('0'+d.getSeconds()).slice(-2);
					$scope.labelsVlansLiveTraffic.push(time);

					var data = $scope.vlanDataMap.map(function(d){return d[$scope.statsMapVlansLiveTrafficdataFilter]});
					$scope.mapVlansLiveTrafficdata.push(data);
				}
				else {
					$scope.showVlansChart = false;
					$scope.vlansMessage = "No Data Available";
				}

			})
			.error(function(resp) {
				$scope.awaitingVlansResponse = false;
				console.log(resp);
			});
		};

		$scope.refreshVlansLiveTrafficdataFilter = function(statsMapVlansLiveTrafficdataFilter){
			$scope.statsMapVlansLiveTrafficdataFilter = statsMapVlansLiveTrafficdataFilter;
		};

		$scope.$watch('vlans', function() {
			if($scope.vlans == ""){
				$scope.vlansMessage = "Please enter valid VLAN number/s."
				$scope.showVlansChart = false;
			}
		});

		$scope.vlanChange = function(vlans){
			if(vlans == ""){
				$scope.vlansMessage = "Please enter valid VLAN number/s."
				$scope.showVlansChart = false;
			}
			$scope.vlans = vlans;
		};

		$scope.labels = ['Memory % Utilization','CPU % Utilization - User', 'CPU % Utilization - System'];

		$scope.loadMapCtrlPlaneChart = function(){
			if(typeof $scope.startChart !== "undefined"){
				$interval.cancel($scope.startChart);
			}
			$scope.startChart = $interval(function () {
				if ( $scope.awaitingResponse === false
					&& $scope.tab == 'ctrlPlane'
					&& $rootScope.mapDialogOpen[$scope.ngDialogData.node.code]
					) {
					$scope.awaitingResponse = true;
					$scope.getMapCtrlPlaneChart();
				}
			}, $scope.refreshRate * 1000);
		};

		$scope.refreshRateChange = function(refreshRate){

			if(refreshRate < 1){
				refreshRate = 1;
			}

			if(typeof $scope.startChart !== "undefined"){
				$interval.cancel($scope.startChart);
			}

			$scope.startChart = $interval(function () {
				if ( $scope.awaitingResponse === false
					&& $scope.tab == 'ctrlPlane'
					) {
					$scope.awaitingResponse = true;
					$scope.getMapCtrlPlaneChart();
				}
			}, refreshRate * 1000);
		};

		$scope.getMapCtrlPlaneChart = function(){


			$http({
				method: 'GET',
				url: config.SYSTEM_STATS_GET_URI,
				params: {
					"networkCode": $scope.networkCode,
					'code': $scope.ngDialogData.node.code
				}
			})
			.success(function(response){
				$scope.awaitingResponse = false;
				if (!response || !response.result) {
					$scope.showCtrlPlaneChart = false;
					$scope.ctrlPlaneMessage = "No Data Available";
				}
				else if(response.result[0]['usedMem']) {
					$scope.ctrlPlaneData = [];
					$scope.ctrlPlaneData.push(response.result[0]['usedMem']);
					$scope.ctrlPlaneData.push(response.result[0]['cpuUser'])
					$scope.ctrlPlaneData.push(response.result[0]['cpuSys']);
					$scope.mapCtrlPlaneData = $scope.ctrlPlaneData;
					$scope.showCtrlPlaneChart = true;
				}
				else {
					$scope.showCtrlPlaneChart = false;
					$scope.ctrlPlaneMessage = "No Data Available";
				}
			})
			.error(function(resp) {
				$scope.awaitingResponse = false;
				console.log(resp);
			});
		};

		$scope.cmds = [];

		$scope.terminalKeyUp = function(keyEvent, terminalText){
			if (keyEvent.which === 13 && terminalText !="")
			{
				$scope.dialogLoading = true;
				$http({
					method: 'POST',
					url: config.SSH_COMMAND_POST_URI,
					data: {
						'host' : $scope.ngDialogData.node.mgmtIp,
						'port' : $scope.ngDialogData.port,
						'user' : $scope.ngDialogData.user,
						'password' : $scope.ngDialogData.password,
						'command' : terminalText
					}
				})
				.success(function(response){
					//setTimeout(function(){
						$scope.dialogLoading = false;
						$scope.terminalTextbox = "";
						$scope.shouldBeFocus = true;
						var result = response.result ? response.result : response.message;
						$scope.cmds.push('$ ' + terminalText);
						$scope.cmds.push(result);
					//}, 5000);

				})
				.error(function(resp) {
					//$scope.isHide = false;
					console.log('an error occurred', resp.result);
					console.log(resp);
				});


			}
		};

		$timeout(function() {
			if(ngDialog.isOpen($scope.mapDialog.id)){
				$scope.setTab("liveTraffic");
			}
		}, 100)

		$scope.inputFocus = function () {
			$scope.shouldBeFocus = true;
		};
	}
]);
