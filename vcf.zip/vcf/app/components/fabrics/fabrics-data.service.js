VCF.factory('FabricsDataService',['$rootScope', '$timeout', function($rootScope, $timeout){
	var service = {};
	service.currentFabric;

	service.clear = function() {
		service.currentFabric = null;
	}

	service.setCurrentFabric = function(newValue, parent){
		var raiseEvent = true;//false;
		var oldValue = service.currentFabric;
		if (oldValue !== newValue || oldValue.name !== newValue.name) {
			raiseEvent = true
		}
		service.currentFabric = newValue;

		$rootScope.newValue = newValue;
		$rootScope.oldValue = oldValue;
		$rootScope.parent = parent;

		if (raiseEvent) {

			if (oldValue && newValue) {
				if(!newValue.networkCode){
					$rootScope.networkCode = (newValue.networkCode ? newValue.networkCode : newValue.code);
					$rootScope.fabId = newValue.fabId;

					$rootScope.$broadcast('fabric_change', newValue, oldValue, parent);
					$rootScope.$broadcast('selectedFabricsTab');
				}
				else if (/* code under testing, to be modified/removed latter
					newValue === oldValue // if old and new have same object identity then no network/fabric-change event
					|| newValue.code === oldValue.code // if old and new value have same persistent identity then no network/fabric-change event
					||*/
					(newValue.networkCode
						&& newValue.networkCode === oldValue.code && !oldValue.networkCode) // if new value's parent was old value (network)
					|| (oldValue.networkCode
						&& oldValue.networkCode === newValue.code && !newValue.networkCode) // if old value's parent was new value (network)
					|| (newValue.networkCode && newValue.networkCode === oldValue.networkCode )
					) { // if new and old value's parent were same
					$rootScope.networkCode = (newValue.networkCode ? newValue.networkCode : newValue.code);
					$rootScope.fabId = newValue.fabId;

					$rootScope.$broadcast('fabric_node_change', newValue, oldValue, parent);
					//return; // ignore if the main fabric was not changed
				}
				else {
					$rootScope.networkCode = (newValue.networkCode ? newValue.networkCode : newValue.code);
					$rootScope.fabId = newValue.fabId;

					$rootScope.$broadcast('fabric_change', newValue, oldValue, parent);
					$rootScope.$broadcast('selectedFabricsTab');
				}
			}
			else {
				$rootScope.networkCode = (newValue.networkCode ? newValue.networkCode : newValue.code);
				$rootScope.fabId = newValue.fabId;

				$rootScope.$broadcast('fabric_change', newValue, oldValue, parent);
				$rootScope.$broadcast('selectedFabricsTab');
			}
		}
	};
	service.getCurrentFabric = function(){
		return service.currentFabric;
	};
	return service;
}]);
