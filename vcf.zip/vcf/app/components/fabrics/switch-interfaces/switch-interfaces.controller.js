VCF.controller('InterfacesController', ['$scope', '$rootScope', '$http', 'config', '$filter', 'ngDialog', 'ContextSearchService', '$templateCache',
	function($scope, $rootScope, $http, config, $filter, ngDialog, ContextSearchService, $templateCache) {
		
		$scope.filterDiv = true;
		$scope.networkCode;
		$scope.fabId;
		$scope.switchInterfacesList = [];
		$scope.dataReload = false;
		$rootScope.fabricSelected = false;
		$scope.isDataFound = false; 
		$scope.currentSwitch;
		
		$scope.$on('text_search', function(){
			if($rootScope.selectedFabricsTab == "interfaces" && $scope.switchInterfacesList) {
				var searchValue =  ContextSearchService.getData();
				if (searchValue == '') {
					$scope.items = $scope.switchInterfacesList;
				}
				else {
					$scope.items = $filter('filter')($scope.switchInterfacesList, searchValue, undefined);
				}
			}
        });
		
		$scope.$on('fabric_change', function(event, newValue, oldValue, parent){
			$scope.networkCode = (newValue.networkCode ? newValue.networkCode : newValue.code);
			$scope.fabId = newValue.fabId;
			if(newValue.id){
				$rootScope.selectedSwitchId = newValue.id;
			}
			else{
				$rootScope.selectedSwitchId = "";
			}
			$scope.dataReload = false;
			$scope.clearInterface();
		});
		
		$scope.$on('fabric_node_change', function(event, newValue, oldValue, parent){
			$rootScope.selectedSwitchId = newValue.id;
			if(newValue.networkCode && (newValue != oldValue)){
				$scope.filterInterface();
			}
		});
		
		$scope.$on('selectedFabricsTab', function(event) {	
			if($rootScope.selectedFabricsTab == "interfaces" && $scope.networkCode && $scope.fabId && !$scope.dataReload){
				$scope.filterInterface();
			}
			
			if($rootScope.selectedFabricsTab == "interfaces"){
				$rootScope.contextValue = "network_ports";
				
			}
		});
		
		$scope.speeds = [];
		$scope.trunks = [];
		$scope.vlags = [];
		$scope.loadInterfaces = function(){
			$scope.loading = true;
			$http ({
				method: 'GET',
				url: config.INTERFACES_GET_URI,
				params: {
					"networkCode": $scope.networkCode
				}
			})
			.success(function(response){
				$scope.loading = false;
				$scope.items = response.result;
				$rootScope.fabricSelected = true;
				$scope.switchInterfacesList = response.result;
				$scope.filterDiv = false;
				$scope.dataReload = true;
			})
			.error(function(resp) {
				console.log(resp);
				$scope.loading = false;
			});
		};
		
		$scope.openInterface = function () {
			$scope.currentInterface = this.item;
			$scope.interfaceDialog = ngDialog.open({
				template: './app/components/fabrics/switch-interfaces/switch-interface.dialog.htm',
				showClose: true,
				closeByDocument: false,
				closeByEscape: false,
				scope: $scope,
				width: '95%'
			});
		};

		$scope.filterInterface = function() {
			$scope.loading = true;
			$http ({
				method: 'POST',
				url: config.SEARCH_INTERFACES_POST_URI,
				params: {
					'networkCode': $scope.networkCode
				},
				data: {
					'switchId': $rootScope.selectedSwitchId,
					'mode': $scope.switchMode,
					'speed': $scope.speed,
					'trunk': $scope.trunk,
					'vlag': $scope.vlag
				}
			})
			.success(function(response){
				
				$rootScope.fabricSelected = true;
				$scope.filterDiv = false;
				$scope.items = response.result;
				$scope.switchInterfacesList = response.result;
				if ($scope.items.length == 0) {
					$scope.isDataFound = true;
				}
				else{
					$scope.items = response.result;
					$scope.isDataFound = false;   
				}
				$scope.loading = false;
			})
			.error(function(resp) {
				console.log(resp);
				$scope.loading = false;
			});
		};
		
		$scope.clearInterface = function(){
			//$scope.switchId = $scope.switchId
			$rootScope.selectedSwitchId = $rootScope.selectedSwitchId;
			$scope.switchMode = "up"
			$scope.speed = ""
			$scope.trunk = ""
			$scope.vlag = ""
			$scope.isDataFound = false; 
			
			$http ({
				method: 'POST',
				url: config.SEARCH_INTERFACES_POST_URI,
				params: {
					'networkCode': $scope.networkCode
				},
				data: {
					'switchId': $rootScope.selectedSwitchId,
					'mode': $scope.switchMode,
					'speed': $scope.speed,
					'trunk': $scope.trunk,
					'vlag': $scope.vlag
				}
			})
			.success(function(response){
				$scope.switchInterfacesList = response.result;
				$scope.items = response.result;
				$scope.filterDiv = false;
			})
			.error(function(resp) {
				console.log(resp);
			});
		};
		
		$scope.propertyName = 'switchName';
		$scope.reverse = false;
		$scope.sortInterface = function(){
			$scope.reverse = !$scope.reverse;
		};
		
		$scope.switchMode = "up";
		
		if($rootScope.selectedFabricsTab == "interfaces" && $scope.networkCode && $scope.fabId && !$scope.dataReload){
			//console.log("in loadinterfaces");
			$scope.filterInterface();
		}
		
		if($rootScope.selectedFabricsTab == "interfaces"){
			$rootScope.contextValue = "network_ports";
		}
	}
])