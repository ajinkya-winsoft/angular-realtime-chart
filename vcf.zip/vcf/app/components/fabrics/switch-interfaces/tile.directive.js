angular.module('winsoft', [])
	.directive('tile', function(){
		return {
			restrict: 'E',
			template: '<div class="content-box float-left" ng-repeat="item in items">' +
				'<span>{{item.label}}</span>' +
				'<div class="inner-content-box">' +
					'<p>{{item.name}}</p>' +
					'<p class="link"><a href="#">{{item.link}}</a></p>' +
					'<div class="host">{{item.hostname}}</div>' +
				'</div>' +
				'<div align="right"><a hrer="#" ng-click="openInterfaces()">More</a></div>' +
			'</div>',
			
			controller: function($scope, ngDialog){
				$scope.openInterfaces = function () {
					$scope.currentInterfaces = this.item;
					console.log($scope.currentInterfaces);
					$scope.interfacesDialog = ngDialog.open({
					template: './app/components/fabrics/switch-interfaces/switch-interface.dialog.htm',
					showClose: false,
					closeByDocument: false,
					closeByEscape: false,
					scope: $scope
					});
				ngDialog.close($scope.interfacesDialog);
				};
			}
		}	
	});