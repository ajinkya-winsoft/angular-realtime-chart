VCF.controller('AnsibleAutomationController', ['$scope', '$rootScope', '$http', 'config', 'ngDialog', '$filter', 'ContextSearchService',
	function($scope, $rootScope, $http, config, ngDialog, $filter, ContextSearchService) {
		$scope.networkCode;
		$scope.ansibleModulesList = [];
		$scope.cmds = [];
		$scope.dataReload = false;
		$rootScope.fabricSelected = false;
		$scope.fileDataChanged = false;
		$scope.executeTooltip = "Excute Ansible File";
		$scope.ansibleOutputDisplay = false;
		
		$scope.$on('fabric_change', function(event, newValue, oldValue, parent){
			$scope.networkCode = (newValue.networkCode ? newValue.networkCode : newValue.code);
			$scope.dataReload = false;
		});
		
		$scope.$on('selectedFabricsTab', function(event) {			
			if($rootScope.selectedFabricsTab == "ansibleAutomation" && $scope.networkCode && !$scope.dataReload){
				$scope.loadAnsibleModules();
			}
			if($rootScope.selectedFabricsTab == "ansibleAutomation"){
				$rootScope.contextValue = "ansible_automation";
			}
		});
		
		$scope.loadAnsibleModules = function(){
			$scope.loading = true;
			$http ({
				method: 'GET',
				url: config.ANSIBLE_MODULES_GET_URI,
				params: {
					"networkCode": $rootScope.networkCode
				}
			})
			.success(function(response){
				$scope.ansibleModules = response.result;
				$scope.ansibleModulesList = response.result;
				$scope.dataReload = true;
				$rootScope.fabricSelected = true;
				$scope.loading = false;
			})
			.error(function(resp) {
				console.log(resp);
				$scope.loading = false;
			});
		};
		
		$scope.showModuleDetails = function () {
			angular.element(this).addClass("selected");
			$scope.selectedAnsibleModule = this.module;
			//console.log($scope.selectedAnsibleModule);
			
			$http ({
				method: 'GET',
				url: config.ANSIBLE_YML_FILE_PATH_URI + "/" + $scope.selectedAnsibleModule.file
			})
			.success(function(response){
				//console.log(response);
				$scope.ansibleFileData = response;
				$scope.fileDataChanged = false;
			})
			.error(function(resp) {
				console.log(resp);
				$scope.loading = false;
			});
			
		};
		
		$scope.saveData = function(){
			$http ({
				method: 'POST',
				url: config.ANSIBLE_YML_POST_URI,
				params: {
					"networkCode": $rootScope.networkCode
				},
				data: {
					'ansibleFileData': $scope.ansibleFileData,
					'selectedAnsibleModule': $scope.selectedAnsibleModule
				}
			})
			.success(function(response){
				//console.log(response);
				//$scope.ansibleFileData = response;
				$scope.fileDataChanged = false;
				$scope.executeTooltip = "Excute Ansible File";
				$scope.cmds = [];
			})
			.error(function(resp) {
				console.log(resp);
				$scope.loading = false;
			});
		};
		
		$scope.executeYML = function(){
			$http ({
				method: 'POST',
				url: config.ANSIBLE_YML_EXECUTE_POST_URI,
				params: {
					"networkCode": $rootScope.networkCode
				},
				data: {
					'ansibleFileData': $scope.ansibleFileData,
					'selectedAnsibleModule': $scope.selectedAnsibleModule
				}
			})
			.success(function(response){
				//console.log(response);
				//$scope.ansibleFileData = response;
				var result = response.result ? response.result : response.message;
				$scope.cmds.push(result);
				$scope.ansibleOutputDisplay = true;
			})
			.error(function(resp) {
				console.log(resp);
				$scope.loading = false;
			});
		};
		
		
		$scope.showHelp = function(){
			$scope.inventoryDialog = ngDialog.open({
				template:'<div style="padding: 5px;"><iframe height="300" width="100%" frameborder="0" allowfullscreen src='+$scope.selectedAnsibleModule.help+'></iframe></div>',
				plain: true,
				showClose: true,
				closeByDocument: false,
				closeByEscape: false,
				scope: $scope
			});
		};
		
		if($rootScope.selectedFabricsTab == "ansibleAutomation" && $scope.networkCode && !$scope.dataReload){
			$scope.loadAnsibleModules();
		}
		if($rootScope.selectedFabricsTab == "ansibleAutomation"){
			$rootScope.contextValue = "ansible_automation";
		}
	}
])