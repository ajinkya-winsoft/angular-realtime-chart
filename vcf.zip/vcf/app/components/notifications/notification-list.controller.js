VCF.controller('NotificationListController', ['$scope', 'SharedDataService',
	function($scope, SharedDataService){
		var context =  SharedDataService.getContext();
		$scope.selectedNode = context.menu;
	}
]);