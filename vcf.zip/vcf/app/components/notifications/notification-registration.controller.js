VCF.controller('NotificationDialogController', ['$scope', '$rootScope', '$http', 'config', '$timeout', 'ngDialog', 
	function($scope, $rootScope, $http, config, $timeout, ngDialog){
		$scope.rowCount = 0;
		
		$scope.addNew = function(addCondition){
			if($scope.currentNotification.type == "select"){
				ngDialog.open({
					template: 
						'<div class="inner-dialog-container">'+
							'<div>Please select type</div>'+
							'<button type="button" class="button" ng-click="closeThisDialog(0)">Close</button>'+
						'</div>',
					plain: 'true'
				});
				return
			}
			$scope.rowCount++;
			addCondition.conditions.push({ 
				'code': $scope.rowCount,
				'operand1': "select", 
				'operator': "select",
				'operand2': ''
			});
			if ($scope.currentNotification.conditions.length >= 1){
				$scope.disabledType = true;
			}
		};
		
		$scope.removeRow = function(removeCondition){
			var index = -1;
			var comArr = eval( $scope.currentNotification.conditions );
			for( var i = 0; i < comArr.length; i++ ) {
				if( comArr[i].code === removeCondition ) {
					index = i;
					break;
				}
			}
			if( index === -1 ) {
				alert( "Something gone wrong");
			}
			
			$scope.currentNotification.conditions.splice( index, 1);
			if ($scope.currentNotification.conditions.length <= 0){
				$scope.disabledType = false;
			}
			else{
				$scope.disabledType = true;
			}
		};
		
		$scope.getConditionFields = function(){
			$http({
					method: 'GET',
					url: config.NOTIFICATION_TYPE_GET_URI,  
					params: {
						'type': $scope.currentNotification.type
					}
				})
				.success(function(response){
					$scope.conditionFields = response.result;
				})
				.error(function(resp) {
					console.log(resp);
				});

		};
		
		$scope.save = function(data){
			if(!data.name || data.type == "select" || data.severity == "select") {
				ngDialog.open({
					template: 
						'<div class="inner-dialog-container">'+
							'<div>Name, Type, Severity & Action Fields are mandatory</div>'+
							'<button type="button" class="button" ng-click="closeThisDialog(0)">Close</button>'+
						'</div>',
					plain: 'true'
				});
				return;
			};
			
			if(data.conditions.length < 1){
				ngDialog.open({
					template: 
						'<div class="inner-dialog-container">'+
							'<div>Minimum one condition required</div>'+
							'<button type="button" class="button" ng-click="closeThisDialog(0)">Close</button>'+
						'</div>',
					plain: 'true'
				});
				return;
			};

			if(data.conditions[0].operand1 == "select" || data.conditions[0].operator == "select" || data.conditions[0].operand2 == ""){
				ngDialog.open({
					template: 
						'<div class="inner-dialog-container">'+
							'<div>All values of 1st condition must be selected</div>'+
							'<button type="button" class="button" ng-click="closeThisDialog(0)">Close</button>'+
						'</div>',
					plain: 'true'
				});
				return;
			};
			
			if (data.code) {
				$rootScope.$broadcast("update-row", data);
				ngDialog.close();
			}
			else {
				$http({
					method: 'PUT',
					url: config.NOTIFICATION_PUT_URI, 
					data: {
						'name': data.name,
						'type': data.type,
						'pollingFrequency': data.pollingFrequency,
						'severity': data.severity,
						'retriggerPeriod': data.retriggerPeriod,
						'shouldMatchAll': data.shouldMatchAll,
						'action': data.action,
						'state': data.state,
						'conditions': data.conditions
					}
				})
				.success(function(response){
				
					var createNotificationDialog = ngDialog.open({
						template: 
							'<div class="inner-dialog-container success-container">'+
								'<div>Notification saved successfully.</div>'+
							'</div>',
						plain: 'true',
						showClose: false,
						overlay: false,
						width:250
					});
					
					$timeout(function () {
						ngDialog.close(createNotificationDialog);
					}, 2000);
				
					$rootScope.$broadcast("load-notification");
					ngDialog.close();
				})
				.error(function(resp) {
					console.log(resp);
				});
			}			
		};
		
		$scope.cancelDialog = function(){
			$rootScope.$broadcast("load-notification");
			ngDialog.close();
		}
		
		if($scope.currentNotification.conditions){
			$scope.getConditionFields();
		}
		else{
			$scope.currentNotification.conditions = [
				// {
					// 'code': $scope.rowCount,
					// 'operand1': '',
					// 'operator': '',
					// 'operand2': ''
				// }
				];
		}
		
		if ($scope.currentNotification.conditions.length <= 0){
			$scope.disabledType = false;
		}
		else{
			$scope.disabledType = true;
		}
	}
]);