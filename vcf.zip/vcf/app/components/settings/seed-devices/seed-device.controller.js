VCF.controller('SeedDeviceController', ['$scope', '$rootScope', '$http', '$q', '$filter', '$interval', 'ngDialog', 'config', '$timeout', 'ContextSearchService', 
	function($scope, $rootScope, $http, $q, $filter, $interval, ngDialog, config, $timeout, ContextSearchService){

		$scope.seedDeviceList = {};
		$scope.currentSeedDevice = {};
		$rootScope.contextValue = "seed_devices";
		
		$scope.search = function(){
			$http
				({
					method: 'POST', 
					url: config.CONTEXT_SEARCH_POST_URI,
					data: {
						'context': $rootScope.contextValue,
						'key': '',
						'value': $scope.searchValue
					}
				})
				.success(function() {
					ContextSearchService.sendData($scope.searchValue);
				}) ;
		};
		
		$scope.$on('text_search', function(){
			var searchValue =  ContextSearchService.getData();
			if (searchValue == '') {
				$scope.gridOptions.data = $scope.seedDeviceList;
			}
			else {
				$scope.gridOptions.data = $filter('filter')($scope.seedDeviceList, searchValue, undefined);
			}
        });

		$scope.openSeedDevice = function (value) {
			if(value) {
				$scope.currentSeedDevice = value;
			} 
			else {
				$scope.currentSeedDevice = {};
				$scope.currentSeedDevice.port = '80';
				$scope.currentSeedDevice.protocol='http';
				$scope.currentSeedDevice.uri='vRest';
				$scope.currentSeedDevice.triggerDeviceDiscovery = true;
				
			}
			
			$scope.seedDeviceDialog = ngDialog.open({
				template: './app/components/settings/seed-devices/seed-device.dialog.htm',
				showClose: false,
				closeByDocument: false,
				closeByEscape: false,
				scope: $scope
			})
		};
		
		$scope.save = function(data) {
			$scope.currentSeedDevice = null;
			if(!data.ip) {
				ngDialog.open({
					template: 
						'<div class="inner-dialog-container">'+
							'<div>name is mandatory</div>'+
							'<button type="button" ng-click="closeThisDialog(0)">Close</button>'+
						'</div>',
					plain: 'true'
					});
			}
			else if (data.code) {
				$scope.saveRow(data);
				ngDialog.close($scope.seedDeviceDialog);
			} 
			else {
				$http({
					method: 'PUT',
					url: config.SEED_DEVICE_PUT_URI,  
					data: data
				})
				.success(function(response){
					var createSeedDeviceDialog = ngDialog.open({
						template: 
							'<div class="inner-dialog-container success-container">'+
								'<div>Seed Device saved successfully.</div>'+
							'</div>',
						plain: 'true',
						showClose: false,
						overlay: false,
						width:250
					});
					
					$timeout(function () {
						ngDialog.close(createSeedDeviceDialog);
					}, 2000);
					
					$scope.gridOptions.data.push(data);
					loadSeedDevices();
				})
				.error(function(resp) {
					console.log(resp);
					$scope.loading = false;
				});
				ngDialog.close($scope.seedDeviceDialog);
			}
		};
		
		$scope.deleteRow = function(row) {
			ngDialog.openConfirm({
				template:
					'<div class="inner-dialog-container">'+
						'<p>Are you sure you want to close the parent dialog?</p>'+
						'<div class="ngdialog-buttons">'+
							'<button type="button" class="button" ng-click="closeThisDialog(0)"> No </button> '+
							'<button type="button" class="button" ng-click="confirm(1)">Yes</button>'+
						'</div>'+
					'</div>',
				plain: true
			}).then(function(success){
				var index = $scope.gridOptions.data.indexOf(row.entity);
				$http ({
					method: 'DELETE',
					url: config.SEED_DEVICE_DELETE_URI + "/" + row.entity.code
				})
				.success(function(response){
					var DeleteSeedDeviceDialog = ngDialog.open({
						template: 
							'<div class="inner-dialog-container success-container">'+
								'<div>Seed Device deleted successfully.</div>'+
							'</div>',
						plain: 'true',
						showClose: false,
						overlay: false,
						width:250
					});
					
					$timeout(function () {
						ngDialog.close(DeleteSeedDeviceDialog);
					}, 2000);
					
					$scope.gridOptions.data.splice(index, 1);
					loadSeedDevices();
				})
				.error(function(resp) {
					console.log('an error occurred', resp.data);
					console.log(resp);
				});
			})
		};
		
		$scope.columns = [
			{name: 'code', displayName: 'Code', visible: false, width:50},
			{name: 'ip', displayName: 'IP', width:100},
			{name: 'protocol', displayName: 'Protocol'},
			{name: 'port', displayName: 'Port'},
			{name: 'uri', displayName: 'API'},
			{name: 'userId', displayName: 'User', sort: { direction: 'asc', priority: 0 }},
			{name: 'deviceDiscoveryStatus', displayName: 'Status'},
			{name: 'Action',  
					enableCellEdit: false, 
					enableSorting:false,
					width: 80,
					cellTemplate: 
						'<button ng-click="grid.appScope.openSeedDevice(row.entity)" class="icon-edit" tooltip-placement="left" uib-tooltip="Edit Seed Device">Edit</button>'+	
						'<button ng-click="grid.appScope.deleteRow(row)" class="icon-delete" tooltip-placement="left" uib-tooltip="Delete Seed Device"> Delete </button>'
			}		
		];
		
		var paginationOptions = {
			pageNumber: 1,
			pageSize: 10
		};
		
		$scope.gridOptions = {
			rowEditWaitInterval: 1000,
			paginationPageSizes: [10, 15, 20],
			paginationPageSize: 10,
			enableCellEdit: false,
			enableGridMenu: true,
			enableColumnResizing: true,
			columnDefs: $scope.columns,
			rowStyle: function(row){
				if(row.entity.deviceDiscoveryStatus === "completed"){
					return;
				}
				if(row.entity.deviceDiscoveryStatus === "failed"){
					return 'redbg';
				}
				else {
					return 'greybg';
				}
			},
			rowTemplate : '<div ng-class="grid.options.rowStyle(row)"><div ng-repeat="(colRenderIndex, col) in colContainer.renderedColumns track by col.uid" ui-grid-one-bind-id-grid="rowRenderIndex + \'-\' + col.uid + \'-cell\'" ng-class="{ \'ui-grid-row-header-cell\': col.isRowHeader}" class="ui-grid-cell" role="{{col.isRowHeader ? \'rowheader\' : \'gridcell\'}}" ui-grid-cell></div></div><div ng-class="{\'error-tooltip\': row.entity.deviceDiscoveryStatus == \'failed\' && row.entity.error && row.entity.error != \'\'}" style="display:none"> {{row.entity.error}}</div>',
			
			onRegisterApi: function(gridApi) {
				//set gridApi on scope
				$scope.gridApi = gridApi;
				
				//gridApi.rowEdit.on.saveRow($scope, $scope.saveRow);
				
				gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
					paginationOptions.pageNumber = newPage;
					paginationOptions.pageSize = pageSize;
					loadSeedDevices();
				});
			}
		};
		
		var loadSeedDevices = function() {
			$scope.loading = true;
			$http ({
				method: 'GET',
				url: config.SEED_DEVICES_GET_URI,
				params: {
					"pageNumber": paginationOptions.pageNumber, 
					"pageSize" : paginationOptions.pageSize
				}
				
			})
			.success(function (response) {
				$scope.gridOptions.data = response.result;
				$scope.seedDeviceList = response.result;
				$scope.loading = false;
			})
			.error(function(resp) {
				console.log(resp);
				$scope.loading = false;
			});
		};
		// automatically called when the grid is edited inline (within row)
		$scope.saveRow = function( rowEntity ) {
			// create a fake promise - normally you'd use the promise returned by $http or $resource
			var promise = $q.defer();
			
			//$scope.gridApi.rowEdit.setSavePromise( rowEntity, promise.promise );

			// fake a delay of 3 seconds whilst the save occurs, return error if gender is "male"
			$interval( function() {
				if (rowEntity.ip === '' ) {
					promise.reject();
				}
				else {
					promise.resolve();
					$http ({
						method: 'POST',
						url: config.SEED_DEVICE_POST_URI,
						data: rowEntity
					})
					.success(function(response){
						var UpdateSeedDeviceDialog = ngDialog.open({
							template: 
								'<div class="inner-dialog-container success-container">'+
									'<div>Seed Device saved successfully.</div>'+
								'</div>',
							plain: 'true',
							showClose: false,
							overlay: false,
							width:250
						});
						
						$timeout(function () {
							ngDialog.close(UpdateSeedDeviceDialog);
						}, 2000);
						
						loadSeedDevices();
					})
				}
			}, 100, 1);
		};
		
		$scope.openZTP = function(){
			$scope.ztp = {};
			$scope.ztp.file = '';
			$scope.ztp.userId='';
			$scope.ztp.password='';
			$scope.ZTPDialog = ngDialog.open({
				template: './app/components/settings/seed-devices/ZTP.dialog.htm',
				showClose: false,
				closeByDocument: false,
				closeByEscape: false,
				scope: $scope
			})
		};
		
		$scope.cancelDialog = function(){
			loadSeedDevices();
			ngDialog.close();
		};
		
		$scope.refreshSeedDevice = function(){
			loadSeedDevices();
		};
		
		loadSeedDevices();
	}
]);