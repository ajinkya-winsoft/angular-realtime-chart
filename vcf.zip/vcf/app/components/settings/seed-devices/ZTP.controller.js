VCF.controller('ZTPController', ['$scope', '$rootScope', '$http', '$q', '$filter', '$interval', 'ngDialog', 'config', '$timeout', 'ContextSearchService', 
	function($scope, $rootScope, $http, $q, $filter, $interval, ngDialog, config, $timeout, ContextSearchService){
		$scope.model = {
			name: "",
			comments: ""
		};

		//an array of files selected
		$scope.files = [];

		//listen for the file selected event
		$scope.$on("fileSelected", function (event, args) {
			$scope.$apply(function () {            
				//add the file object to the scope's files collection
				$scope.files.push(args.file);
			});
		});
		$scope.saveZTP = function(){
			if(document.getElementById("hostFile").files.length == 0 || $scope.ztp.userId == "" || $scope.ztp.password == "" ) {
				ngDialog.open({
					template: 
						'<div class="inner-dialog-container">'+
							'<div>Host File, UserID & Password are mandatory</div>'+
							'<button type="button" class="button" ng-click="closeThisDialog(0)">Close</button>'+
						'</div>',
					plain: 'true'
					});
				return;
			}
			
			$http({
				method: 'POST',
				url: config.ZTP_FILE_UPLOAD_POST_URI,
				headers: { 'Content-Type': undefined },
				transformRequest: function(data) {
					var formData = new FormData();
					formData.append('userId', angular.toJson(data.userId));
					formData.append('password', angular.toJson(data.password));
					for (var i = 0; i < data.files.length; i++) {
					formData.append('hostFile', data.files[i]);
					}
					return formData;
				},
				data: { 
					'userId': $scope.ztp.userId, 
					'password': $scope.ztp.password,
					'files': $scope.files 
				}
			})
			.success(function (data, status, headers, config) {
				//console.log("success!");
				ngDialog.close();
				var createZTPDialog = ngDialog.open({
					template: 
						'<div class="inner-dialog-container success-container">'+
							'<div>ZTP File details uploaded successfully.</div>'+
						'</div>',
					plain: 'true',
					showClose: false,
					overlay: false,
					width:300
				});
				
				$timeout(function () {
					ngDialog.close(createZTPDialog);
				}, 2000);
			})
			.error(function (data, status, headers, config) {
				//console.log("failed!");
				ngDialog.close();
			});
		};
		
		$scope.cancelZTP = function(){
			ngDialog.close();
		};
	}
]);

VCF.directive('fileUpload', function () {
    return {
        scope: true,        //create a new scope
        link: function (scope, el, attrs) {
            el.bind('change', function (event) {
                var files = event.target.files;
                //iterate files since 'multiple' may be specified on the element
                for (var i = 0;i<files.length;i++) {
                    //emit event upward
                    scope.$emit("fileSelected", { file: files[i] });
                }                                       
            });
        }
    };
});