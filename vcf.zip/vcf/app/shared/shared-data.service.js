VCF.factory('SharedDataService',['$rootScope', '$timeout', 'FabricsDataService', function($rootScope, $timeout, FabricsDataService){
	var service = {context: {}, global: {}};

	service.clear = function() {
		service.context = {};
	}
	
	service.getContext = function(){
		return service.context;
	};

	service.setCurrentMenu = function(data){

		FabricsDataService.clear();

		service.context.menu = data;
		//$timeout(function() {
		//		$rootScope.$broadcast('data_shared');
		//}, 50);
			 
		$rootScope.$broadcast('data_shared');
	};

	service.setNotification = function(notification){
		$rootScope.$broadcast('notification', notification);
	};
	return service;
}]);