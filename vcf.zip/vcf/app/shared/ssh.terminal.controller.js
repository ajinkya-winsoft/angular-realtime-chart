VCF.controller('SSHTerminalController', ['$scope', '$rootScope', '$http', 'config', '$timeout', 'ngDialog', '$interval',
	function($scope, $rootScope, $http, config, $timeout, ngDialog, $interval) {
		$scope.cmds = [];
		
		$scope.terminalKeyUp = function (keyEvent, dialogNumber, host, port, user, password, command){
			if (keyEvent.which === 13 && command !=""){
				//console.log(dialog)
				console.log("enter clicked");
				//$scope.isHide = true;
				$scope.dialogLoading = true;
				$http({
					method: 'POST',
					url: config.SSH_COMMAND_POST_URI,
					data: {
						'host' : host,
						'port' : port,
						'user' : user,
						'password' : password,
						'command' : command
					}
				})
				.success(function(response){
					//$timeout(function(){
						var result = response.result ? response.result : response.message;
						$scope.cmds.push('$ ' + command);
						$scope.cmds.push(result);
						$scope.command = '';
						$scope.shouldBeFocus = true;
						$scope.dialogLoading = false;
					//}, 5000);
				})
				.error(function(resp) {
					//$scope.isHide = false;
					console.log('an error occurred', resp.data);
					console.log(resp);
				});
			
			}
		};
		
		$scope.inputFocus = function () {
			$scope.shouldBeFocus = true;
			//$('#textboxMsg').focus();
		};
	}
]);