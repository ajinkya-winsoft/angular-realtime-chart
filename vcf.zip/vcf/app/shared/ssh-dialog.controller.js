VCF.controller('SSHController', ['$scope', '$rootScope', '$http', 'config', 'ngDialog',
	function($scope, $rootScope, $http, config, ngDialog){
		
		$rootScope.SSHAuthDialogOpen = [];
		$scope.SSHAuthDialog = [];
		$rootScope.SSHDialogOpen = [];
		$scope.SSHDialog = [];
		
		$scope.$on('fabric_change', function(event, newValue, oldValue, parent){
			$scope.host = ""+(newValue.mgmtIp ? newValue.mgmtIp : newValue.ip);
			if (parent) {
				$scope.user = "" + (parent.userId ? parent.userId : "");
				$scope.password = "" + (parent.password ? parent.password : "");
			}
		});
		
		$scope.$on('fabric_node_change', function(event, newValue, oldValue, parent){
			$scope.host = ""+(newValue.mgmtIp ? newValue.mgmtIp : newValue.ip);
			if (parent) {
				$scope.user = "" + (parent.userId ? parent.userId : "");
				$scope.password = "" + (parent.password ? parent.password : "");
			}
		});
		
		$scope.dialogNumber = 0;
		var div, label, input, span;
		
		$scope.$on('openSSHfromMapDialog', function(event, selectedNodeForDialog){
			$scope.host = selectedNodeForDialog.mgmtIp;
			$scope.userDialog();
		});
		
		$scope.SSHCredentials = {};
		
		$scope.userDialog = function(){
			
			$scope.dialogNumber++;
			
			var authDialogData = {
				'dialogNumber': $scope.dialogNumber,
				'host': $scope.host,
				'port': '22',
				'user': $scope.user,
				'password': $scope.password
			};
			
			$scope.SSHAuthDialog[$scope.dialogNumber] = ngDialog.open({
				template: 'SSHAuthDialog',
				showClose: true,
				closeByDocument: false,
				closeByEscape: false,
				overlay: false,
				draggable: true,
				data: authDialogData,
				scope: $scope,
				appendClassName: 'ngdialog-SSH',
				width: 300,
				height: 160
			});
			
		};
		
		$scope.openSSHTerminal = function(dialogNumber, host, port, user, password){
			ngDialog.close($scope.SSHAuthDialog[dialogNumber].id);
			
			var SSHDialogData = {
				'dialogNumber': dialogNumber,
				'host': host,
				'port': port,
				'user': user,
				'password': password
			};
			
			$scope.SSHDialog = ngDialog.open({
				template: './app/shared/ssh.terminal.dialog.htm',
				showClose: true,
				closeByDocument: false,
				closeByEscape: false,
				overlay: false,
				draggable: true,
				pinable: true,
				showMinimize: true,
				enableFullScreen: true,
				minimizedTitle: "SSH " + host,
				data: SSHDialogData,
				scope: $scope,
				appendClassName: 'ngdialog-SSH',
				width: 650,
				height: 450
			});
		};
	}
]);

VCF.directive('scroll', ['$timeout', function($timeout) {
	return {
		restrict: 'A',
		link: function(scope, element, attr) {
			scope.$watchCollection(attr.scroll, function(newVal) {
				$timeout(function() {
					element[0].scrollTop = element[0].scrollHeight;
				});
			});
		}
	}
}]);

VCF.directive('ngEnter', function () {
	return function (scope, element, attrs) {
		element.bind("keydown keypress", function (event) {
			if(event.which === 13) {
				scope.$apply(function (){
					scope.$eval(attrs.ngEnter);
				});
				event.preventDefault();
			}
		});
	};
});

VCF.directive('ngFocus',['$timeout', '$parse', function($timeout, $parse) {
	return {
		link: function(scope, element, attrs) {
			var model = $parse(attrs.ngFocus);
			scope.$watch(model, function(value) {
				if(value === true) { 
					$timeout(function() {
						element[0].focus(); 
					});
				}
			});
			element.bind('blur', function() {
				scope.$apply(model.assign(scope, false));
			})
		}
	};
}]);