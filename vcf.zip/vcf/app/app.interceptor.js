VCF.config(['$httpProvider', function setupConfig($httpProvider) {		
		$httpProvider.interceptors.push('httpInterceptor');		
	}
]);

var noRandomIdUrls = [
	"uib/template",
	"service",
	"ui-grid",
	"SSHAuthDialog"
];
		
VCF.service('httpInterceptor',['$q', 'SharedDataService', function ($q, SharedDataService) {
			
		return ({
				request: request,
				requestError: requestError,
				response: response,
				responseError: responseError
			});
			
		// Intercept the request configuration.
		function request(config) {
			for(var i = 0; i < noRandomIdUrls.length; i++) {
				if(config.url.startsWith(noRandomIdUrls[i])) {
					return config;
				}
			}
			var tempUrl = config.url.substring(config.url.lastIndexOf("/")+1);
			var rNumber = new Date().getTime() * Math.random();
			if (config.params) {
				config.params['_d'] = rNumber;
			}
			else {
				config.params = {'_d': rNumber};
			}
			return(config);
		}
		
		// Intercept the failed request.
		function requestError(rejection) {
			return( $q.reject(rejection) );
		}
		
		// Intercept the successful response.
		function response(response) {
			if (response && (response.data || (response.status !== 200))) {
				if (typeof response.data !== 'string') { // response.data is an object
					if (response.data.success) { // handle functional errors returned by server
						if (response.data.success === true || response.data.success === 'true') {
							// to nothing on successful result
						}
						else {
							SharedDataService.setNotification({type: 'error', msg: response.data.msg});
							return($q.reject(response));
						}
					}
				}
				else if (response.status != 200) { // handle technical errors in http
					alert(response.status + ' - ' + response.statusText);
					return($q.reject(response));
				}
			}
			
			return(response);
		}
		
		// Intercept the failed response. Handle technical errors in http!
		function responseError(response) {
			//console.log(response.status);
			var msg = "";
			if(response.status == -1){
				msg = "<div class='inner-dialog-container'>There seems to be some issue with the Network Connectivity, please contact your system administrator.</div>";
			}
			else if(response.status == 401){
				msg = "<div class='inner-dialog-container'>Session Timeout, please login again.</div>";
				document.location = "/";
			}
			else{
				msg = "<div class='inner-dialog-container'>Please contact your system administrator to configure following service: " + response.config.url + " (" + response.status + ': ' + response.statusText + ")" + "</div>";
			}
			SharedDataService.setNotification({type: 'error', msg: msg});
			return($q.reject(response));
		}
	}
]);