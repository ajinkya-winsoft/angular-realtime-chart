angular.module('winsoft.map', [])
	.directive('networkMap', function(){
		// Runs during compile
		return {
			// name: '',
			// priority: 1,
			// terminal: true,
			scope: {
				title: '=',
				networkNodes: '=',
				networkLinks: '=',
				nodeClick: '=',
				nodeDblclick: '=',
				nodeContextclick: '=',
				nodeMouseover: '=',
				nodeMouseout: '=',
				mapClick: '=',
				nodeMove: '=',
				linkClick: '=',
				linkDblclick: '='
			}, // {} = isolate, true = child, false/undefined = no change
			// require: 'ngModel', // Array = multiple requires, ? = optional, ^ = check parent elements
			restrict: 'E', // E = Element, A = Attribute, C = Class, M = Comment
			template: '<div>{{title}}</div><div class="network"></div>',
			// templateUrl: '',
			// replace: true,
			// transclude: true,
			// compile: function(tElement, tAttrs, function transclude(function(scope, cloneLinkingFn){ return function linking(scope, elm, attrs){}})),
			link: function($scope, iElm, iAttrs, controller) {
				//$scope.title = iAttrs.title;

				var mainElement = iElm[0];
				var width = parseInt(iAttrs.width);
				var height = parseInt(iAttrs.height);
				/**/
			},

			controller: function($scope, $element, $attrs, $transclude, $compile) {

				var mainElement = $element[0];
				var width = parseInt($attrs.width);
				var height = parseInt($attrs.height);
				
				var simulationMode = false;

				var svg = null;
				var d3Svg = null;
				
				//$element.on("click", onClickMap);
				//$element.on("contextmenu",onContextClickMap);

				// Per-type markers, as they don't inherit styles.
				var markerData = [
					{id: 0, name: 'normalRoute', refX: 15, refY:-1.5, markerWidth: 6, markerHeight: 6, path: 'M0,-5L10,0L0,5', viewbox: '0 -5 10 10'},
					{id: 1, name: 'errorRoute', refX: 1, refY:0, markerWidth: 6, markerHeight: 6, path: 'M0 -5 L10 5 M0 5 L 10 -5', viewbox: '0 -5 10 5'},
					{id: 2, name: 'congestedRoute', refX: 15, refY:-1.5, markerWidth: 6, markerHeight: 6, path: 'M0,-5L10,0L0,5', viewbox: '0 -5 10 10' },		
					{id: 3, name: 'circle', refX: 15, refY:-1.5, markerWidth: 6, markerHeight: 6, path: 'M 0, 0  m -5, 0  a 5,5 0 1,0 10,0  a 5,5 0 1,0 -10,0', viewbox: '-6 -6 12 12'},
					{id: 4, name: 'square', refX: 15, refY:-1.5, markerWidth: 6, markerHeight: 6, path: 'M 0,0 m -5,-5 L 5,-5 L 5,5 L -5,5 Z', viewbox: '-5 -5 10 10'},
					{id: 5, name: 'arrow', refX: 15, refY:-1.5, markerWidth: 6, markerHeight: 6, path: 'M 0,0 m -5,-5 L 5,0 L -5,5 Z', viewbox: '-5 -5 10 10' },
					{id: 6, name: 'stub', refX: 15, refY:-1.5, markerWidth: 6, markerHeight: 6, path: 'M 0,0 m -1,-5 L 1,-5 L 1,5 L -1,5 Z', viewbox: '-1 -5 2 10'},
					{id: 7, name: 'testRoute1', refX: 1, refY:0, markerWidth: 6, markerHeight: 6, path: 'M0 -5 L10 5 M0 5 L 10 -5', viewbox: '0 -5 10 5'}
				];

				
				$scope.clear = function() {
					//console.log($element);
					/*
					var basicElementObj = mainElement.querySelector('svg');
					angular.element(basicElementObj).remove();
					*/

					//d3.select('.network-map-svg').remove();
					if (d3Svg) {
						d3Svg.remove();
					}
					svg = null;
					d3Svg = null;
				};

				$scope.$watch('networkNodes', function(newValue, oldValue, scope) {
					if (newValue != oldValue) {
						scope.clear();
						
						var basicElementObj = mainElement.querySelector('div.network');
						var networkElement = angular.element(basicElementObj);
						var svgElement =  d3.select(networkElement[0]);
						d3Svg = svgElement.append("svg")
									.attr("class", "network-map-svg");
							
						svg = d3Svg
								.attr("width", "100%")
								.attr("height", "100%")
								//.style("width", function(d) { return d + "%"; })
								.call(d3.behavior.zoom().on("zoom", function ()  {
										svg.attr("transform", "translate(" + d3.event.translate + ")" + " scale(" + d3.event.scale + ")")
									}))
								.on("dblclick.zoom", null)
								.append("g");
						

						svg.append("defs").selectAll("marker")
							.data(markerData)
						  .enter().append("marker")
							.attr("id", function(d) { return d.name + "MarkerId"; })
							.attr("viewBox", "0 -5 10 10")
							.attr("refX", function(d) { return d.refX; })
							.attr("refY", function(d) { return d.refY; })
							.attr("markerWidth", function(d) { return d.markerWidth; })
							.attr("markerHeight", function(d) { return d.markerHeight; })
							.attr("orient", "auto")
						  .append("path")
							.attr("d", function(d) { return d.path; });

						render(scope.networkNodes, scope.networkLinks);
					}
				}, false); // set TRUE for deep checking
			
				function render(devices, links) {

					//var links = data.links;

					//var devices = data.devices;
					var nodes = {};

					// Compute the distinct nodes from the links.
					links.forEach(function(link) {
						
						if (!nodes[link.source]) {
							var device = devices.filter(function (device) { 
									return device.name === this.name;
								}, {name: link.source})[0];
						
							if (device) {
								nodes[link.source] = device;
								nodes[link.source].outboundLinks = [];
								nodes[link.source].inboundLinks = [];
							}
							else {
								nodes[link.source] = {name: link.source, outboundLinks: [], inboundLinks: []};
							}
						}
						nodes[link.source].outboundLinks.push({code: link.code, type: link.type, toNode: link});
						link.source = nodes[link.source];
						
						if (!nodes[link.target]) {
							var device = devices.filter(function (device) { 
									return device.name === this.name;
								}, {name: link.target})[0];
						
							if (device) {
								nodes[link.target] = device;
								nodes[link.target].outboundLinks = [];
								nodes[link.target].inboundLinks = [];
							}
							else {
								nodes[link.target] = {name: link.target, outboundLinks: [], inboundLinks: [link]}
							}
						}
						nodes[link.target].inboundLinks.push({code: link.code, type: link.type, fromNode: link});
						link.target = nodes[link.target];
						
					});

					force = d3.layout.force()
						//.gravity(.01)
						.nodes(d3.values(nodes))
						.links(links)
						.size([width, height])
						.linkDistance(95)//.linkDistance(65)
						.charge(-800)//.charge(-650)
						.start();
					
					if (simulationMode === true) {
						force.on("tick", tick);
					}
					else {
						var n=500;
						for (var i = n * n; i > 0; --i) force.tick();
						force.stop();
					}

					var clickCancelForLinks = clickCancelProcess(); // handle overlap of click and double click events
					
					var errPath = svg.append("g").selectAll("path")
						.data(force.links().filter(function(d) { return d.type === 'errorRoute'; }))
					  .enter().append("path")
						.attr("id", function(d) { return  d.type + "Path"  + d.code; })
						.attr("class", function(d) { return "link " + d.type; })
						.attr("marker-mid", function(d) { return "url(#" + d.type + "MarkerId" + ")"; })
						.on("mouseover", onMouseoverLink)
						.on("mouseout", onMouseoutLink)
						.call(clickCancelForLinks);
					var normalPath = svg.append("g").selectAll("path")
						.data(force.links().filter(function(d) { return d.type === 'normalRoute'; }))
					  .enter().append("line")
						.attr("id", function(d) { return  d.type + "Path"  + d.code; })
						.attr("class", function(d) { return "link " + d.type; })
						.attr("marker-mid", function(d) { return "url(#" + d.type + "MarkerId" + ")"; })
						.on("mouseover", onMouseoverLink)
						.on("mouseout", onMouseoutLink)
						.call(clickCancelForLinks);	
					var path = svg.append("g").selectAll("path")
						.data(force.links().filter(function(d) { return d.type === 'congestedRoute'; }))
					  .enter().append("path")
						.attr("id", function(d) { return  d.type + "Path"  + d.code; })
						.attr("class", function(d) { return "link " + d.type; })
						.attr("marker-end", function(d) { return "url(#" + d.type + "MarkerId" + ")"; })
						.on("mouseover", onMouseoverLink)
						.on("mouseout", onMouseoutLink)
						.call(clickCancelForLinks);
						
					var testPath = svg.append("g").selectAll("path")
						.data(force.links().filter(function(d) { return d.type === 'testRoute1'; }))
					  .enter().append("path")
						.attr("id", function(d) { return  d.type + "Path"  + d.code; })
						.attr("class", function(d) { return "link " + d.type; })
						.attr("marker-mid", function(d) { return "url(#" + d.type + "MarkerId" + ")"; })
						.on("mouseover", onMouseoverLink)
						.on("mouseout", onMouseoutLink)
						.call(clickCancelForLinks);

					clickCancelForLinks.on("click", onClickLink);
					clickCancelForLinks.on("dblclick", onDoubleClickLink);
					//clickCancelForLinks.on("mouseover", onMouseoverLink);


					var dragNodeBehavior = d3.behavior.drag()
								.on("dragstart", onDragNodeStart)
								.on("dragend", onDragNodeEnd)
								.on("drag", onDragNode);
					
					// define the nodes
					var node = svg.selectAll(".node")
						.data(force.nodes())
					  .enter().append("g")
						.attr("class", "node")
						.on("mouseover", onMouseOverNode)
						.on("mouseout", onMouseOutNode)
						.on("contextmenu", onNodeContextMenu)
						.call(dragNodeBehavior);
						
					// add the nodes
					node.append("circle")
						.attr("r", 4);
						//.style("fill", function(d) { return color(d.name); });
					
					var clickCancelForNodes = clickCancelProcess(); // handle overlap of click and double click events

					// add the image
					node.append("image")
						.attr("class","fabricNode")
						.attr("width", 32)
						.attr("height", 32)
						.attr("x", function(d) { return d.x; })
						.attr("y", function(d) { return d.y; })
						.attr("transform", "translate(-16,-18)")
						.attr("xlink:href", function(d) { return getImageByDeviceType(d);})
						.call(clickCancelForNodes);

					clickCancelForNodes.on("click", onClickNode);
					clickCancelForNodes.on("dblclick", onDoubleClickNode);
					//clickCancelForNodes.on("contextmenu", onNodeContextMenu);


					// add the text 
					node.append("text")
						//.attr("x", 12)
						//.attr("dy", ".35em")
						.attr("x", 8)
						.attr("y", ".31em")
						.attr("dx", -32)
						.attr("dy", 20)
						.text(function(d) { return d.name; });
					
					// add the text 
					node.append("text")
						.attr("class", "systemReading")
						.attr("x", 8)
						.attr("y", ".31em")
						.attr("dx", -20)
						.attr("dy", 34)
						//.text(function(d) { return d.cpu ? 'CPU: '+d.cpu+'%' : ''; });
						.text(function(d) { return d.cpu ? ' '+d.cpu+'' : ''; });
						
					// add the text 
					node.append("text")
						.attr("class", "systemReading")
						.attr("x", 8)
						.attr("y", ".31em")
						.attr("dx", -20)
						.attr("dy", 46)
						//.text(function(d) { return d.memory ? 'MEM: '+d.memory+'%' : ''; });
						.text(function(d) { return d.memory ? ' '+d.memory+'' : ''; });
					

					if (!simulationMode || simulationMode === false) {
						tick();
					}
				}
				
				// Use elliptical arc path segments to doubly-encode directionality.
				function tick() {
					var svg = d3Svg;//d3.select("#networkMapSvgId");
					var circle = svg.selectAll("circle");
					var text = svg.selectAll("text");
					var images = svg.selectAll("image.fabricNode");
					var errPath = svg.selectAll("path.errorRoute");
					var normalPath = svg.selectAll("line.normalRoute");	
					var path = svg.selectAll("path.congestedRoute");		
					var testPath = svg.selectAll("path.testRoute1");
					
					circle.attr("transform", transform);
					text.attr("transform", transform);
					images
						.attr("x", function(d) { return d.x; })
						.attr("y", function(d) { return d.y; });

					var diagonalFn = d3.svg.diagonal().projection(function(d) { return [d.x, d.y]; });
					testPath.attr("d", diagonalFn);
					
					path.attr("d", linkArc);
					errPath.attr("d", linkArc);

					normalPath
						.attr("x1", function(d) { return d.source.x; })
						.attr("y1", function(d) { return d.source.y; })
						.attr("x2", function(d) { return d.target.x; })
						.attr("y2", function(d) { return d.target.y; });
				}

				function linkArc(d) {
					var dx = d.target.x - d.source.x,
						dy = d.target.y - d.source.y,
						dr = Math.sqrt(dx * dx + dy * dy);
					return "M" + d.source.x + "," + d.source.y + "A" + dr + "," + dr + " 0 0,1 " + d.target.x + "," + d.target.y;
				}

				function transform(d) {
					return "translate(" + d.x + "," + d.y + ")";
				}
			
				// action to take on mouse onMouseOverNode
				function onMouseOverNode(d) {
				
					d3.select(this).selectAll("text").transition()
						.duration(750)
						//.attr("x", 22)
						//.style("stroke", "lightsteelblue")
						//.style("stroke-width", ".5px")
						//.style("font", "20px sans-serif");
					d3.select(this).select("circle").transition()
						.duration(500)
						.attr("r", 5);
					d3.select(this).select("image.fabricNode").transition()
						.duration(500)
						.attr("width", 42)
						.attr("height", 42)
						.attr("transform", "translate(-20,-23)");
						//.attr("transform", "translate(-26px,-26px)");
					//console.log(d);	
					$scope.nodeMouseover && $scope.nodeMouseover(d, d3.event);
					
				}
			 
				// action to take on mouse double onMouseOverNode
				function onMouseOutNode(d) {
					d3.select(this).select("image.fabricNode").transition()
						.duration(500)
						.attr("width", 32)
						.attr("height", 32)
						.attr("transform", "translate(-16,-18)");
						
					d3.select(this).select("circle").transition()
						.duration(750)
						.attr("r", 4);			
					d3.select(this).selectAll("text:not(.systemReading)").transition()
						.duration(500)
						//.attr("x", 12)
						.style("stroke", "none")
						//.style("fill", "black")
						//.style("stroke", "none")
						//.style("font", "10px sans-serif")
						;
					$scope.nodeMouseout && $scope.nodeMouseout(d);
				}
			 
			 	// for handling overlap of CLICK and DOUBLE CLICK events. 
			 	// suppress CLICK event upon DOUBLE CLICK event
			 	function clickCancelProcess() {
					var event = d3.dispatch('click', 'dblclick', 'contextmenu');
					function cc(selection) {
						var down,
							tolerance = 5,
							last,
							wait = null;
						// euclidean distance
						function dist(a, b) {
							return Math.sqrt(Math.pow(a[0] - b[0], 2), Math.pow(a[1] - b[1], 2));
						}
						selection.on('mousedown', function() {
							down = d3.mouse(document.body);
							last = +new Date();
						});
						selection.on('mouseup', function() {
							if (dist(down, d3.mouse(document.body)) > tolerance) {
								return;
							} else {
								if (wait) {
									window.clearTimeout(wait);
									wait = null;
									event.dblclick(d3.event);
								} else {
									wait = window.setTimeout((function(e) {
										return function() {
											event.click(e);
											wait = null;
										};
									})(d3.event), 300);
								}
							}
						});
					};
					return d3.rebind(cc, event, 'on');
				}
				
				// function onClickMap(d){
					// $scope.mapClick && $scope.mapClick(d);
				// }
				
				// function onContextClickMap(d, e){
					// $scope.mapContextclick && $scope.mapContextclick(d);
				// }

				// action to take on mouse double onMouseOverNode
				function onClickLink(e, i) {
					var arr = d3.select(e.target).data();
					if (arr && arr.length > 0) {
						$scope.linkClick && $scope.linkClick(arr[0]);
					}
				}

				function onDoubleClickLink(e, i) {
					var arr = d3.select(e.target).data();
					if (arr && arr.length > 0) {
						$scope.linkDblclick && $scope.linkDblclick(arr[0]);
					}
				}
				
				function onMouseoverLink(e, i) {
					d3.select(this).classed("linkover", true);
				}
				
				function onMouseoutLink(e, i) {
					d3.select(this).classed("linkover", false);
				}

				// action to take on mouse double onMouseOverNode
				function onClickNode(e, i) {
					var arr = d3.select(e.target).data();
					if (arr && arr.length > 0) {
						var d = arr[0];
						if ( d3.event
							&& (d.x !== d3.event.dx	|| d.y !== d3.event.dy)) {
							$scope.nodeMove && $scope.nodeMove(d);
						}
						else {
							$scope.nodeClick && $scope.nodeClick(d);
						}
					}
				}

				function onDoubleClickNode(e, i) {
					var arr = d3.select(e.target).data();
					if (arr && arr.length > 0) {
						$scope.nodeDblclick && $scope.nodeDblclick(arr[0]);
					}
				}
				
				function onNodeContextMenu(d) {
					$scope.nodeContextclick && $scope.nodeContextclick(d, d3.event);
					d3.event.preventDefault();
				}
			
				function onDragNodeStart(d, i) {
					d3.event.sourceEvent.stopPropagation();
					d3.select(this).classed("dragging", true);
					
					if (simulationMode === true) {
						force.stop();
					}
				}
			
				function onDragNodeEnd(d, i) {
					d3.select(this).classed("dragging", false);
					
					if (simulationMode === true) {
						force.start();
					}

					if ( d3.event
						&& (d.x !== d3.event.dx	|| d.y !== d3.event.dy)) {
						$scope.nodeMove && $scope.nodeMove(d);
					}
				}
			
				function onDragNode(d,i) {
					d.x += d3.event.dx;
					d.y += d3.event.dy;
					d3.select(this).classed("dragging", true).select("circle").attr("transform", transform);
					d3.select(this).classed("dragging", true).selectAll("text").attr("transform", transform);
					
					d3.select(this).classed("dragging", true)
						.select("image.fabricNode")
							.attr("x", function(d) { return d.x; })
							.attr("y", function(d) { return d.y; });
							
					d3.select(this).classed("dragging", true)
						.select("image.node-selection")
							.attr("x", function(d) { return d.x-20; })
							.attr("y", function(d) { return d.y; });
							
					d.outboundLinks.forEach(onDragLink);
					d.inboundLinks.forEach(onDragLink);
				}
			
				function onDragLink(d) {
					var link = d3.select("#" + d.type + "Path"  + d.code);
					if (d.type === "normalRoute") {
						link
							.attr("x1", function(d) { return d.source.x; })
							.attr("y1", function(d) { return d.source.y; })
							.attr("x2", function(d) { return d.target.x; })
							.attr("y2", function(d) { return d.target.y; });
					}
					else if (d.type === "testRoute1") {
						var diagonalFn = d3.svg.diagonal().projection(function(d) { return [d.x, d.y]; });
						link.attr("d", diagonalFn);
					}
					else {
						link.attr("d", linkArc);
					}
				}
			
				function getImageByDeviceType (data) {
					var enabled = data.fabId && data.fabId.length > 0 ? true : false ;
					var type = data.type;
					var state = data.state;

					if (type === 'host') {
						return "./assets/images/networkImages/host.png";
					}
					else if (type === 'server') {
						return "./assets/images/networkImages/server.png";
					}
					else if (type === 'switch') {
						return "./assets/images/networkImages/switch.png";
					}
					else if (type === 'wireless_router') {
						return "./assets/images/networkImages/wireless-router-down.png";
					}
					else if (type === 'router') {
						return "./assets/images/networkImages/router.png";
					}
					else if (type === 'wan') {
						return "./assets/images/networkImages/cloud.png";
					}
					else if (type === 'pbx') {
						return "./assets/images/networkImages/pbx.png";
					}
					else if (type === 'hub') {
						return "./assets/images/networkImages/hub-unstable.png";
					}
					else if (type === 'bridge') {
						return "./assets/images/networkImages/bridge-disabled.png";
					}
					else if (type === 'firewall') {
						return "./assets/images/networkImages/firewall-vertical-up.png";
					}
					else if (type === 'server_down') {
						return "./assets/images/networkImages/server-disabled.png";
					}
					else if (type === 'lan') {
						return "./assets/images/networkImages/lan.png";
					}
					else if (/B,R/.test(type)) {
						if (enabled) {
							return "./assets/images/networkImages/router-up.png";
						}
						else {
							return "./assets/images/networkImages/router-disabled.png";
						}
					}
					else if (/B,W/.test(type)) {
						if (enabled) {
							return "./assets/images/networkImages/switch-up.png";
						}
						else {
							return "./assets/images/networkImages/switch-disabled.png";
						}
					}
					else if (/B,W,R/.test(type)) {
						if (enabled) {
							return "./assets/images/networkImages/router-up.png";
						}
						else {
							return "./assets/images/networkImages/router-disabled.png";
						}
					}
					else if (/B/.test(type)) {
						if (enabled) {
							return "./assets/images/networkImages/switch-up.png";
						}
						else {
							return "./assets/images/networkImages/switch-disabled.png";
						}
					}
					else if (/R/.test(type)) {
						if (enabled) {
							return "./assets/images/networkImages/router-up.png";
						}
						else {
							return "./assets/images/networkImages/router-disabled.png";
						}
					}
					else if (/W/.test(type)) {
						if (enabled) {
							return "./assets/images/networkImages/access-Point-up.png";
						}
						else {
							return "./assets/images/networkImages/access-Point-disabled.png";
						}
					}
					else if (/S/.test(type)) {
						if (enabled) {
							return "./assets/images/networkImages/server-up.png";
						}
						else {
							return "./assets/images/networkImages/server-disabled.png";
						}
					}
					else {
						return "./assets/images/networkImages/unknown-device.png";
					}
					return null;
				}
			}
		};
	});