angular.module('winsoft.typeahead', [])
	.directive('typeahead', ['$timeout', '$rootScope', '$http', 'config', function($timeout, $rootScope, $http, config) {
		return {
			restrict: 'AEC',
			scope: {
				title: '@',
				modeltype: '@',
				retkey: '@',
				displaykey:'@',
				modeldisplay:'=',
				placeholdertext:"@",
				classstyle: "@",
				modelret: '=',
				modelcontext: '@',
				modelkey: '@',
				modelnetwork: '@'
			},
			link: function(scope, elem, attrs) {   
				scope.current = 0;
				scope.selected = false;
				var keyCode;
				var listPos=0;
				var listCount=0;
				var newTop=0;
				var divH=0;
				var aTop=0;
				var curTop=0;
				scope.da  = function($event, txt, context, key, networkCode){
					keyCode = window.event ? $event.keyCode : $event.which;
					scope.ajaxClass = 'loadImage';
					if(keyCode == 40 || keyCode == 38 || keyCode == 13 || keyCode == 27){
						if(keyCode == 38) //UP arrow pressed
						{
							
							if(listPos>1)
							{
								listPos--;
								$(".typeahead-group a").removeClass("active");
								$(".typeahead-group a:nth-child("+listPos+")").addClass("active");
								
								divH = angular.element(elem[0].querySelector(".typeahead-group")).prop("offsetHeight");
								aTop = angular.element(elem[0].querySelector(".typeahead-group a:nth-child("+listPos+")")).prop("offsetTop");
								curTop = aTop + angular.element(elem[0].querySelector(".searchField")).prop("offsetHeight");
								
								if(curTop > divH){
									newTop = curTop - divH;
									angular.element(elem[0].querySelector(".typeahead-group"))[0].scrollTop = newTop;
								}
								else{
									angular.element(elem[0].querySelector(".typeahead-group"))[0].scrollTop = 0;
								}
							}
						}
						
						if(keyCode == 40) //DOWN arrow pressed
						{
							if(listPos<listCount)
							{
								listPos++;
								$(".typeahead-group a").removeClass("active");
								$(".typeahead-group a:nth-child("+listPos+")").addClass("active");
								
								divH = angular.element(elem[0].querySelector(".typeahead-group")).prop("offsetHeight");
								aTop = angular.element(elem[0].querySelector(".typeahead-group a:nth-child("+listPos+")")).prop("offsetTop");
								curTop = aTop + angular.element(elem[0].querySelector(".searchField")).prop("offsetHeight");
								
								if(divH < curTop ){
									newTop = curTop - divH;
									angular.element(elem[0].querySelector(".typeahead-group"))[0].scrollTop = newTop;
								}
							}
						}
						
						if(keyCode == 13) //enter pressed
						{
							if(scope.TypeAheadData && scope.TypeAheadData.length > 0){
								scope.selected = true;
								scope.handleSelection(key,scope.TypeAheadData[listPos-1].name);
							}
						}
						
						if(keyCode == 27) //ESC pressed
						{
							scope.selected = false;
							listPos = 0;
							scope.modeldisplay = "";
							scope.TypeAheadData = [];
						}
					}
					else{
						$http
						({
							method: 'POST', 
							url: config.CONTEXT_SEARCH_POST_URI,
							params: {
								'networkCode': networkCode
							},
							data: {
								'context': context,
								'key': key,
								'value': txt
							}
						})
						.success(function(response, status) {
							scope.TypeAheadData = response.result;
							scope.ajaxClass = '';
							listPos = 1;
							listCount = response.result.length;
							$(".typeahead-group a").removeClass("active");
							$(".typeahead-group a:nth-child("+listPos+")").addClass("active");
						}) ;
					}
					
				}
				scope.handleSelection = function(key, val, index) {
					
					if(index){
						listPos = index + 1;
					}
					angular.element(elem[0].querySelector(".searchField")).focus();
					scope.modelret = key;
					scope.modeldisplay = val;
					scope.current = 0;
					scope.selected = true;
				}
				scope.isCurrent = function(index) {
					return scope.current == index;
				}
				scope.setCurrent = function(index) {
					scope.current = index;
				}
			},
			template: '<input style="border-radius: 0px; width: 100%" type="text" ng-model="modeldisplay" ng-KeyUp="da($event, modeldisplay, modelcontext, modelkey, modelnetwork)" ng-keydown="selected=false"'+
			'style="width:100%;" ng-class="ajaxClass"'+
			'placeholder="{{placeholdertext}}"'+
			'class="{{classstyle}}">'+
			'<div class="typeahead-group table-condensed overlap" ng-hide="!modeldisplay.length || selected">'+
			'<a class="typeahead-group-item noTopBottomPad" ng-repeat="item in TypeAheadData|filter:model  track by $index" '+
			'ng-click="handleSelection(item[retkey],item[displaykey],$index)" style="cursor:pointer" '+
			'ng-class="{active:isCurrent($index)}" '+
			'ng-mouseenter="setCurrent($index)">'+
			' {{item[title]}}<i style="float:right;">{{item[modeltype]}} </i>'+
			'</a> '+
			'</div>'+
			'</input>'
		};
}]);